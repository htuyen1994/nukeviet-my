-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: January 27, 2015, 01:23 AM GMT
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `nukeviet_my`
--


-- ---------------------------------------


--
-- Table structure for table `nv4_authors`
--

DROP TABLE IF EXISTS `nv4_authors`;
CREATE TABLE `nv4_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) DEFAULT '',
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors`
--

INSERT INTO `nv4_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '3d8d7d4509e03604610e0b2ebb6a981b3b7fc6ab', 1421983254, '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0');


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_config`
--

DROP TABLE IF EXISTS `nv4_authors_config`;
CREATE TABLE `nv4_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_module`
--

DROP TABLE IF EXISTS `nv4_authors_module`;
CREATE TABLE `nv4_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `lang_key` varchar(50) NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32) DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors_module`
--

INSERT INTO `nv4_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '860184b51b989cb380a6649a07f2aa81'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '0d79069ea3a0202424f754c2d0aa7efc'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '4a4b5439c54d9905ab56928a335537e3'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, 'c401fb3fa7f5900c559f5df2bcf3edc5'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, '095f71ead542b8bdc333847a39fa9480'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, 'f0cc5f822708a522bc03c06658afac83'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, 'd91dbd2a8b3ae5ce7f569ce41783add0'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, 'a004160d22637314f0278436dc8409a2'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, '7f09ec43f002400d2ec751f35b577903'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, 'c06d21f5f6669176fa4f8d60bc3b7b82'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '81f6c05a0b6031471b7c8f18d40ff121');


-- ---------------------------------------


--
-- Table structure for table `nv4_banip`
--

DROP TABLE IF EXISTS `nv4_banip`;
CREATE TABLE `nv4_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_click`
--

DROP TABLE IF EXISTS `nv4_banners_click`;
CREATE TABLE `nv4_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_clients`
--

DROP TABLE IF EXISTS `nv4_banners_clients`;
CREATE TABLE `nv4_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_plans`
--

DROP TABLE IF EXISTS `nv4_banners_plans`;
CREATE TABLE `nv4_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) DEFAULT '',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_plans`
--

INSERT INTO `nv4_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_rows`
--

DROP TABLE IF EXISTS `nv4_banners_rows`;
CREATE TABLE `nv4_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) DEFAULT '',
  `imageforswf` varchar(255) DEFAULT '',
  `click_url` varchar(255) DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_rows`
--

INSERT INTO `nv4_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', '', 'http://www.mofa.gov.vn', '_blank', 1421635014, 1421635014, 0, 0, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', '', 'http://vinades.vn', '_blank', 1421635014, 1421635014, 0, 0, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.gif', 'gif', 'image/gif', 510, 65, '', '', 'http://webnhanh.vn', '_blank', 1421635014, 1421635014, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_config`
--

DROP TABLE IF EXISTS `nv4_config`;
CREATE TABLE `nv4_config` (
  `lang` varchar(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` text,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_config`
--

INSERT INTO `nv4_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle - sitename'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '10485760'), 
('sys', 'global', 'upload_checking_mode', 'mild'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'allow_adminlangs', 'en,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', 'news'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google'), 
('sys', 'global', 'optActive', '0'), 
('sys', 'global', 'timestamp', '7'), 
('sys', 'global', 'mudim_displaymode', '1'), 
('sys', 'global', 'mudim_method', '4'), 
('sys', 'global', 'mudim_showpanel', '1'), 
('sys', 'global', 'mudim_active', '1'), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'version', '4.0.10'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'adminrelogin_max', '3'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '0'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '5'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '120'), 
('sys', 'define', 'nv_gfx_height', '25'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, sub, sup, table, tbody, td, th, tr, u, ul, iframe, figure, figcaption, video, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('vi', 'global', 'site_domain', ''), 
('vi', 'global', 'site_name', 'myDemo'), 
('vi', 'global', 'site_logo', 'images/logo.png'), 
('vi', 'global', 'site_description', 'NukeViet CMS 4.x Developed by VINADES.,JSC'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'site_theme', 'default'), 
('vi', 'global', 'mobile_theme', ''), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'switch_mobi_des', '1'), 
('vi', 'global', 'upload_logo', 'images/logo.png'), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'cronjobs_next_time', '1422322094'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha', '1'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '52'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', 'Chú ý&#x3A; Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http&#x3A;&#x002F;&#x002F;nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'bottom'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'socialbutton', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'news', 'imgposition', '1'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha', '1'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '1'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha', '1'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'admin@gmail.com'), 
('sys', 'global', 'error_send_email', 'admin@gmail.com'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv3c_O0guh'), 
('sys', 'global', 'session_prefix', 'nv3s_Dgglgw'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'jaZeQj6wBZzo29-lck1yO42mXkI-sAWc6NvfpXJNcjs,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'shops', 'image_size', '100x100'), 
('vi', 'shops', 'home_view', 'view_home_all'), 
('vi', 'shops', 'per_page', '20'), 
('vi', 'shops', 'per_row', '3'), 
('vi', 'shops', 'money_unit', 'VND'), 
('vi', 'shops', 'post_auto_member', '0'), 
('vi', 'shops', 'auto_check_order', '1'), 
('vi', 'shops', 'format_order_id', 'S%06s'), 
('vi', 'shops', 'format_code_id', 'S%06s'), 
('vi', 'shops', 'active_guest_order', '1'), 
('vi', 'shops', 'active_showhomtext', '1'), 
('vi', 'shops', 'active_order', '1'), 
('vi', 'shops', 'active_price', '1'), 
('vi', 'shops', 'active_order_number', '0'), 
('vi', 'shops', 'active_payment', '1'), 
('vi', 'shops', 'active_tooltip', '1'), 
('vi', 'shops', 'timecheckstatus', '0'), 
('vi', 'shops', 'show_product_code', '1'), 
('vi', 'shops', 'show_compare', '0'), 
('vi', 'shops', 'show_displays', '0'), 
('vi', 'shops', 'active_wishlist', '1'), 
('vi', 'shops', 'tags_alias', '0'), 
('vi', 'shops', 'auto_tags', '1'), 
('vi', 'shops', 'tags_remind', '0'), 
('vi', 'shops', 'auto_postcomm', '1'), 
('vi', 'shops', 'allowed_comm', '-1'), 
('vi', 'shops', 'view_comm', '6'), 
('vi', 'shops', 'setcomm', '4'), 
('vi', 'shops', 'activecomm', '1'), 
('vi', 'shops', 'emailcomm', '0'), 
('vi', 'shops', 'adminscomm', ''), 
('vi', 'shops', 'sortcomm', '0'), 
('vi', 'shops', 'captcha', '1');


-- ---------------------------------------


--
-- Table structure for table `nv4_cookies`
--

DROP TABLE IF EXISTS `nv4_cookies`;
CREATE TABLE `nv4_cookies` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `domain` varchar(100) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_counter`
--

DROP TABLE IF EXISTS `nv4_counter`;
CREATE TABLE `nv4_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_counter`
--

INSERT INTO `nv4_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1422321791, 0), 
('total', 'hits', 1422321791, 18, 18), 
('year', '2015', 1422321791, 18, 18), 
('year', '2016', 0, 0, 0), 
('year', '2017', 0, 0, 0), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('month', 'Jan', 1422321791, 18, 18), 
('month', 'Feb', 0, 0, 0), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 0, 0, 0), 
('month', 'May', 0, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 0, 0, 0), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 0, 0, 0), 
('day', '02', 0, 0, 0), 
('day', '03', 0, 0, 0), 
('day', '04', 0, 0, 0), 
('day', '05', 0, 0, 0), 
('day', '06', 0, 0, 0), 
('day', '07', 0, 0, 0), 
('day', '08', 0, 0, 0), 
('day', '09', 0, 0, 0), 
('day', '10', 0, 0, 0), 
('day', '11', 0, 0, 0), 
('day', '12', 0, 0, 0), 
('day', '13', 0, 0, 0), 
('day', '14', 0, 0, 0), 
('day', '15', 0, 0, 0), 
('day', '16', 0, 0, 0), 
('day', '17', 0, 0, 0), 
('day', '18', 0, 0, 0), 
('day', '19', 1421641000, 3, 3), 
('day', '20', 0, 0, 0), 
('day', '21', 1421814073, 7, 7), 
('day', '22', 1421920260, 4, 4), 
('day', '23', 1421988431, 3, 3), 
('day', '24', 0, 0, 0), 
('day', '25', 0, 0, 0), 
('day', '26', 0, 0, 0), 
('day', '27', 1422321791, 1, 1), 
('day', '28', 0, 0, 0), 
('day', '29', 0, 0, 0), 
('day', '30', 0, 0, 0), 
('day', '31', 0, 0, 0), 
('dayofweek', 'Sunday', 0, 0, 0), 
('dayofweek', 'Monday', 1421641000, 3, 3), 
('dayofweek', 'Tuesday', 1422321791, 1, 1), 
('dayofweek', 'Wednesday', 1421814073, 7, 7), 
('dayofweek', 'Thursday', 1421920260, 4, 4), 
('dayofweek', 'Friday', 1421988431, 3, 3), 
('dayofweek', 'Saturday', 0, 0, 0), 
('hour', '00', 0, 0, 0), 
('hour', '01', 0, 0, 0), 
('hour', '02', 0, 0, 0), 
('hour', '03', 0, 0, 0), 
('hour', '04', 0, 0, 0), 
('hour', '05', 0, 0, 0), 
('hour', '06', 0, 0, 0), 
('hour', '07', 0, 0, 0), 
('hour', '08', 1422321791, 1, 1), 
('hour', '09', 1421809156, 0, 0), 
('hour', '10', 1421983461, 0, 0), 
('hour', '11', 1421988431, 0, 0), 
('hour', '12', 0, 0, 0), 
('hour', '13', 0, 0, 0), 
('hour', '14', 1421912556, 0, 0), 
('hour', '15', 0, 0, 0), 
('hour', '16', 1421920260, 0, 0), 
('hour', '17', 0, 0, 0), 
('hour', '18', 0, 0, 0), 
('hour', '19', 0, 0, 0), 
('hour', '20', 0, 0, 0), 
('hour', '21', 0, 0, 0), 
('hour', '22', 0, 0, 0), 
('hour', '23', 0, 0, 0), 
('bot', 'Alexa', 0, 0, 0), 
('bot', 'AltaVista Scooter', 0, 0, 0), 
('bot', 'Altavista Mercator', 0, 0, 0), 
('bot', 'Altavista Search', 0, 0, 0), 
('bot', 'Aport.ru Bot', 0, 0, 0), 
('bot', 'Ask Jeeves', 0, 0, 0), 
('bot', 'Baidu', 0, 0, 0), 
('bot', 'Exabot', 0, 0, 0), 
('bot', 'FAST Enterprise', 0, 0, 0), 
('bot', 'FAST WebCrawler', 0, 0, 0), 
('bot', 'Francis', 0, 0, 0), 
('bot', 'Gigablast', 0, 0, 0), 
('bot', 'Google AdsBot', 0, 0, 0), 
('bot', 'Google Adsense', 0, 0, 0), 
('bot', 'Google Bot', 0, 0, 0), 
('bot', 'Google Desktop', 0, 0, 0), 
('bot', 'Google Feedfetcher', 0, 0, 0), 
('bot', 'Heise IT-Markt', 0, 0, 0), 
('bot', 'Heritrix', 0, 0, 0), 
('bot', 'IBM Research', 0, 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0, 0), 
('bot', 'Ichiro', 0, 0, 0), 
('bot', 'InfoSeek Spider', 0, 0, 0), 
('bot', 'Lycos.com Bot', 0, 0, 0), 
('bot', 'MSN Bot', 0, 0, 0), 
('bot', 'MSN Bot Media', 0, 0, 0), 
('bot', 'MSN Bot News', 0, 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0, 0), 
('bot', 'Majestic-12', 0, 0, 0), 
('bot', 'Metager', 0, 0, 0), 
('bot', 'NG-Search', 0, 0, 0), 
('bot', 'Nutch Bot', 0, 0, 0), 
('bot', 'NutchCVS', 0, 0, 0), 
('bot', 'OmniExplorer', 0, 0, 0), 
('bot', 'Online Link Validator', 0, 0, 0), 
('bot', 'Open-source Web Search', 0, 0, 0), 
('bot', 'Psbot', 0, 0, 0), 
('bot', 'Rambler', 0, 0, 0), 
('bot', 'SEO Crawler', 0, 0, 0), 
('bot', 'SEOSearch', 0, 0, 0), 
('bot', 'Seekport', 0, 0, 0), 
('bot', 'Sensis', 0, 0, 0), 
('bot', 'Seoma', 0, 0, 0), 
('bot', 'Snappy', 0, 0, 0), 
('bot', 'Steeler', 0, 0, 0), 
('bot', 'Synoo', 0, 0, 0), 
('bot', 'Telekom', 0, 0, 0), 
('bot', 'TurnitinBot', 0, 0, 0), 
('bot', 'Vietnamese Search', 0, 0, 0), 
('bot', 'Voyager', 0, 0, 0), 
('bot', 'W3 Sitesearch', 0, 0, 0), 
('bot', 'W3C Linkcheck', 0, 0, 0), 
('bot', 'W3C Validator', 0, 0, 0), 
('bot', 'WiseNut', 0, 0, 0), 
('bot', 'YaCy', 0, 0, 0), 
('bot', 'Yahoo Bot', 0, 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0, 0), 
('bot', 'Yahoo Slurp', 0, 0, 0), 
('bot', 'YahooSeeker', 0, 0, 0), 
('bot', 'Yandex', 0, 0, 0), 
('bot', 'Yandex Blog', 0, 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0, 0), 
('bot', 'Yandex Something', 0, 0, 0), 
('browser', 'netcaptor', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'aol', 0, 0, 0), 
('browser', 'aol2', 0, 0, 0), 
('browser', 'mosaic', 0, 0, 0), 
('browser', 'k-meleon', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'avantbrowser', 0, 0, 0), 
('browser', 'avantgo', 0, 0, 0), 
('browser', 'proxomitron', 0, 0, 0), 
('browser', 'chrome', 1421912556, 12, 12), 
('browser', 'safari', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'links', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'abrowse', 0, 0, 0), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'ant', 0, 0, 0), 
('browser', 'aweb', 0, 0, 0), 
('browser', 'beonex', 0, 0, 0), 
('browser', 'blazer', 0, 0, 0), 
('browser', 'camino', 0, 0, 0), 
('browser', 'chimera', 0, 0, 0), 
('browser', 'columbus', 0, 0, 0), 
('browser', 'crazybrowser', 0, 0, 0), 
('browser', 'curl', 0, 0, 0), 
('browser', 'deepnet', 0, 0, 0), 
('browser', 'dillo', 0, 0, 0), 
('browser', 'doris', 0, 0, 0), 
('browser', 'elinks', 0, 0, 0), 
('browser', 'epiphany', 0, 0, 0), 
('browser', 'ibrowse', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'ice', 0, 0, 0), 
('browser', 'isilox', 0, 0, 0), 
('browser', 'lotus', 0, 0, 0), 
('browser', 'lunascape', 0, 0, 0), 
('browser', 'maxthon', 0, 0, 0), 
('browser', 'mbrowser', 0, 0, 0), 
('browser', 'multibrowser', 0, 0, 0), 
('browser', 'nautilus', 0, 0, 0), 
('browser', 'netfront', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'oregano', 0, 0, 0), 
('browser', 'phaseout', 0, 0, 0), 
('browser', 'plink', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'shiira', 0, 0, 0), 
('browser', 'sleipnir', 0, 0, 0), 
('browser', 'slimbrowser', 0, 0, 0), 
('browser', 'staroffice', 0, 0, 0), 
('browser', 'sunrise', 0, 0, 0), 
('browser', 'voyager', 0, 0, 0), 
('browser', 'w3m', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'xiino', 0, 0, 0), 
('browser', 'explorer', 0, 0, 0), 
('browser', 'firefox', 1422321791, 6, 6), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'netscape2', 0, 0, 0), 
('browser', 'mozilla', 0, 0, 0), 
('browser', 'mozilla2', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 0, 0, 0), 
('browser', 'Unspecified', 0, 0, 0), 
('os', 'windows8', 0, 0, 0), 
('os', 'windows7', 0, 0, 0), 
('os', 'windowsvista', 0, 0, 0), 
('os', 'windows2003', 0, 0, 0), 
('os', 'windowsxp', 0, 0, 0), 
('os', 'windowsxp2', 0, 0, 0), 
('os', 'windows2k', 0, 0, 0), 
('os', 'windows95', 0, 0, 0), 
('os', 'windowsce', 0, 0, 0), 
('os', 'windowsme', 0, 0, 0), 
('os', 'windowsme2', 0, 0, 0), 
('os', 'windowsnt', 0, 0, 0), 
('os', 'windowsnt2', 1422321791, 18, 18), 
('os', 'windows98', 0, 0, 0), 
('os', 'windows', 0, 0, 0), 
('os', 'linux', 0, 0, 0), 
('os', 'linux2', 0, 0, 0), 
('os', 'linux3', 0, 0, 0), 
('os', 'macosx', 0, 0, 0), 
('os', 'macppc', 0, 0, 0), 
('os', 'mac', 0, 0, 0), 
('os', 'amiga', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'freebsd2', 0, 0, 0), 
('os', 'irix', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'netbsd2', 0, 0, 0), 
('os', 'os2', 0, 0, 0), 
('os', 'os22', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'openbsd2', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('os', 'palm2', 0, 0, 0), 
('os', 'Unspecified', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 0, 0, 0), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 0, 0, 0), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 0, 0, 0), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 0, 0, 0), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 0, 0, 0), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 0, 0, 0), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 0, 0, 0), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 0, 0, 0), 
('country', 'RU', 0, 0, 0), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 0, 0, 0), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 0, 0, 0), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1422321791, 18, 18), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_cronjobs`
--

DROP TABLE IF EXISTS `nv4_cronjobs`;
CREATE TABLE `nv4_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_cronjobs`
--

INSERT INTO `nv4_cronjobs` VALUES
(1, 1421635014, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1422321794, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1421635014, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1421910580, 1, 'Tự động lưu CSDL'), 
(3, 1421635014, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1421988432, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1421635014, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1421990237, 1, 'Xóa IP log files Xóa các file logo truy cập'), 
(5, 1421635014, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1421910580, 1, 'Xóa các file error_log quá hạn'), 
(6, 1421635014, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1421635014, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1421988432, 1, 'Xóa các referer quá hạn'), 
(8, 1421635014, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 0, 1, 1421910580, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1421635014, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1421983246, 1, 'Kiểm tra phiên bản NukeViet');


-- ---------------------------------------


--
-- Table structure for table `nv4_googleplus`
--

DROP TABLE IF EXISTS `nv4_googleplus`;
CREATE TABLE `nv4_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `idprofile` varchar(25) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_groups`
--

DROP TABLE IF EXISTS `nv4_groups`;
CREATE TABLE `nv4_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `publics` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups`
--

INSERT INTO `nv4_groups` VALUES
(6, 'All', '', 1421635014, 0, 0, 1, 1, 0, 0, 0), 
(5, 'Guest', '', 1421635014, 0, 0, 2, 1, 0, 0, 0), 
(4, 'Users', '', 1421635014, 0, 0, 3, 1, 0, 1, 0), 
(1, 'Super admin', '', 1421635014, 0, 0, 4, 1, 0, 1, 0), 
(2, 'General admin', '', 1421635014, 0, 0, 5, 1, 0, 0, 0), 
(3, 'Module admin', '', 1421635014, 0, 0, 6, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_groups_users`
--

DROP TABLE IF EXISTS `nv4_groups_users`;
CREATE TABLE `nv4_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups_users`
--

INSERT INTO `nv4_groups_users` VALUES
(1, 1, '0');


-- ---------------------------------------


--
-- Table structure for table `nv4_language`
--

DROP TABLE IF EXISTS `nv4_language`;
CREATE TABLE `nv4_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_language_file`
--

DROP TABLE IF EXISTS `nv4_language_file`;
CREATE TABLE `nv4_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_logs`
--

DROP TABLE IF EXISTS `nv4_logs`;
CREATE TABLE `nv4_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=69  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_logs`
--

INSERT INTO `nv4_logs` VALUES
(1, 'vi', 'login', '[admin@gmail.com] Đăng nhập', ' Client IP:::1', '', 0, 1421635070), 
(2, 'vi', 'themes', 'Kích hoạt theme: \"ala\"', '', '', 1, 1421635141), 
(3, 'vi', 'themes', 'Thêm block', 'Name : global menutop', '', 1, 1421635212), 
(4, 'vi', 'themes', 'Thêm block', 'Name : global banner', '', 1, 1421635222), 
(5, 'vi', 'themes', 'Thêm block', 'Name : global hotro', '', 1, 1421635232), 
(6, 'vi', 'themes', 'Thêm block', 'Name : global dannhmuc', '', 1, 1421635252), 
(7, 'vi', 'themes', 'Thêm block', 'Name : global sanpham', '', 1, 1421635265), 
(8, 'vi', 'themes', 'Thêm block', 'Name : global thongtin', '', 1, 1421635283), 
(9, 'vi', 'themes', 'Thêm block', 'Name : global coppyright', '', 1, 1421635294), 
(10, 'vi', 'modules', 'Cài đặt gói Module + Block', 'module-shops-master.zip', '', 1, 1421635800), 
(11, 'vi', 'modules', 'Thiết lập module mới shops', '', '', 1, 1421635856), 
(12, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1421635859), 
(13, 'vi', 'modules', 'Thiết lập module mới make-theme', '', '', 1, 1421635897), 
(14, 'vi', 'modules', 'Sửa module &ldquo;make-theme&rdquo;', '', '', 1, 1421635900), 
(15, 'vi', 'modules', 'Sửa module &ldquo;make-theme&rdquo;', '', '', 1, 1421635935), 
(16, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421635954), 
(17, 'vi', 'themes', 'Kích hoạt theme: \"ala\"', '', '', 1, 1421635997), 
(18, 'vi', 'modules', 'Xóa module \"make-theme\"', '', '', 1, 1421636031), 
(19, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1421636047), 
(20, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421636080), 
(21, 'vi', 'modules', 'Thiết lập module mới shops', '', '', 1, 1421636097), 
(22, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1421636112), 
(23, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1421636135), 
(24, 'vi', 'modules', 'Thiết lập module mới make-theme', '', '', 1, 1421636267), 
(25, 'vi', 'modules', 'Sửa module &ldquo;make-theme&rdquo;', '', '', 1, 1421636269), 
(26, 'vi', 'modules', 'Cài đặt gói Module + Block', 'module-shops-develop.zip', '', 1, 1421636369), 
(27, 'vi', 'modules', 'Cài đặt gói Module + Block', 'module-shops-develop.zip', '', 1, 1421636450), 
(28, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1421637014), 
(29, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1421637022), 
(30, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1421637026), 
(31, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1421637348), 
(32, 'vi', 'modules', 'Thiết lập module mới shops', '', '', 1, 1421637357), 
(33, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1421637361), 
(34, 'vi', 'themes', 'Kích hoạt theme: \"ala\"', '', '', 1, 1421637389), 
(35, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421637395), 
(36, 'vi', 'modules', 'Cài lại module \"shops\"', '', '', 1, 1421637450), 
(37, 'vi', 'modules', 'Xóa module \"shops\"', '', '', 1, 1421637601), 
(38, 'vi', 'modules', 'Cài đặt gói Module + Block', 'module-shops-develop.zip', '', 1, 1421639142), 
(39, 'vi', 'modules', 'Cài đặt gói Module + Block', 'packet news', '', 1, 1421639186), 
(40, 'vi', 'modules', 'Cài đặt gói Module + Block', 'module-shops-develop.zip', '', 1, 1421639248), 
(41, 'vi', 'modules', 'Cài đặt gói Module + Block', 'module-shops-develop.zip', '', 1, 1421642174), 
(42, 'vi', 'modules', 'Thiết lập module mới shops', '', '', 1, 1421642202), 
(43, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1421642227), 
(44, 'vi', 'themes', 'Kích hoạt theme: \"ala\"', '', '', 1, 1421642349), 
(45, 'vi', 'login', '[admin@gmail.com] Đăng nhập', ' Client IP:::1', '', 0, 1421805160), 
(46, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1421805192), 
(47, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421805219), 
(48, 'vi', 'themes', 'Cài đặt theme lên hệ thống', 'file name : nv4_theme_xe.zip', '', 1, 1421807498), 
(49, 'vi', 'themes', 'Kích hoạt theme: \"xe\"', '', '', 1, 1421807536), 
(50, 'vi', 'login', '[admin@gmail.com] Đăng nhập', ' Client IP:::1', '', 0, 1421910614), 
(51, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421910631), 
(52, 'vi', 'themes', 'Kích hoạt theme: \"xe\"', '', '', 1, 1421910693), 
(53, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421910719), 
(54, 'vi', 'themes', 'Kích hoạt theme: \"ala\"', '', '', 1, 1421911545), 
(55, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421911811), 
(56, 'vi', 'themes', 'Kích hoạt theme: \"ala\"', '', '', 1, 1421912099), 
(57, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421912139), 
(58, 'vi', 'themes', 'Thêm block', 'Name : global test', '', 1, 1421912178), 
(59, 'vi', 'themes', 'Kích hoạt theme: \"xe\"', '', '', 1, 1421912326), 
(60, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1421918424), 
(61, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1421918454), 
(62, 'vi', 'themes', 'Thêm block', 'Name : global test', '', 1, 1421918478), 
(63, 'vi', 'themes', 'Thêm block', 'Name : global test', '', 1, 1421918802), 
(64, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1421920415), 
(65, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1421983254), 
(66, 'vi', 'modules', 'Cài đặt gói Module + Block', 'module-nvtools-master.zip', '', 1, 1421983345), 
(67, 'vi', 'modules', 'Thiết lập module mới nvtools', '', '', 1, 1421983387), 
(68, 'vi', 'modules', 'Sửa module &ldquo;nvtools&rdquo;', '', '', 1, 1421983402);


-- ---------------------------------------


--
-- Table structure for table `nv4_plugin`
--

DROP TABLE IF EXISTS `nv4_plugin`;
CREATE TABLE `nv4_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50) NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_sessions`
--

DROP TABLE IF EXISTS `nv4_sessions`;
CREATE TABLE `nv4_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_sessions`
--

INSERT INTO `nv4_sessions` VALUES
('vkufdh15g8tb1a7q200s4n84h0', 0, 'guest', 1422321791);


-- ---------------------------------------


--
-- Table structure for table `nv4_setup`
--

DROP TABLE IF EXISTS `nv4_setup`;
CREATE TABLE `nv4_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_extensions`
--

DROP TABLE IF EXISTS `nv4_setup_extensions`;
CREATE TABLE `nv4_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50) NOT NULL DEFAULT '',
  `table_prefix` varchar(55) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_extensions`
--

INSERT INTO `nv4_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'make-theme', 0, 0, 'make-theme', 'make_theme', '4.0.1 1373447732', 1421635851, 'VINADES (contact@vinades.vn)', ''), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 0, 'users', 'users', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(25, 'module', 'download', 0, 1, 'download', 'download', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 1, 'menu', 'menu', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.00 1393416212', 1421635014, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'shops', 0, 1, 'shops', 'shops', '4.0.00 1371948600', 1421642196, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'nvtools', 0, 0, 'nvtools', 'nvtools', '4.0.0 1300553445', 1421983383, 'VINADES (contact@vinades.vn)', 'Công cụ xây dựng site');


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_language`
--

DROP TABLE IF EXISTS `nv4_setup_language`;
CREATE TABLE `nv4_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_language`
--

INSERT INTO `nv4_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_block`
--

DROP TABLE IF EXISTS `nv4_shops_block`;
CREATE TABLE `nv4_shops_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_block_cat`
--

DROP TABLE IF EXISTS `nv4_shops_block_cat`;
CREATE TABLE `nv4_shops_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_catalogs`
--

DROP TABLE IF EXISTS `nv4_shops_catalogs`;
CREATE TABLE `nv4_shops_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(4) NOT NULL DEFAULT '3',
  `form` varchar(50) NOT NULL DEFAULT '',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons`
--

DROP TABLE IF EXISTS `nv4_shops_coupons`;
CREATE TABLE `nv4_shops_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `code` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(1) NOT NULL DEFAULT 'p',
  `discount` float NOT NULL DEFAULT '0',
  `total_amount` float NOT NULL DEFAULT '0',
  `free_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `date_start` int(11) unsigned NOT NULL DEFAULT '0',
  `date_end` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon_count` int(11) NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons_history`
--

DROP TABLE IF EXISTS `nv4_shops_coupons_history`;
CREATE TABLE `nv4_shops_coupons_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons_product`
--

DROP TABLE IF EXISTS `nv4_shops_coupons_product`;
CREATE TABLE `nv4_shops_coupons_product` (
  `cid` int(11) unsigned NOT NULL,
  `pid` int(11) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_discounts`
--

DROP TABLE IF EXISTS `nv4_shops_discounts`;
CREATE TABLE `nv4_shops_discounts` (
  `did` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `begin_time` int(11) unsigned NOT NULL DEFAULT '0',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  PRIMARY KEY (`did`),
  KEY `begin_time` (`begin_time`,`end_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_field`
--

DROP TABLE IF EXISTS `nv4_shops_field`;
CREATE TABLE `nv4_shops_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `listtemplate` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group`
--

DROP TABLE IF EXISTS `nv4_shops_group`;
CREATE TABLE `nv4_shops_group` (
  `groupid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `cateid` int(11) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewgroup` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL DEFAULT '0',
  `subgroupid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `numpro` int(11) unsigned NOT NULL DEFAULT '0',
  `in_order` tinyint(2) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_info`
--

DROP TABLE IF EXISTS `nv4_shops_info`;
CREATE TABLE `nv4_shops_info` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `shopid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_items_group`
--

DROP TABLE IF EXISTS `nv4_shops_items_group`;
CREATE TABLE `nv4_shops_items_group` (
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `group_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pro_id`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_money_vi`
--

DROP TABLE IF EXISTS `nv4_shops_money_vi`;
CREATE TABLE `nv4_shops_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  `round` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_money_vi`
--

INSERT INTO `nv4_shops_money_vi` VALUES
(840, 'USD', 'US Dollar', '21000', '0.01'), 
(704, 'VND', 'Vietnam Dong', '1', '100');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders`
--

DROP TABLE IF EXISTS `nv4_shops_orders`;
CREATE TABLE `nv4_shops_orders` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_code` varchar(30) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT 'en',
  `order_name` varchar(255) NOT NULL,
  `order_email` varchar(255) NOT NULL,
  `order_address` text NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_note` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0',
  `shop_id` int(11) unsigned NOT NULL DEFAULT '0',
  `who_is` int(2) unsigned NOT NULL DEFAULT '0',
  `unit_total` char(3) NOT NULL,
  `order_total` double unsigned NOT NULL DEFAULT '0',
  `order_time` int(11) unsigned NOT NULL DEFAULT '0',
  `postip` varchar(100) NOT NULL,
  `order_view` tinyint(2) NOT NULL DEFAULT '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL DEFAULT '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders_id`
--

DROP TABLE IF EXISTS `nv4_shops_orders_id`;
CREATE TABLE `nv4_shops_orders_id` (
  `order_id` int(11) NOT NULL,
  `id` mediumint(9) NOT NULL,
  `num` mediumint(9) NOT NULL,
  `price` int(11) NOT NULL,
  `group_id` mediumint(8) NOT NULL,
  UNIQUE KEY `orderid` (`order_id`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_payment`
--

DROP TABLE IF EXISTS `nv4_shops_payment`;
CREATE TABLE `nv4_shops_payment` (
  `payment` varchar(100) NOT NULL,
  `paymentname` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  `images_button` varchar(255) NOT NULL,
  PRIMARY KEY (`payment`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_rows`
--

DROP TABLE IF EXISTS `nv4_shops_rows`;
CREATE TABLE `nv4_shops_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` int(11) NOT NULL DEFAULT '0',
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `product_code` varchar(255) NOT NULL DEFAULT '',
  `product_number` int(11) NOT NULL DEFAULT '0',
  `product_price` float NOT NULL DEFAULT '0',
  `money_unit` char(3) NOT NULL,
  `product_unit` int(11) NOT NULL,
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `homeimgalt` varchar(255) NOT NULL,
  `otherimage` text NOT NULL,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_sell` mediumint(8) NOT NULL DEFAULT '0',
  `showprice` tinyint(2) NOT NULL DEFAULT '0',
  `custom` text NOT NULL,
  `vat` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `typeproduct` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `new_old` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `percentnew` tinyint(2) unsigned NOT NULL DEFAULT '90',
  `adddefaul` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_hometext` text NOT NULL,
  `vi_bodytext` mediumtext NOT NULL,
  `vi_warranty` text NOT NULL,
  `vi_promotional` text NOT NULL,
  `vi_custom` text NOT NULL,
  `vi_address` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `listcatid` (`listcatid`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_tags`
--

DROP TABLE IF EXISTS `nv4_shops_tags`;
CREATE TABLE `nv4_shops_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vi_numpro` mediumint(8) NOT NULL DEFAULT '0',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_image` varchar(255) DEFAULT '',
  `vi_description` text,
  `vi_keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_tags_id`
--

DROP TABLE IF EXISTS `nv4_shops_tags_id`;
CREATE TABLE `nv4_shops_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `vi_keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_template`
--

DROP TABLE IF EXISTS `nv4_shops_template`;
CREATE TABLE `nv4_shops_template` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_transaction`
--

DROP TABLE IF EXISTS `nv4_shops_transaction`;
CREATE TABLE `nv4_shops_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_time` int(11) NOT NULL DEFAULT '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `payment` varchar(100) NOT NULL DEFAULT '0',
  `payment_id` varchar(22) NOT NULL DEFAULT '0',
  `payment_time` int(11) NOT NULL DEFAULT '0',
  `payment_amount` int(11) NOT NULL DEFAULT '0',
  `payment_data` text NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_units`
--

DROP TABLE IF EXISTS `nv4_shops_units`;
CREATE TABLE `nv4_shops_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_wishlist`
--

DROP TABLE IF EXISTS `nv4_shops_wishlist`;
CREATE TABLE `nv4_shops_wishlist` (
  `wid` smallint(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `listid` text,
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_dir`
--

DROP TABLE IF EXISTS `nv4_upload_dir`;
CREATE TABLE `nv4_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=38  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_upload_dir`
--

INSERT INTO `nv4_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'images', 0, 0, 0, 0, 0), 
(2, 'images/rank', 0, 0, 0, 0, 0), 
(3, 'uploads', 0, 0, 0, 0, 0), 
(4, 'uploads/about', 0, 0, 0, 0, 0), 
(5, 'uploads/banners', 0, 0, 0, 0, 0), 
(6, 'uploads/contact', 0, 0, 0, 0, 0), 
(8, 'uploads/menu', 0, 0, 0, 0, 0), 
(9, 'uploads/news', 0, 0, 0, 0, 0), 
(10, 'uploads/news/source', 0, 0, 0, 0, 0), 
(11, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(12, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(13, 'uploads/page', 0, 0, 0, 0, 0), 
(14, 'uploads/users', 0, 0, 0, 0, 0), 
(37, 'uploads/nvtools', 0, 0, 0, 0, 0), 
(36, 'uploads/shops/2015_01', 0, 0, 0, 0, 0), 
(35, 'uploads/shops/temp_pic', 0, 0, 0, 0, 0), 
(27, 'uploads/make-theme', 0, 0, 0, 0, 0), 
(34, 'uploads/shops', 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_file`
--

DROP TABLE IF EXISTS `nv4_upload_file`;
CREATE TABLE `nv4_upload_file` (
  `name` varchar(255) NOT NULL,
  `ext` varchar(10) NOT NULL DEFAULT '',
  `type` varchar(5) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255) NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alt` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users`
--

DROP TABLE IF EXISTS `nv4_users`;
CREATE TABLE `nv4_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `gender` char(1) DEFAULT '',
  `photo` varchar(255) DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(50) DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  `last_openid` varchar(255) DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users`
--

INSERT INTO `nv4_users` VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '4abb85773c0cc60c0daf8c8de8676b67aa76d230', 'admin@gmail.com', 'admin', '', '', 0, '', 1421635052, '1', '1', '', 0, 1, '', 1, '', 1421635052, '', '', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_config`
--

DROP TABLE IF EXISTS `nv4_users_config`;
CREATE TABLE `nv4_users_config` (
  `config` varchar(100) NOT NULL,
  `content` text,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_config`
--

INSERT INTO `nv4_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|654321|696969|1234567|12345678|123456789|1234567890|aaaaaa|abc123|abc123@|abc@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman', 1421635014), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1421635014), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1421635014), 
('avatar_width', '80', 1421635014), 
('avatar_height', '80', 1421635014), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_field`
--

DROP TABLE IF EXISTS `nv4_users_field`;
CREATE TABLE `nv4_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50) NOT NULL,
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_info`
--

DROP TABLE IF EXISTS `nv4_users_info`;
CREATE TABLE `nv4_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_info`
--

INSERT INTO `nv4_users_info` VALUES
(1);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_openid`
--

DROP TABLE IF EXISTS `nv4_users_openid`;
CREATE TABLE `nv4_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_question`
--

DROP TABLE IF EXISTS `nv4_users_question`;
CREATE TABLE `nv4_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_question`
--

INSERT INTO `nv4_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_reg`
--

DROP TABLE IF EXISTS `nv4_users_reg`;
CREATE TABLE `nv4_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  `users_info` text,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about`
--

DROP TABLE IF EXISTS `nv4_vi_about`;
CREATE TABLE `nv4_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_about`
--

INSERT INTO `nv4_vi_about` VALUES
(1, 'Giới thiệu về NukeViet 3.0', 'Gioi-thieu-ve-NukeViet-3-0', '', '', '', '<p> NukeViet 3.0 là thế hệ CMS hoàn toàn mới do người Việt phát triển. Lần đầu tiên ở Việt Nam, một bộ nhân mã nguồn mở được đầu tư bài bản và chuyên nghiệp cả về tài chính, nhân lực và thời gian. Kết quả là 100% dòng code của NukeViet được viết mới hoàn toàn, NukeViet 3 sử dụng xHTML, CSS với Xtemplate và jquery cho phép vận dụng Ajax uyển chuyển cả trong công nghệ nhân.</p><p> Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 3 vẫn đảm bảo rằng từng dòng code là được code tay (NukeViet 3 không sử dụng bất cứ một nền tảng (framework) nào). Điều này có nghĩa là NukeViet 3 hoàn toàn không phụ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 3 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 3 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).</p><p style=\"text-align: justify;\"> Bộ nhân NukeViet 3 ngoài việc thừa hưởng sự đơn giản vốn có của NukeViet nhưng không vì thế mà quên nâng cấp mình. Hệ thống NukeViet 3 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</p><p style=\"text-align: justify;\"> NukeViet 3 cũng hỗ trợ việc cài đặt từ động 100% các module, block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 3 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</p><p style=\"text-align: justify;\"> NukeViet 3 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ database. NukeViet 3 có tính năng&nbsp; cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho&nbsp; phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng... câu chuyện về nukeviet 3 sẽ còn dài vì một loạt các tính năng cao cấp vẫn đang được phát triển. Hãy sử dụng và phổ biến NukeViet 3 để tự mình tận hưởng những thành quả mới nhất từ công nghệ web mã nguồn mở. Cuối cùng NukeViet 3 là món của của <a href=\"http://vinades.vn\" target=\"_blank\">VINADES.,JSC</a> gửi tới cộng đồng để cảm ơn cộng đồng đã ủng hộ thời gian qua, bây giờ NukeViet 3 được đưa trở lại cộng đồng để cộng đồng tiếp tục nuôi nấng và chăm sóc NukeViet lớn mạnh hơn.</p><p style=\"text-align: justify;\"> Mọi ý kiến và yêu cầu trợ giúp về NukeViet 3 các bạn có thể gửi lên diễn đàn NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn/phpbb/\" target=\"_blank\">http://nukeviet.vn/phpbb/</a>. Việc giúp đỡ hoàn toàn miễn phí và mọi góp ý của bạn đều được hoan nghênh.</p> <div style=\"text-align: center;\"> <object height=\"400\" width=\"480\"><param name=\"movie\" value=\"//www.youtube.com/v/dG66RocXSeY?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" /><param name=\"allowFullScreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><embed allowfullscreen=\"true\" allowscriptaccess=\"always\" height=\"400\" src=\"//www.youtube.com/v/dG66RocXSeY?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" type=\"application/x-shockwave-flash\" width=\"480\"></embed></object>	<br /> Video clip Giới thiệu mã nguồn mở NukeViet trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</div>', '', 0, '4', '', 0, 1, 1, 1275320174, 1275320174, 1), 
(2, 'Giới thiệu về công ty chuyên quản NukeViet', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '', '', '', '<p style=\"text-align: justify;\"> <strong>Công ty cổ phần phát triển nguồn mở Việt Nam</strong> (VINADES.,JSC) là công ty mã nguồn mở đầu tiên của Việt Nam sở hữu riêng một mã nguồn mở nổi tiếng và đang được sử dụng ở hàng ngàn website lớn nhỏ trong mọi lĩnh vực.<br /> <br /> Ra đời từ hoạt động của tổ chức nguồn mở NukeViet (từ năm 2004) và chính thức được thành lập đầu 2010 tại Hà Nội, khi đó báo chí đã gọi VINADES.,JSC là &quot;Công ty mã nguồn mở đầu tiên tại Việt Nam&quot;.<br /> <br /> Ngay sau khi thành lập, VINADES.,JSC đã thành công trong việc xây dựng <strong><a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a></strong> thành một <a href=\"http://nukeviet.vn/\" target=\"_blank\">mã nguồn mở</a> thuần Việt. Với khả năng mạnh mẽ, cùng các ưu điểm vượt trội về công nghệ, độ an toàn và bảo mật, NukeViet đã được hàng ngàn website lựa chọn sử dụng trong năm qua. Ngay khi ra mắt phiên bản mới năm 2010, NukeViet đã tạo nên hiệu ứng truyền thông chưa từng có trong lịch sử mã nguồn mở Việt Nam. Tiếp đó, năm 2011 Mã nguồn mở NukeViet đã giành giải thưởng Nhân tài đất Việt cho sản phẩm Công nghệ thông tin đã được ứng dụng rộng rãi.<br /></p><div style=\"text-align: center;\"> <object height=\"400\" width=\"480\"><param name=\"movie\" value=\"//www.youtube.com/v/ZOhu2bLE-eA?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" /><param name=\"allowFullScreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><embed allowfullscreen=\"true\" allowscriptaccess=\"always\" height=\"400\" src=\"//www.youtube.com/v/ZOhu2bLE-eA?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" type=\"application/x-shockwave-flash\" width=\"480\"></embed></object><br /> <strong>Video clip trao giải Nhân tài đất Việt 2011.</strong><br /> Sản phẩm &quot;Mã nguồn mở NukeViet&quot; đã nhận giải cao nhất (Giải ba, không có giải nhất, giải nhì) của Giải thưởng Nhân Tài Đất Việt 2011 ở lĩnh vực Công nghệ thông tin - Sản phẩm đã có ứng dụng rộng rãi.</div><p style=\"text-align: justify;\"><br /> Tự chuyên nghiệp hóa mình, thoát khỏi mô hình phát triển tự phát, công ty đã nỗ lực vươn mình ra thế giới và đang phấn đấu trở thành một trong những hiện tượng của thời &quot;dotcom&quot; ở Việt Nam.<br /> <br /> Để phục vụ hoạt động của công ty, công ty liên tục mở rộng và tuyển thêm nhân sự ở các vị trí: Lập trình viên, chuyên viên đồ họa, nhân viên kinh doanh... Hãy liên hệ ngay để gia nhập VINADES.,JSC và cùng chúng tôi trở thành một công ty phát triển nguồn mở thành công nhất Việt Nam.</p> <p>Nếu bạn có nhu cầu triển khai các hệ thống <a href=\"http://toasoandientu.vn\" target=\"_blank\">Tòa Soạn Điện Tử</a>, <a href=\"http://webnhanh.vn\" target=\"_blank\">phần mềm trực tuyến</a>, <a href=\"http://vinades.vn\" target=\"_blank\">thiết kế web</a> theo yêu cầu hoặc dịch vụ có liên quan, hãy liên hệ công ty chuyên quản NukeViet theo thông tin dưới đây:</p><p><strong><span style=\"font-family: Tahoma; color: rgb(255, 69, 0); font-size: 14px;\">CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM</span></strong><br /> <strong>VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY</strong> (<strong>VINADES.,JSC</strong>)<br />Website: <a href=\"http://vinades.vn/\">http://vinades.vn</a> | <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a> | <a href=\"http://webnhanh.vn/\">http://webnhanh.vn</a><br />Trụ sở: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br /> - Tel: +84-4-85872007<br /> - Fax: +84-4-35500914<br /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', '', 0, '4', '', 0, 2, 1, 1275320224, 1275320224, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about_config`
--

DROP TABLE IF EXISTS `nv4_vi_about_config`;
CREATE TABLE `nv4_vi_about_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_about_config`
--

INSERT INTO `nv4_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_groups`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_groups`;
CREATE TABLE `nv4_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=47  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_blocks_groups`
--

INSERT INTO `nv4_vi_blocks_groups` VALUES
(1, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, 1, '6', 1, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(2, 'default', 'statistics', 'global.counter.php', 'Thống kê truy cập', '', 'primary', '[LEFT]', 0, 1, '6', 1, 2, ''), 
(3, 'default', 'banners', 'global.banners.php', 'Quảng cáo trái', '', 'no_title', '[LEFT]', 0, 1, '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(4, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'border', '[RIGHT]', 0, 1, '6', 1, 1, ''), 
(5, 'default', 'users', 'global.login.php', 'Đăng nhập thành viên', '', 'primary', '[RIGHT]', 0, 1, '6', 1, 2, ''), 
(6, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', 'primary', '[RIGHT]', 0, 1, '6', 1, 3, ''), 
(7, 'default', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[TOP]', 0, 1, '6', 0, 1, 'a:3:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(8, 'default', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', '', 'no_title', '[TOP]', 0, 1, '6', 1, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(17, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(19, 'default', 'page', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:231:\"<p class=\"footer\"> © Copyright NukeViet 4. All right reserved.</p><p> Powered by <a href=\"http://nukeviet.vn/\" title=\"NukeViet CMS\">NukeViet CMS</a>. Design by <a href=\"http://vinades.vn/\" title=\"VINADES.,JSC\">VINADES.,JSC</a></p>\";}'), 
(21, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, 1, '6', 1, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(22, 'default', 'theme', 'global.menu_footer.php', 'Menu footer', '', 'no_title', '[MENU_FOOTER]', 0, 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:4:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";}}'), 
(9, 'modern', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[HEADER]', 0, 1, '6', 0, 1, 'a:3:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '6', 1, 1, ''), 
(11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '6', 1, 3, ''), 
(13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''), 
(14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '6', 0, 5, ''), 
(15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '6', 1, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(16, 'modern', 'menu', 'global.superfish.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(18, 'modern', 'page', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:274:\"© Copyright NukeViet 4. All right reserved.<br  />Xây dựng trên nền tảng <a href=\"http://nukeviet.vn/\" title=\"Mã nguồn mở NukeViet\">Mã nguồn mở NukeViet</a>. <a href=\"http://vinades.vn/\" title=\"Thiết kế web\">Thiết kế website</a> bởi VINADES.,JSC\";}'), 
(20, 'mobile_nukeviet', 'theme', 'global.menu.php', 'global menu', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:6:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:10:\"statistics\";i:5;s:6:\"voting\";}}'), 
(23, 'ala', 'theme', 'global.menutop.php', 'global menutop', '', 'no_title', '[MENUTOP]', 0, 1, '6', 1, 1, ''), 
(24, 'ala', 'theme', 'global.banner.php', 'global banner', '', 'no_title', '[BANNER]', 0, 1, '6', 1, 1, ''), 
(25, 'ala', 'theme', 'global.hotro.php', 'global hotro', '', 'no_title', '[HOTRO]', 0, 1, '6', 1, 1, ''), 
(26, 'ala', 'theme', 'global.dannhmuc.php', 'global dannhmuc', '', 'no_title', '[DANNHMUC]', 0, 1, '6', 1, 1, ''), 
(27, 'ala', 'theme', 'global.sanpham.php', 'global sanpham', '', 'no_title', '[SANPHAM]', 0, 1, '6', 1, 1, ''), 
(28, 'ala', 'theme', 'global.thongtin.php', 'global thongtin', '', 'no_title', '[THONGTIN]', 0, 1, '6', 1, 1, ''), 
(29, 'ala', 'theme', 'global.coppyright.php', 'global coppyright', '', 'no_title', '[COPPYRIGHT]', 0, 1, '6', 1, 1, ''), 
(30, 'xe', 'theme', 'global.headertop.php', 'global headertop', NULL, 'no_title', '[HEADERTOP]', 0, 1, '6', 1, 1, ''), 
(31, 'xe', 'theme', 'global.bannerright.php', 'global bannerright', NULL, 'no_title', '[BANNERRIGHT]', 0, 1, '6', 1, 1, ''), 
(32, 'xe', 'theme', 'global.navtop.php', 'global navtop', NULL, 'no_title', '[NAVTOP]', 0, 1, '6', 1, 1, ''), 
(33, 'xe', 'theme', 'global.navbottom.php', 'global navbottom', NULL, 'no_title', '[NAVBOTTOM]', 0, 1, '6', 1, 1, ''), 
(34, 'xe', 'theme', 'global.silde.php', 'global silde', NULL, 'no_title', '[SILDE]', 0, 1, '6', 1, 1, ''), 
(35, 'xe', 'theme', 'global.danhmuc.php', 'global danhmuc', NULL, 'no_title', '[DANHMUC]', 0, 1, '6', 1, 1, ''), 
(36, 'xe', 'theme', 'global.hotro.php', 'global hotro', NULL, 'no_title', '[HOTRO]', 0, 1, '6', 1, 1, ''), 
(37, 'xe', 'theme', 'global.lienket.php', 'global lienket', NULL, 'no_title', '[LIENKET]', 0, 1, '6', 1, 1, ''), 
(38, 'xe', 'theme', 'global.sanpham.php', 'global sanpham', NULL, 'no_title', '[SANPHAM]', 0, 1, '6', 1, 1, ''), 
(39, 'xe', 'theme', 'global.quangcao.php', 'global quangcao', NULL, 'no_title', '[QUANGCAO]', 0, 1, '6', 1, 1, ''), 
(40, 'xe', 'theme', 'global.tienich.php', 'global tienich', NULL, 'no_title', '[TIENICH]', 0, 1, '6', 1, 1, ''), 
(41, 'xe', 'theme', 'global.truycap.php', 'global truycap', NULL, 'no_title', '[TRUYCAP]', 0, 1, '6', 1, 1, ''), 
(42, 'xe', 'theme', 'global.navfooter.php', 'global navfooter', NULL, 'no_title', '[NAVFOOTER]', 0, 1, '6', 1, 1, ''), 
(43, 'xe', 'theme', 'global.footercontent.php', 'global footercontent', NULL, 'no_title', '[FOOTERCONTENT]', 0, 1, '6', 1, 1, ''), 
(46, 'default', 'theme', 'global.test.php', 'global test', '', '', '[HEADER]', 0, 1, '6', 1, 1, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_weight`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_weight`;
CREATE TABLE `nv4_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_blocks_weight`
--

INSERT INTO `nv4_vi_blocks_weight` VALUES
(19, 2, 1), 
(19, 36, 1), 
(19, 39, 1), 
(19, 42, 1), 
(19, 43, 1), 
(19, 54, 1), 
(19, 55, 1), 
(19, 56, 1), 
(19, 57, 1), 
(19, 27, 1), 
(19, 47, 1), 
(19, 11, 1), 
(19, 52, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 13, 1), 
(19, 15, 1), 
(19, 16, 1), 
(19, 51, 1), 
(19, 53, 1), 
(19, 46, 1), 
(19, 33, 1), 
(19, 32, 1), 
(19, 30, 1), 
(19, 29, 1), 
(19, 31, 1), 
(19, 28, 1), 
(19, 34, 1), 
(19, 24, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 26, 1), 
(19, 23, 1), 
(19, 18, 1), 
(19, 25, 1), 
(19, 17, 1), 
(19, 22, 1), 
(19, 19, 1), 
(19, 48, 1), 
(19, 50, 1), 
(19, 58, 1), 
(19, 35, 1), 
(1, 2, 1), 
(1, 36, 1), 
(1, 39, 1), 
(1, 42, 1), 
(1, 43, 1), 
(1, 54, 1), 
(1, 55, 1), 
(1, 56, 1), 
(1, 57, 1), 
(1, 27, 1), 
(1, 47, 1), 
(1, 11, 1), 
(1, 52, 1), 
(1, 5, 1), 
(1, 6, 1), 
(1, 7, 1), 
(1, 13, 1), 
(1, 15, 1), 
(1, 16, 1), 
(1, 51, 1), 
(1, 53, 1), 
(1, 46, 1), 
(1, 33, 1), 
(1, 32, 1), 
(1, 30, 1), 
(1, 29, 1), 
(1, 31, 1), 
(1, 28, 1), 
(1, 34, 1), 
(1, 24, 1), 
(1, 20, 1), 
(1, 21, 1), 
(1, 26, 1), 
(1, 23, 1), 
(1, 18, 1), 
(1, 25, 1), 
(1, 17, 1), 
(1, 22, 1), 
(1, 19, 1), 
(1, 48, 1), 
(1, 50, 1), 
(1, 58, 1), 
(1, 35, 1), 
(2, 2, 2), 
(2, 36, 2), 
(2, 39, 2), 
(2, 42, 2), 
(2, 43, 2), 
(2, 54, 2), 
(2, 55, 2), 
(2, 56, 2), 
(2, 57, 2), 
(2, 27, 2), 
(2, 47, 2), 
(2, 11, 2), 
(2, 52, 2), 
(2, 5, 2), 
(2, 6, 2), 
(2, 7, 2), 
(2, 13, 2), 
(2, 15, 2), 
(2, 16, 2), 
(2, 51, 2), 
(2, 53, 2), 
(2, 46, 2), 
(2, 33, 2), 
(2, 32, 2), 
(2, 30, 2), 
(2, 29, 2), 
(2, 31, 2), 
(2, 28, 2), 
(2, 34, 2), 
(2, 24, 2), 
(2, 20, 2), 
(2, 21, 2), 
(2, 26, 2), 
(2, 23, 2), 
(2, 18, 2), 
(2, 25, 2), 
(2, 17, 2), 
(2, 22, 2), 
(2, 19, 2), 
(2, 48, 2), 
(2, 50, 2), 
(2, 58, 2), 
(2, 35, 2), 
(3, 2, 3), 
(3, 36, 3), 
(3, 39, 3), 
(3, 42, 3), 
(3, 43, 3), 
(3, 54, 3), 
(3, 55, 3), 
(3, 56, 3), 
(3, 57, 3), 
(3, 27, 3), 
(3, 47, 3), 
(3, 11, 3), 
(3, 52, 3), 
(3, 5, 3), 
(3, 6, 3), 
(3, 7, 3), 
(3, 13, 3), 
(3, 15, 3), 
(3, 16, 3), 
(3, 51, 3), 
(3, 53, 3), 
(3, 46, 3), 
(3, 33, 3), 
(3, 32, 3), 
(3, 30, 3), 
(3, 29, 3), 
(3, 31, 3), 
(3, 28, 3), 
(3, 34, 3), 
(3, 24, 3), 
(3, 20, 3), 
(3, 21, 3), 
(3, 26, 3), 
(3, 23, 3), 
(3, 18, 3), 
(3, 25, 3), 
(3, 17, 3), 
(3, 22, 3), 
(3, 19, 3), 
(3, 48, 3), 
(3, 50, 3), 
(3, 58, 3), 
(3, 35, 3), 
(22, 2, 1), 
(22, 36, 1), 
(22, 39, 1), 
(22, 42, 1), 
(22, 43, 1), 
(22, 54, 1), 
(22, 55, 1), 
(22, 56, 1), 
(22, 57, 1), 
(22, 27, 1), 
(22, 47, 1), 
(22, 11, 1), 
(22, 52, 1), 
(22, 5, 1), 
(22, 6, 1), 
(22, 7, 1), 
(22, 13, 1), 
(22, 15, 1), 
(22, 16, 1), 
(22, 51, 1), 
(22, 53, 1), 
(22, 46, 1), 
(22, 33, 1), 
(22, 32, 1), 
(22, 30, 1), 
(22, 29, 1), 
(22, 31, 1), 
(22, 28, 1), 
(22, 34, 1), 
(22, 24, 1), 
(22, 20, 1), 
(22, 21, 1), 
(22, 26, 1), 
(22, 23, 1), 
(22, 18, 1), 
(22, 25, 1), 
(22, 17, 1), 
(22, 22, 1), 
(22, 19, 1), 
(22, 48, 1), 
(22, 50, 1), 
(22, 58, 1), 
(22, 35, 1), 
(17, 2, 1), 
(17, 36, 1), 
(17, 39, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 54, 1), 
(17, 55, 1), 
(17, 56, 1), 
(17, 57, 1), 
(17, 27, 1), 
(17, 47, 1), 
(17, 11, 1), 
(17, 52, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 13, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 51, 1), 
(17, 53, 1), 
(17, 46, 1), 
(17, 33, 1), 
(17, 32, 1), 
(17, 30, 1), 
(17, 29, 1), 
(17, 31, 1), 
(17, 28, 1), 
(17, 34, 1), 
(17, 24, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 26, 1), 
(17, 23, 1), 
(17, 18, 1), 
(17, 25, 1), 
(17, 17, 1), 
(17, 22, 1), 
(17, 19, 1), 
(17, 48, 1), 
(17, 50, 1), 
(17, 58, 1), 
(17, 35, 1), 
(4, 2, 1), 
(4, 36, 1), 
(4, 39, 1), 
(4, 42, 1), 
(4, 43, 1), 
(4, 54, 1), 
(4, 55, 1), 
(4, 56, 1), 
(4, 57, 1), 
(4, 27, 1), 
(4, 47, 1), 
(4, 11, 1), 
(4, 52, 1), 
(4, 5, 1), 
(4, 6, 1), 
(4, 7, 1), 
(4, 13, 1), 
(4, 15, 1), 
(4, 16, 1), 
(4, 51, 1), 
(4, 53, 1), 
(4, 46, 1), 
(4, 33, 1), 
(4, 32, 1), 
(4, 30, 1), 
(4, 29, 1), 
(4, 31, 1), 
(4, 28, 1), 
(4, 34, 1), 
(4, 24, 1), 
(4, 20, 1), 
(4, 21, 1), 
(4, 26, 1), 
(4, 23, 1), 
(4, 18, 1), 
(4, 25, 1), 
(4, 17, 1), 
(4, 22, 1), 
(4, 19, 1), 
(4, 48, 1), 
(4, 50, 1), 
(4, 58, 1), 
(4, 35, 1), 
(5, 2, 2), 
(5, 36, 2), 
(5, 39, 2), 
(5, 42, 2), 
(5, 43, 2), 
(5, 54, 2), 
(5, 55, 2), 
(5, 56, 2), 
(5, 57, 2), 
(5, 27, 2), 
(5, 47, 2), 
(5, 11, 2), 
(5, 52, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 13, 2), 
(5, 15, 2), 
(5, 16, 2), 
(5, 51, 2), 
(5, 53, 2), 
(5, 46, 2), 
(5, 33, 2), 
(5, 32, 2), 
(5, 30, 2), 
(5, 29, 2), 
(5, 31, 2), 
(5, 28, 2), 
(5, 34, 2), 
(5, 24, 2), 
(5, 20, 2), 
(5, 21, 2), 
(5, 26, 2), 
(5, 23, 2), 
(5, 18, 2), 
(5, 25, 2), 
(5, 17, 2), 
(5, 22, 2), 
(5, 19, 2), 
(5, 48, 2), 
(5, 50, 2), 
(5, 58, 2), 
(5, 35, 2), 
(6, 2, 3), 
(6, 36, 3), 
(6, 39, 3), 
(6, 42, 3), 
(6, 43, 3), 
(6, 54, 3), 
(6, 55, 3), 
(6, 56, 3), 
(6, 57, 3), 
(6, 27, 3), 
(6, 47, 3), 
(6, 11, 3), 
(6, 52, 3), 
(6, 5, 3), 
(6, 6, 3), 
(6, 7, 3), 
(6, 13, 3), 
(6, 15, 3), 
(6, 16, 3), 
(6, 51, 3), 
(6, 53, 3), 
(6, 46, 3), 
(6, 33, 3), 
(6, 32, 3), 
(6, 30, 3), 
(6, 29, 3), 
(6, 31, 3), 
(6, 28, 3), 
(6, 34, 3), 
(6, 24, 3), 
(6, 20, 3), 
(6, 21, 3), 
(6, 26, 3), 
(6, 23, 3), 
(6, 18, 3), 
(6, 25, 3), 
(6, 17, 3), 
(6, 22, 3), 
(6, 19, 3), 
(6, 48, 3), 
(6, 50, 3), 
(6, 58, 3), 
(6, 35, 3), 
(21, 2, 1), 
(21, 36, 1), 
(21, 39, 1), 
(21, 42, 1), 
(21, 43, 1), 
(21, 54, 1), 
(21, 55, 1), 
(21, 56, 1), 
(21, 57, 1), 
(21, 27, 1), 
(21, 47, 1), 
(21, 11, 1), 
(21, 52, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 13, 1), 
(21, 15, 1), 
(21, 16, 1), 
(21, 51, 1), 
(21, 53, 1), 
(21, 46, 1), 
(21, 33, 1), 
(21, 32, 1), 
(21, 30, 1), 
(21, 29, 1), 
(21, 31, 1), 
(21, 28, 1), 
(21, 34, 1), 
(21, 24, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 26, 1), 
(21, 23, 1), 
(21, 18, 1), 
(21, 25, 1), 
(21, 17, 1), 
(21, 22, 1), 
(21, 19, 1), 
(21, 48, 1), 
(21, 50, 1), 
(21, 58, 1), 
(21, 35, 1), 
(7, 7, 1), 
(8, 2, 1), 
(8, 36, 1), 
(8, 39, 1), 
(8, 42, 1), 
(8, 43, 1), 
(8, 54, 1), 
(8, 55, 1), 
(8, 56, 1), 
(8, 57, 1), 
(8, 27, 1), 
(8, 47, 1), 
(8, 11, 1), 
(8, 52, 1), 
(8, 5, 1), 
(8, 6, 1), 
(8, 7, 2), 
(8, 13, 1), 
(8, 15, 1), 
(8, 16, 1), 
(8, 51, 1), 
(8, 53, 1), 
(8, 46, 1), 
(8, 33, 1), 
(8, 32, 1), 
(8, 30, 1), 
(8, 29, 1), 
(8, 31, 1), 
(8, 28, 1), 
(8, 34, 1), 
(8, 24, 1), 
(8, 20, 1), 
(8, 21, 1), 
(8, 26, 1), 
(8, 23, 1), 
(8, 18, 1), 
(8, 25, 1), 
(8, 17, 1), 
(8, 22, 1), 
(8, 19, 1), 
(8, 48, 1), 
(8, 50, 1), 
(8, 58, 1), 
(8, 35, 1), 
(20, 2, 1), 
(20, 36, 1), 
(20, 39, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 54, 1), 
(20, 55, 1), 
(20, 56, 1), 
(20, 57, 1), 
(20, 27, 1), 
(20, 47, 1), 
(20, 11, 1), 
(20, 52, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 13, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 51, 1), 
(20, 53, 1), 
(20, 46, 1), 
(20, 33, 1), 
(20, 32, 1), 
(20, 30, 1), 
(20, 29, 1), 
(20, 31, 1), 
(20, 28, 1), 
(20, 34, 1), 
(20, 24, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 26, 1), 
(20, 23, 1), 
(20, 18, 1), 
(20, 25, 1), 
(20, 17, 1), 
(20, 22, 1), 
(20, 19, 1), 
(20, 48, 1), 
(20, 50, 1), 
(20, 58, 1), 
(20, 35, 1), 
(18, 2, 1), 
(18, 36, 1), 
(18, 39, 1), 
(18, 42, 1), 
(18, 43, 1), 
(18, 54, 1), 
(18, 55, 1), 
(18, 56, 1), 
(18, 57, 1), 
(18, 27, 1), 
(18, 47, 1), 
(18, 11, 1), 
(18, 52, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 13, 1), 
(18, 15, 1), 
(18, 16, 1), 
(18, 51, 1), 
(18, 53, 1), 
(18, 46, 1), 
(18, 33, 1), 
(18, 32, 1), 
(18, 30, 1), 
(18, 29, 1), 
(18, 31, 1), 
(18, 28, 1), 
(18, 34, 1), 
(18, 24, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 26, 1), 
(18, 23, 1), 
(18, 18, 1), 
(18, 25, 1), 
(18, 17, 1), 
(18, 22, 1), 
(18, 19, 1), 
(18, 48, 1), 
(18, 50, 1), 
(18, 58, 1), 
(18, 35, 1), 
(9, 7, 1), 
(16, 2, 1), 
(16, 36, 1), 
(16, 39, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 54, 1), 
(16, 55, 1), 
(16, 56, 1), 
(16, 57, 1), 
(16, 27, 1), 
(16, 47, 1), 
(16, 11, 1), 
(16, 52, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 13, 1), 
(16, 15, 1), 
(16, 16, 1), 
(16, 51, 1), 
(16, 53, 1), 
(16, 46, 1), 
(16, 33, 1), 
(16, 32, 1), 
(16, 30, 1), 
(16, 29, 1), 
(16, 31, 1), 
(16, 28, 1), 
(16, 34, 1), 
(16, 24, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 26, 1), 
(16, 23, 1), 
(16, 18, 1), 
(16, 25, 1), 
(16, 17, 1), 
(16, 22, 1), 
(16, 19, 1), 
(16, 48, 1), 
(16, 50, 1), 
(16, 58, 1), 
(16, 35, 1), 
(10, 2, 1), 
(10, 36, 1), 
(10, 39, 1), 
(10, 42, 1), 
(10, 43, 1), 
(10, 54, 1), 
(10, 55, 1), 
(10, 56, 1), 
(10, 57, 1), 
(10, 27, 1), 
(10, 47, 1), 
(10, 11, 1), 
(10, 52, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 13, 1), 
(10, 15, 1), 
(10, 16, 1), 
(10, 51, 1), 
(10, 53, 1), 
(10, 46, 1), 
(10, 33, 1), 
(10, 32, 1), 
(10, 30, 1), 
(10, 29, 1), 
(10, 31, 1), 
(10, 28, 1), 
(10, 34, 1), 
(10, 24, 1), 
(10, 20, 1), 
(10, 21, 1), 
(10, 26, 1), 
(10, 23, 1), 
(10, 18, 1), 
(10, 25, 1), 
(10, 17, 1), 
(10, 22, 1), 
(10, 19, 1), 
(10, 48, 1), 
(10, 50, 1), 
(10, 58, 1), 
(10, 35, 1), 
(11, 2, 2), 
(11, 36, 2), 
(11, 39, 2), 
(11, 42, 2), 
(11, 43, 2), 
(11, 54, 2), 
(11, 55, 2), 
(11, 56, 2), 
(11, 57, 2), 
(11, 27, 2), 
(11, 47, 2), 
(11, 11, 2), 
(11, 52, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 13, 2), 
(11, 15, 2), 
(11, 16, 2), 
(11, 51, 2), 
(11, 53, 2), 
(11, 46, 2), 
(11, 33, 2), 
(11, 32, 2), 
(11, 30, 2), 
(11, 29, 2), 
(11, 31, 2), 
(11, 28, 2), 
(11, 34, 2), 
(11, 24, 2), 
(11, 20, 2), 
(11, 21, 2), 
(11, 26, 2), 
(11, 23, 2), 
(11, 18, 2), 
(11, 25, 2), 
(11, 17, 2), 
(11, 22, 2), 
(11, 19, 2), 
(11, 48, 2), 
(11, 50, 2), 
(11, 58, 2), 
(11, 35, 2), 
(12, 2, 3), 
(12, 36, 3), 
(12, 39, 3), 
(12, 42, 3), 
(12, 43, 3), 
(12, 54, 3), 
(12, 55, 3), 
(12, 56, 3), 
(12, 57, 3), 
(12, 27, 3), 
(12, 47, 3), 
(12, 11, 3), 
(12, 52, 3), 
(12, 5, 3), 
(12, 6, 3), 
(12, 7, 3), 
(12, 13, 3), 
(12, 15, 3), 
(12, 16, 3), 
(12, 51, 3), 
(12, 53, 3), 
(12, 46, 3), 
(12, 33, 3), 
(12, 32, 3), 
(12, 30, 3), 
(12, 29, 3), 
(12, 31, 3), 
(12, 28, 3), 
(12, 34, 3), 
(12, 24, 3), 
(12, 20, 3), 
(12, 21, 3), 
(12, 26, 3), 
(12, 23, 3), 
(12, 18, 3), 
(12, 25, 3), 
(12, 17, 3), 
(12, 22, 3), 
(12, 19, 3), 
(12, 48, 3), 
(12, 50, 3), 
(12, 58, 3), 
(12, 35, 3), 
(13, 2, 4), 
(13, 36, 4), 
(13, 39, 4), 
(13, 42, 4), 
(13, 43, 4), 
(13, 54, 4), 
(13, 55, 4), 
(13, 56, 4), 
(13, 57, 4), 
(13, 27, 4), 
(13, 47, 4), 
(13, 11, 4), 
(13, 52, 4), 
(13, 5, 4), 
(13, 6, 4), 
(13, 7, 4), 
(13, 13, 4), 
(13, 15, 4), 
(13, 16, 4), 
(13, 51, 4), 
(13, 53, 4), 
(13, 46, 4), 
(13, 33, 4), 
(13, 32, 4), 
(13, 30, 4), 
(13, 29, 4), 
(13, 31, 4), 
(13, 28, 4), 
(13, 34, 4), 
(13, 24, 4), 
(13, 20, 4), 
(13, 21, 4), 
(13, 26, 4), 
(13, 23, 4), 
(13, 18, 4), 
(13, 25, 4), 
(13, 17, 4), 
(13, 22, 4), 
(13, 19, 4), 
(13, 48, 4), 
(13, 50, 4), 
(13, 58, 4), 
(13, 35, 4), 
(14, 5, 5), 
(14, 6, 5), 
(14, 7, 5), 
(14, 11, 5), 
(14, 13, 5), 
(14, 15, 5), 
(14, 16, 5), 
(14, 51, 5), 
(14, 52, 5), 
(15, 2, 1), 
(15, 36, 1), 
(15, 39, 1), 
(15, 42, 1), 
(15, 43, 1), 
(15, 54, 1), 
(15, 55, 1), 
(15, 56, 1), 
(15, 57, 1), 
(15, 27, 1), 
(15, 47, 1), 
(15, 11, 1), 
(15, 52, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 13, 1), 
(15, 15, 1), 
(15, 16, 1), 
(15, 51, 1), 
(15, 53, 1), 
(15, 46, 1), 
(15, 33, 1), 
(15, 32, 1), 
(15, 30, 1), 
(15, 29, 1), 
(15, 31, 1), 
(15, 28, 1), 
(15, 34, 1), 
(15, 24, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 26, 1), 
(15, 23, 1), 
(15, 18, 1), 
(15, 25, 1), 
(15, 17, 1), 
(15, 22, 1), 
(15, 19, 1), 
(15, 48, 1), 
(15, 50, 1), 
(15, 58, 1), 
(15, 35, 1), 
(23, 2, 1), 
(23, 11, 1), 
(23, 52, 1), 
(23, 5, 1), 
(23, 6, 1), 
(23, 7, 1), 
(23, 13, 1), 
(23, 15, 1), 
(23, 16, 1), 
(23, 51, 1), 
(23, 24, 1), 
(23, 20, 1), 
(23, 21, 1), 
(23, 26, 1), 
(23, 23, 1), 
(23, 18, 1), 
(23, 25, 1), 
(23, 17, 1), 
(23, 22, 1), 
(23, 19, 1), 
(23, 48, 1), 
(23, 50, 1), 
(23, 58, 1), 
(23, 27, 1), 
(23, 33, 1), 
(23, 32, 1), 
(23, 30, 1), 
(23, 29, 1), 
(23, 31, 1), 
(23, 28, 1), 
(23, 34, 1), 
(23, 35, 1), 
(23, 36, 1), 
(23, 39, 1), 
(23, 42, 1), 
(23, 43, 1), 
(23, 46, 1), 
(23, 47, 1), 
(23, 53, 1), 
(23, 54, 1), 
(23, 55, 1), 
(23, 56, 1), 
(23, 57, 1), 
(24, 2, 1), 
(24, 11, 1), 
(24, 52, 1), 
(24, 5, 1), 
(24, 6, 1), 
(24, 7, 1), 
(24, 13, 1), 
(24, 15, 1), 
(24, 16, 1), 
(24, 51, 1), 
(24, 24, 1), 
(24, 20, 1), 
(24, 21, 1), 
(24, 26, 1), 
(24, 23, 1), 
(24, 18, 1), 
(24, 25, 1), 
(24, 17, 1), 
(24, 22, 1), 
(24, 19, 1), 
(24, 48, 1), 
(24, 50, 1), 
(24, 58, 1), 
(24, 27, 1), 
(24, 33, 1), 
(24, 32, 1), 
(24, 30, 1), 
(24, 29, 1), 
(24, 31, 1), 
(24, 28, 1), 
(24, 34, 1), 
(24, 35, 1), 
(24, 36, 1), 
(24, 39, 1), 
(24, 42, 1), 
(24, 43, 1), 
(24, 46, 1), 
(24, 47, 1), 
(24, 53, 1), 
(24, 54, 1), 
(24, 55, 1), 
(24, 56, 1), 
(24, 57, 1), 
(25, 2, 1), 
(25, 11, 1), 
(25, 52, 1), 
(25, 5, 1), 
(25, 6, 1), 
(25, 7, 1), 
(25, 13, 1), 
(25, 15, 1), 
(25, 16, 1), 
(25, 51, 1), 
(25, 24, 1), 
(25, 20, 1), 
(25, 21, 1), 
(25, 26, 1), 
(25, 23, 1), 
(25, 18, 1), 
(25, 25, 1), 
(25, 17, 1), 
(25, 22, 1), 
(25, 19, 1), 
(25, 48, 1), 
(25, 50, 1), 
(25, 58, 1), 
(25, 27, 1), 
(25, 33, 1), 
(25, 32, 1), 
(25, 30, 1), 
(25, 29, 1), 
(25, 31, 1), 
(25, 28, 1), 
(25, 34, 1), 
(25, 35, 1), 
(25, 36, 1), 
(25, 39, 1), 
(25, 42, 1), 
(25, 43, 1), 
(25, 46, 1), 
(25, 47, 1), 
(25, 53, 1), 
(25, 54, 1), 
(25, 55, 1), 
(25, 56, 1), 
(25, 57, 1), 
(26, 2, 1), 
(26, 11, 1), 
(26, 52, 1), 
(26, 5, 1), 
(26, 6, 1), 
(26, 7, 1), 
(26, 13, 1), 
(26, 15, 1), 
(26, 16, 1), 
(26, 51, 1), 
(26, 24, 1), 
(26, 20, 1), 
(26, 21, 1), 
(26, 26, 1), 
(26, 23, 1), 
(26, 18, 1), 
(26, 25, 1), 
(26, 17, 1), 
(26, 22, 1), 
(26, 19, 1), 
(26, 48, 1), 
(26, 50, 1), 
(26, 58, 1), 
(26, 27, 1), 
(26, 33, 1), 
(26, 32, 1), 
(26, 30, 1), 
(26, 29, 1), 
(26, 31, 1), 
(26, 28, 1), 
(26, 34, 1), 
(26, 35, 1), 
(26, 36, 1), 
(26, 39, 1), 
(26, 42, 1), 
(26, 43, 1), 
(26, 46, 1), 
(26, 47, 1), 
(26, 53, 1), 
(26, 54, 1), 
(26, 55, 1), 
(26, 56, 1), 
(26, 57, 1), 
(27, 2, 1), 
(27, 11, 1), 
(27, 52, 1), 
(27, 5, 1), 
(27, 6, 1), 
(27, 7, 1), 
(27, 13, 1), 
(27, 15, 1), 
(27, 16, 1), 
(27, 51, 1), 
(27, 24, 1), 
(27, 20, 1), 
(27, 21, 1), 
(27, 26, 1), 
(27, 23, 1), 
(27, 18, 1), 
(27, 25, 1), 
(27, 17, 1), 
(27, 22, 1), 
(27, 19, 1), 
(27, 48, 1), 
(27, 50, 1), 
(27, 58, 1), 
(27, 27, 1), 
(27, 33, 1), 
(27, 32, 1), 
(27, 30, 1), 
(27, 29, 1), 
(27, 31, 1), 
(27, 28, 1), 
(27, 34, 1), 
(27, 35, 1), 
(27, 36, 1), 
(27, 39, 1), 
(27, 42, 1), 
(27, 43, 1), 
(27, 46, 1), 
(27, 47, 1), 
(27, 53, 1), 
(27, 54, 1), 
(27, 55, 1), 
(27, 56, 1), 
(27, 57, 1), 
(28, 2, 1), 
(28, 11, 1), 
(28, 52, 1), 
(28, 5, 1), 
(28, 6, 1), 
(28, 7, 1), 
(28, 13, 1), 
(28, 15, 1), 
(28, 16, 1), 
(28, 51, 1), 
(28, 24, 1), 
(28, 20, 1), 
(28, 21, 1), 
(28, 26, 1), 
(28, 23, 1), 
(28, 18, 1), 
(28, 25, 1), 
(28, 17, 1), 
(28, 22, 1), 
(28, 19, 1), 
(28, 48, 1), 
(28, 50, 1), 
(28, 58, 1), 
(28, 27, 1), 
(28, 33, 1), 
(28, 32, 1), 
(28, 30, 1), 
(28, 29, 1), 
(28, 31, 1), 
(28, 28, 1), 
(28, 34, 1), 
(28, 35, 1), 
(28, 36, 1), 
(28, 39, 1), 
(28, 42, 1), 
(28, 43, 1), 
(28, 46, 1), 
(28, 47, 1), 
(28, 53, 1), 
(28, 54, 1), 
(28, 55, 1), 
(28, 56, 1), 
(28, 57, 1), 
(29, 2, 1), 
(29, 11, 1), 
(29, 52, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 13, 1), 
(29, 15, 1), 
(29, 16, 1), 
(29, 51, 1), 
(29, 24, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 26, 1), 
(29, 23, 1), 
(29, 18, 1), 
(29, 25, 1), 
(29, 17, 1), 
(29, 22, 1), 
(29, 19, 1), 
(29, 48, 1), 
(29, 50, 1), 
(29, 58, 1), 
(29, 27, 1), 
(29, 33, 1), 
(29, 32, 1), 
(29, 30, 1), 
(29, 29, 1), 
(29, 31, 1), 
(29, 28, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 36, 1), 
(29, 39, 1), 
(29, 42, 1), 
(29, 43, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 53, 1), 
(29, 54, 1), 
(29, 55, 1), 
(29, 56, 1), 
(29, 57, 1), 
(24, 71, 1), 
(24, 89, 1), 
(24, 67, 1), 
(24, 84, 1), 
(24, 61, 1), 
(24, 74, 1), 
(24, 75, 1), 
(24, 64, 1), 
(24, 69, 1), 
(24, 68, 1), 
(24, 85, 1), 
(24, 73, 1), 
(24, 80, 1), 
(24, 76, 1), 
(29, 71, 1), 
(29, 89, 1), 
(29, 67, 1), 
(29, 84, 1), 
(29, 61, 1), 
(29, 74, 1), 
(29, 75, 1), 
(29, 64, 1), 
(29, 69, 1), 
(29, 68, 1), 
(29, 85, 1), 
(29, 73, 1), 
(29, 80, 1), 
(29, 76, 1), 
(26, 71, 1), 
(26, 89, 1), 
(26, 67, 1), 
(26, 84, 1), 
(26, 61, 1), 
(26, 74, 1), 
(26, 75, 1), 
(26, 64, 1), 
(26, 69, 1), 
(26, 68, 1), 
(26, 85, 1), 
(26, 73, 1), 
(26, 80, 1), 
(26, 76, 1), 
(25, 71, 1), 
(25, 89, 1), 
(25, 67, 1), 
(25, 84, 1), 
(25, 61, 1), 
(25, 74, 1), 
(25, 75, 1), 
(25, 64, 1), 
(25, 69, 1), 
(25, 68, 1), 
(25, 85, 1), 
(25, 73, 1), 
(25, 80, 1), 
(25, 76, 1), 
(23, 71, 1), 
(23, 89, 1), 
(23, 67, 1), 
(23, 84, 1), 
(23, 61, 1), 
(23, 74, 1), 
(23, 75, 1), 
(23, 64, 1), 
(23, 69, 1), 
(23, 68, 1), 
(23, 85, 1), 
(23, 73, 1), 
(23, 80, 1), 
(23, 76, 1), 
(27, 71, 1), 
(27, 89, 1), 
(27, 67, 1), 
(27, 84, 1), 
(27, 61, 1), 
(27, 74, 1), 
(27, 75, 1), 
(27, 64, 1), 
(27, 69, 1), 
(27, 68, 1), 
(27, 85, 1), 
(27, 73, 1), 
(27, 80, 1), 
(27, 76, 1), 
(28, 71, 1), 
(28, 89, 1), 
(28, 67, 1), 
(28, 84, 1), 
(28, 61, 1), 
(28, 74, 1), 
(28, 75, 1), 
(28, 64, 1), 
(28, 69, 1), 
(28, 68, 1), 
(28, 85, 1), 
(28, 73, 1), 
(28, 80, 1), 
(28, 76, 1), 
(19, 71, 1), 
(19, 89, 1), 
(19, 67, 1), 
(19, 84, 1), 
(19, 61, 1), 
(19, 74, 1), 
(19, 75, 1), 
(19, 64, 1), 
(19, 69, 1), 
(19, 68, 1), 
(19, 85, 1), 
(19, 73, 1), 
(19, 80, 1), 
(19, 76, 1), 
(1, 71, 1), 
(1, 89, 1), 
(1, 67, 1), 
(1, 84, 1), 
(1, 61, 1), 
(1, 74, 1), 
(1, 75, 1), 
(1, 64, 1), 
(1, 69, 1), 
(1, 68, 1), 
(1, 85, 1), 
(1, 73, 1), 
(1, 80, 1), 
(1, 76, 1), 
(2, 71, 2), 
(2, 89, 2), 
(2, 67, 2), 
(2, 84, 2), 
(2, 61, 2), 
(2, 74, 2), 
(2, 75, 2), 
(2, 64, 2), 
(2, 69, 2), 
(2, 68, 2), 
(2, 85, 2), 
(2, 73, 2), 
(2, 80, 2), 
(2, 76, 2), 
(3, 71, 3), 
(3, 89, 3), 
(3, 67, 3), 
(3, 84, 3), 
(3, 61, 3), 
(3, 74, 3), 
(3, 75, 3), 
(3, 64, 3), 
(3, 69, 3), 
(3, 68, 3), 
(3, 85, 3), 
(3, 73, 3), 
(3, 80, 3), 
(3, 76, 3), 
(22, 71, 1), 
(22, 89, 1), 
(22, 67, 1), 
(22, 84, 1), 
(22, 61, 1), 
(22, 74, 1), 
(22, 75, 1), 
(22, 64, 1), 
(22, 69, 1), 
(22, 68, 1), 
(22, 85, 1), 
(22, 73, 1), 
(22, 80, 1), 
(22, 76, 1), 
(17, 71, 1), 
(17, 89, 1), 
(17, 67, 1), 
(17, 84, 1), 
(17, 61, 1), 
(17, 74, 1), 
(17, 75, 1), 
(17, 64, 1), 
(17, 69, 1), 
(17, 68, 1), 
(17, 85, 1), 
(17, 73, 1), 
(17, 80, 1), 
(17, 76, 1), 
(4, 71, 1), 
(4, 89, 1), 
(4, 67, 1), 
(4, 84, 1), 
(4, 61, 1), 
(4, 74, 1), 
(4, 75, 1), 
(4, 64, 1), 
(4, 69, 1), 
(4, 68, 1), 
(4, 85, 1), 
(4, 73, 1), 
(4, 80, 1), 
(4, 76, 1), 
(5, 71, 2), 
(5, 89, 2), 
(5, 67, 2), 
(5, 84, 2), 
(5, 61, 2), 
(5, 74, 2), 
(5, 75, 2), 
(5, 64, 2), 
(5, 69, 2), 
(5, 68, 2), 
(5, 85, 2), 
(5, 73, 2), 
(5, 80, 2), 
(5, 76, 2), 
(6, 71, 3), 
(6, 89, 3), 
(6, 67, 3), 
(6, 84, 3), 
(6, 61, 3), 
(6, 74, 3), 
(6, 75, 3), 
(6, 64, 3), 
(6, 69, 3), 
(6, 68, 3), 
(6, 85, 3), 
(6, 73, 3), 
(6, 80, 3), 
(6, 76, 3), 
(21, 71, 1), 
(21, 89, 1), 
(21, 67, 1), 
(21, 84, 1), 
(21, 61, 1), 
(21, 74, 1), 
(21, 75, 1), 
(21, 64, 1), 
(21, 69, 1), 
(21, 68, 1), 
(21, 85, 1), 
(21, 73, 1), 
(21, 80, 1), 
(21, 76, 1), 
(8, 71, 1), 
(8, 89, 1), 
(8, 67, 1), 
(8, 84, 1), 
(8, 61, 1), 
(8, 74, 1), 
(8, 75, 1), 
(8, 64, 1), 
(8, 69, 1), 
(8, 68, 1), 
(8, 85, 1), 
(8, 73, 1), 
(8, 80, 1), 
(8, 76, 1), 
(20, 71, 1), 
(20, 89, 1), 
(20, 67, 1), 
(20, 84, 1), 
(20, 61, 1), 
(20, 74, 1), 
(20, 75, 1), 
(20, 64, 1), 
(20, 69, 1), 
(20, 68, 1), 
(20, 85, 1), 
(20, 73, 1), 
(20, 80, 1), 
(20, 76, 1), 
(18, 71, 1), 
(18, 89, 1), 
(18, 67, 1), 
(18, 84, 1), 
(18, 61, 1), 
(18, 74, 1), 
(18, 75, 1), 
(18, 64, 1), 
(18, 69, 1), 
(18, 68, 1), 
(18, 85, 1), 
(18, 73, 1), 
(18, 80, 1), 
(18, 76, 1), 
(16, 71, 1), 
(16, 89, 1), 
(16, 67, 1), 
(16, 84, 1), 
(16, 61, 1), 
(16, 74, 1), 
(16, 75, 1), 
(16, 64, 1), 
(16, 69, 1), 
(16, 68, 1), 
(16, 85, 1), 
(16, 73, 1), 
(16, 80, 1), 
(16, 76, 1), 
(10, 71, 1), 
(10, 89, 1), 
(10, 67, 1), 
(10, 84, 1), 
(10, 61, 1), 
(10, 74, 1), 
(10, 75, 1), 
(10, 64, 1), 
(10, 69, 1), 
(10, 68, 1), 
(10, 85, 1), 
(10, 73, 1), 
(10, 80, 1), 
(10, 76, 1), 
(11, 71, 2), 
(11, 89, 2), 
(11, 67, 2), 
(11, 84, 2), 
(11, 61, 2), 
(11, 74, 2), 
(11, 75, 2), 
(11, 64, 2), 
(11, 69, 2), 
(11, 68, 2), 
(11, 85, 2), 
(11, 73, 2), 
(11, 80, 2), 
(11, 76, 2), 
(12, 71, 3), 
(12, 89, 3), 
(12, 67, 3), 
(12, 84, 3), 
(12, 61, 3), 
(12, 74, 3), 
(12, 75, 3), 
(12, 64, 3), 
(12, 69, 3), 
(12, 68, 3), 
(12, 85, 3), 
(12, 73, 3), 
(12, 80, 3), 
(12, 76, 3), 
(13, 71, 4), 
(13, 89, 4), 
(13, 67, 4), 
(13, 84, 4), 
(13, 61, 4), 
(13, 74, 4), 
(13, 75, 4), 
(13, 64, 4), 
(13, 69, 4), 
(13, 68, 4), 
(13, 85, 4), 
(13, 73, 4), 
(13, 80, 4), 
(13, 76, 4), 
(15, 71, 1), 
(15, 89, 1), 
(15, 67, 1), 
(15, 84, 1), 
(15, 61, 1), 
(15, 74, 1), 
(15, 75, 1), 
(15, 64, 1), 
(15, 69, 1), 
(15, 68, 1), 
(15, 85, 1), 
(15, 73, 1), 
(15, 80, 1), 
(15, 76, 1), 
(24, 90, 1), 
(29, 90, 1), 
(26, 90, 1), 
(25, 90, 1), 
(23, 90, 1), 
(27, 90, 1), 
(28, 90, 1), 
(19, 90, 1), 
(1, 90, 1), 
(2, 90, 2), 
(3, 90, 3), 
(22, 90, 1), 
(17, 90, 1), 
(4, 90, 1), 
(5, 90, 2), 
(6, 90, 3), 
(21, 90, 1), 
(8, 90, 1), 
(20, 90, 1), 
(18, 90, 1), 
(16, 90, 1), 
(10, 90, 1), 
(11, 90, 2), 
(12, 90, 3), 
(13, 90, 4), 
(15, 90, 1), 
(24, 103, 1), 
(24, 121, 1), 
(24, 99, 1), 
(24, 116, 1), 
(24, 93, 1), 
(24, 106, 1), 
(24, 107, 1), 
(24, 96, 1), 
(24, 101, 1), 
(24, 100, 1), 
(24, 117, 1), 
(24, 105, 1), 
(24, 112, 1), 
(24, 108, 1), 
(29, 103, 1), 
(29, 121, 1), 
(29, 99, 1), 
(29, 116, 1), 
(29, 93, 1), 
(29, 106, 1), 
(29, 107, 1), 
(29, 96, 1), 
(29, 101, 1), 
(29, 100, 1), 
(29, 117, 1), 
(29, 105, 1), 
(29, 112, 1), 
(29, 108, 1), 
(26, 103, 1), 
(26, 121, 1), 
(26, 99, 1), 
(26, 116, 1), 
(26, 93, 1), 
(26, 106, 1), 
(26, 107, 1), 
(26, 96, 1), 
(26, 101, 1), 
(26, 100, 1), 
(26, 117, 1), 
(26, 105, 1), 
(26, 112, 1), 
(26, 108, 1), 
(25, 103, 1), 
(25, 121, 1), 
(25, 99, 1), 
(25, 116, 1), 
(25, 93, 1), 
(25, 106, 1), 
(25, 107, 1), 
(25, 96, 1), 
(25, 101, 1), 
(25, 100, 1), 
(25, 117, 1), 
(25, 105, 1), 
(25, 112, 1), 
(25, 108, 1), 
(23, 103, 1), 
(23, 121, 1), 
(23, 99, 1), 
(23, 116, 1), 
(23, 93, 1), 
(23, 106, 1), 
(23, 107, 1), 
(23, 96, 1), 
(23, 101, 1), 
(23, 100, 1), 
(23, 117, 1), 
(23, 105, 1), 
(23, 112, 1), 
(23, 108, 1), 
(27, 103, 1), 
(27, 121, 1), 
(27, 99, 1), 
(27, 116, 1), 
(27, 93, 1), 
(27, 106, 1), 
(27, 107, 1), 
(27, 96, 1), 
(27, 101, 1), 
(27, 100, 1), 
(27, 117, 1), 
(27, 105, 1), 
(27, 112, 1), 
(27, 108, 1), 
(28, 103, 1), 
(28, 121, 1), 
(28, 99, 1), 
(28, 116, 1), 
(28, 93, 1), 
(28, 106, 1), 
(28, 107, 1), 
(28, 96, 1), 
(28, 101, 1), 
(28, 100, 1), 
(28, 117, 1), 
(28, 105, 1), 
(28, 112, 1), 
(28, 108, 1), 
(19, 103, 1), 
(19, 121, 1), 
(19, 99, 1), 
(19, 116, 1), 
(19, 93, 1), 
(19, 106, 1), 
(19, 107, 1), 
(19, 96, 1), 
(19, 101, 1), 
(19, 100, 1), 
(19, 117, 1), 
(19, 105, 1), 
(19, 112, 1), 
(19, 108, 1), 
(1, 103, 1), 
(1, 121, 1), 
(1, 99, 1), 
(1, 116, 1), 
(1, 93, 1), 
(1, 106, 1), 
(1, 107, 1), 
(1, 96, 1), 
(1, 101, 1), 
(1, 100, 1), 
(1, 117, 1), 
(1, 105, 1), 
(1, 112, 1), 
(1, 108, 1), 
(2, 103, 2), 
(2, 121, 2), 
(2, 99, 2), 
(2, 116, 2), 
(2, 93, 2), 
(2, 106, 2), 
(2, 107, 2), 
(2, 96, 2), 
(2, 101, 2), 
(2, 100, 2), 
(2, 117, 2), 
(2, 105, 2), 
(2, 112, 2), 
(2, 108, 2), 
(3, 103, 3), 
(3, 121, 3), 
(3, 99, 3), 
(3, 116, 3), 
(3, 93, 3), 
(3, 106, 3), 
(3, 107, 3), 
(3, 96, 3), 
(3, 101, 3), 
(3, 100, 3), 
(3, 117, 3), 
(3, 105, 3), 
(3, 112, 3), 
(3, 108, 3), 
(22, 103, 1), 
(22, 121, 1), 
(22, 99, 1), 
(22, 116, 1), 
(22, 93, 1), 
(22, 106, 1), 
(22, 107, 1), 
(22, 96, 1), 
(22, 101, 1), 
(22, 100, 1), 
(22, 117, 1), 
(22, 105, 1), 
(22, 112, 1), 
(22, 108, 1), 
(17, 103, 1), 
(17, 121, 1), 
(17, 99, 1), 
(17, 116, 1), 
(17, 93, 1), 
(17, 106, 1), 
(17, 107, 1), 
(17, 96, 1), 
(17, 101, 1), 
(17, 100, 1), 
(17, 117, 1), 
(17, 105, 1), 
(17, 112, 1), 
(17, 108, 1), 
(4, 103, 1), 
(4, 121, 1), 
(4, 99, 1), 
(4, 116, 1), 
(4, 93, 1), 
(4, 106, 1), 
(4, 107, 1), 
(4, 96, 1), 
(4, 101, 1), 
(4, 100, 1), 
(4, 117, 1), 
(4, 105, 1), 
(4, 112, 1), 
(4, 108, 1), 
(5, 103, 2), 
(5, 121, 2), 
(5, 99, 2), 
(5, 116, 2), 
(5, 93, 2), 
(5, 106, 2), 
(5, 107, 2), 
(5, 96, 2), 
(5, 101, 2), 
(5, 100, 2), 
(5, 117, 2), 
(5, 105, 2), 
(5, 112, 2), 
(5, 108, 2), 
(6, 103, 3), 
(6, 121, 3), 
(6, 99, 3), 
(6, 116, 3), 
(6, 93, 3), 
(6, 106, 3), 
(6, 107, 3), 
(6, 96, 3), 
(6, 101, 3), 
(6, 100, 3), 
(6, 117, 3), 
(6, 105, 3), 
(6, 112, 3), 
(6, 108, 3), 
(21, 103, 1), 
(21, 121, 1), 
(21, 99, 1), 
(21, 116, 1), 
(21, 93, 1), 
(21, 106, 1), 
(21, 107, 1), 
(21, 96, 1), 
(21, 101, 1), 
(21, 100, 1), 
(21, 117, 1), 
(21, 105, 1), 
(21, 112, 1), 
(21, 108, 1), 
(8, 103, 1), 
(8, 121, 1), 
(8, 99, 1), 
(8, 116, 1), 
(8, 93, 1), 
(8, 106, 1), 
(8, 107, 1), 
(8, 96, 1), 
(8, 101, 1), 
(8, 100, 1), 
(8, 117, 1), 
(8, 105, 1), 
(8, 112, 1), 
(8, 108, 1), 
(20, 103, 1), 
(20, 121, 1), 
(20, 99, 1), 
(20, 116, 1), 
(20, 93, 1), 
(20, 106, 1), 
(20, 107, 1), 
(20, 96, 1), 
(20, 101, 1), 
(20, 100, 1), 
(20, 117, 1), 
(20, 105, 1), 
(20, 112, 1), 
(20, 108, 1), 
(18, 103, 1), 
(18, 121, 1), 
(18, 99, 1), 
(18, 116, 1), 
(18, 93, 1), 
(18, 106, 1), 
(18, 107, 1), 
(18, 96, 1), 
(18, 101, 1), 
(18, 100, 1), 
(18, 117, 1), 
(18, 105, 1), 
(18, 112, 1), 
(18, 108, 1), 
(16, 103, 1), 
(16, 121, 1), 
(16, 99, 1), 
(16, 116, 1), 
(16, 93, 1), 
(16, 106, 1), 
(16, 107, 1), 
(16, 96, 1), 
(16, 101, 1), 
(16, 100, 1), 
(16, 117, 1), 
(16, 105, 1), 
(16, 112, 1), 
(16, 108, 1), 
(10, 103, 1), 
(10, 121, 1), 
(10, 99, 1), 
(10, 116, 1), 
(10, 93, 1), 
(10, 106, 1), 
(10, 107, 1), 
(10, 96, 1), 
(10, 101, 1), 
(10, 100, 1), 
(10, 117, 1), 
(10, 105, 1), 
(10, 112, 1), 
(10, 108, 1), 
(11, 103, 2), 
(11, 121, 2), 
(11, 99, 2), 
(11, 116, 2), 
(11, 93, 2), 
(11, 106, 2), 
(11, 107, 2), 
(11, 96, 2), 
(11, 101, 2), 
(11, 100, 2), 
(11, 117, 2), 
(11, 105, 2), 
(11, 112, 2), 
(11, 108, 2), 
(12, 103, 3), 
(12, 121, 3), 
(12, 99, 3), 
(12, 116, 3), 
(12, 93, 3), 
(12, 106, 3), 
(12, 107, 3), 
(12, 96, 3), 
(12, 101, 3), 
(12, 100, 3), 
(12, 117, 3), 
(12, 105, 3), 
(12, 112, 3), 
(12, 108, 3), 
(13, 103, 4), 
(13, 121, 4), 
(13, 99, 4), 
(13, 116, 4), 
(13, 93, 4), 
(13, 106, 4), 
(13, 107, 4), 
(13, 96, 4), 
(13, 101, 4), 
(13, 100, 4), 
(13, 117, 4), 
(13, 105, 4), 
(13, 112, 4), 
(13, 108, 4), 
(15, 103, 1), 
(15, 121, 1), 
(15, 99, 1), 
(15, 116, 1), 
(15, 93, 1), 
(15, 106, 1), 
(15, 107, 1), 
(15, 96, 1), 
(15, 101, 1), 
(15, 100, 1), 
(15, 117, 1), 
(15, 105, 1), 
(15, 112, 1), 
(15, 108, 1), 
(24, 122, 1), 
(29, 122, 1), 
(26, 122, 1), 
(25, 122, 1), 
(23, 122, 1), 
(27, 122, 1), 
(28, 122, 1), 
(19, 122, 1), 
(1, 122, 1), 
(2, 122, 2), 
(3, 122, 3), 
(22, 122, 1), 
(17, 122, 1), 
(4, 122, 1), 
(5, 122, 2), 
(6, 122, 3), 
(21, 122, 1), 
(8, 122, 1), 
(20, 122, 1), 
(18, 122, 1), 
(16, 122, 1), 
(10, 122, 1), 
(11, 122, 2), 
(12, 122, 3), 
(13, 122, 4), 
(15, 122, 1), 
(24, 135, 1), 
(24, 153, 1), 
(24, 131, 1), 
(24, 148, 1), 
(24, 125, 1), 
(24, 138, 1), 
(24, 139, 1), 
(24, 128, 1), 
(24, 133, 1), 
(24, 132, 1), 
(24, 149, 1), 
(24, 137, 1), 
(24, 144, 1), 
(24, 140, 1), 
(29, 135, 1), 
(29, 153, 1), 
(29, 131, 1), 
(29, 148, 1), 
(29, 125, 1), 
(29, 138, 1), 
(29, 139, 1), 
(29, 128, 1), 
(29, 133, 1), 
(29, 132, 1), 
(29, 149, 1), 
(29, 137, 1), 
(29, 144, 1), 
(29, 140, 1), 
(26, 135, 1), 
(26, 153, 1), 
(26, 131, 1), 
(26, 148, 1), 
(26, 125, 1), 
(26, 138, 1), 
(26, 139, 1), 
(26, 128, 1), 
(26, 133, 1), 
(26, 132, 1), 
(26, 149, 1), 
(26, 137, 1), 
(26, 144, 1), 
(26, 140, 1), 
(25, 135, 1), 
(25, 153, 1), 
(25, 131, 1), 
(25, 148, 1), 
(25, 125, 1), 
(25, 138, 1), 
(25, 139, 1), 
(25, 128, 1), 
(25, 133, 1), 
(25, 132, 1), 
(25, 149, 1), 
(25, 137, 1), 
(25, 144, 1), 
(25, 140, 1), 
(23, 135, 1), 
(23, 153, 1), 
(23, 131, 1), 
(23, 148, 1), 
(23, 125, 1), 
(23, 138, 1), 
(23, 139, 1), 
(23, 128, 1), 
(23, 133, 1), 
(23, 132, 1), 
(23, 149, 1), 
(23, 137, 1), 
(23, 144, 1), 
(23, 140, 1), 
(27, 135, 1), 
(27, 153, 1), 
(27, 131, 1), 
(27, 148, 1), 
(27, 125, 1), 
(27, 138, 1), 
(27, 139, 1), 
(27, 128, 1), 
(27, 133, 1), 
(27, 132, 1), 
(27, 149, 1), 
(27, 137, 1), 
(27, 144, 1), 
(27, 140, 1), 
(28, 135, 1), 
(28, 153, 1), 
(28, 131, 1), 
(28, 148, 1), 
(28, 125, 1), 
(28, 138, 1), 
(28, 139, 1), 
(28, 128, 1), 
(28, 133, 1), 
(28, 132, 1), 
(28, 149, 1), 
(28, 137, 1), 
(28, 144, 1), 
(28, 140, 1), 
(19, 135, 1), 
(19, 153, 1), 
(19, 131, 1), 
(19, 148, 1), 
(19, 125, 1), 
(19, 138, 1), 
(19, 139, 1), 
(19, 128, 1), 
(19, 133, 1), 
(19, 132, 1), 
(19, 149, 1), 
(19, 137, 1), 
(19, 144, 1), 
(19, 140, 1), 
(1, 135, 1), 
(1, 153, 1), 
(1, 131, 1), 
(1, 148, 1), 
(1, 125, 1), 
(1, 138, 1), 
(1, 139, 1), 
(1, 128, 1), 
(1, 133, 1), 
(1, 132, 1), 
(1, 149, 1), 
(1, 137, 1), 
(1, 144, 1), 
(1, 140, 1), 
(2, 135, 2), 
(2, 153, 2), 
(2, 131, 2), 
(2, 148, 2), 
(2, 125, 2), 
(2, 138, 2), 
(2, 139, 2), 
(2, 128, 2), 
(2, 133, 2), 
(2, 132, 2), 
(2, 149, 2), 
(2, 137, 2), 
(2, 144, 2), 
(2, 140, 2), 
(3, 135, 3), 
(3, 153, 3), 
(3, 131, 3), 
(3, 148, 3), 
(3, 125, 3), 
(3, 138, 3), 
(3, 139, 3), 
(3, 128, 3), 
(3, 133, 3), 
(3, 132, 3), 
(3, 149, 3), 
(3, 137, 3), 
(3, 144, 3), 
(3, 140, 3), 
(22, 135, 1), 
(22, 153, 1), 
(22, 131, 1), 
(22, 148, 1), 
(22, 125, 1), 
(22, 138, 1), 
(22, 139, 1), 
(22, 128, 1), 
(22, 133, 1), 
(22, 132, 1), 
(22, 149, 1), 
(22, 137, 1), 
(22, 144, 1), 
(22, 140, 1), 
(17, 135, 1), 
(17, 153, 1), 
(17, 131, 1), 
(17, 148, 1), 
(17, 125, 1), 
(17, 138, 1), 
(17, 139, 1), 
(17, 128, 1), 
(17, 133, 1), 
(17, 132, 1), 
(17, 149, 1), 
(17, 137, 1), 
(17, 144, 1), 
(17, 140, 1), 
(4, 135, 1), 
(4, 153, 1), 
(4, 131, 1), 
(4, 148, 1), 
(4, 125, 1), 
(4, 138, 1), 
(4, 139, 1), 
(4, 128, 1), 
(4, 133, 1), 
(4, 132, 1), 
(4, 149, 1), 
(4, 137, 1), 
(4, 144, 1), 
(4, 140, 1), 
(5, 135, 2), 
(5, 153, 2), 
(5, 131, 2), 
(5, 148, 2), 
(5, 125, 2), 
(5, 138, 2), 
(5, 139, 2), 
(5, 128, 2), 
(5, 133, 2), 
(5, 132, 2), 
(5, 149, 2), 
(5, 137, 2), 
(5, 144, 2), 
(5, 140, 2), 
(6, 135, 3), 
(6, 153, 3), 
(6, 131, 3), 
(6, 148, 3), 
(6, 125, 3), 
(6, 138, 3), 
(6, 139, 3), 
(6, 128, 3), 
(6, 133, 3), 
(6, 132, 3), 
(6, 149, 3), 
(6, 137, 3), 
(6, 144, 3), 
(6, 140, 3), 
(21, 135, 1), 
(21, 153, 1), 
(21, 131, 1), 
(21, 148, 1), 
(21, 125, 1), 
(21, 138, 1), 
(21, 139, 1), 
(21, 128, 1), 
(21, 133, 1), 
(21, 132, 1), 
(21, 149, 1), 
(21, 137, 1), 
(21, 144, 1), 
(21, 140, 1), 
(8, 135, 1), 
(8, 153, 1), 
(8, 131, 1), 
(8, 148, 1), 
(8, 125, 1), 
(8, 138, 1), 
(8, 139, 1), 
(8, 128, 1), 
(8, 133, 1), 
(8, 132, 1), 
(8, 149, 1), 
(8, 137, 1), 
(8, 144, 1), 
(8, 140, 1), 
(20, 135, 1), 
(20, 153, 1), 
(20, 131, 1), 
(20, 148, 1), 
(20, 125, 1), 
(20, 138, 1), 
(20, 139, 1), 
(20, 128, 1), 
(20, 133, 1), 
(20, 132, 1), 
(20, 149, 1), 
(20, 137, 1), 
(20, 144, 1), 
(20, 140, 1), 
(18, 135, 1), 
(18, 153, 1), 
(18, 131, 1), 
(18, 148, 1), 
(18, 125, 1), 
(18, 138, 1), 
(18, 139, 1), 
(18, 128, 1), 
(18, 133, 1), 
(18, 132, 1), 
(18, 149, 1), 
(18, 137, 1), 
(18, 144, 1), 
(18, 140, 1), 
(16, 135, 1), 
(16, 153, 1), 
(16, 131, 1), 
(16, 148, 1), 
(16, 125, 1), 
(16, 138, 1), 
(16, 139, 1), 
(16, 128, 1), 
(16, 133, 1), 
(16, 132, 1), 
(16, 149, 1), 
(16, 137, 1), 
(16, 144, 1), 
(16, 140, 1), 
(10, 135, 1), 
(10, 153, 1), 
(10, 131, 1), 
(10, 148, 1), 
(10, 125, 1), 
(10, 138, 1), 
(10, 139, 1), 
(10, 128, 1), 
(10, 133, 1), 
(10, 132, 1), 
(10, 149, 1), 
(10, 137, 1), 
(10, 144, 1), 
(10, 140, 1), 
(11, 135, 2), 
(11, 153, 2), 
(11, 131, 2), 
(11, 148, 2), 
(11, 125, 2), 
(11, 138, 2), 
(11, 139, 2), 
(11, 128, 2), 
(11, 133, 2), 
(11, 132, 2), 
(11, 149, 2), 
(11, 137, 2), 
(11, 144, 2), 
(11, 140, 2), 
(12, 135, 3), 
(12, 153, 3), 
(12, 131, 3), 
(12, 148, 3), 
(12, 125, 3), 
(12, 138, 3), 
(12, 139, 3), 
(12, 128, 3), 
(12, 133, 3), 
(12, 132, 3), 
(12, 149, 3), 
(12, 137, 3), 
(12, 144, 3), 
(12, 140, 3), 
(13, 135, 4), 
(13, 153, 4), 
(13, 131, 4), 
(13, 148, 4), 
(13, 125, 4), 
(13, 138, 4), 
(13, 139, 4), 
(13, 128, 4), 
(13, 133, 4), 
(13, 132, 4), 
(13, 149, 4), 
(13, 137, 4), 
(13, 144, 4), 
(13, 140, 4), 
(15, 135, 1), 
(15, 153, 1), 
(15, 131, 1), 
(15, 148, 1), 
(15, 125, 1), 
(15, 138, 1), 
(15, 139, 1), 
(15, 128, 1), 
(15, 133, 1), 
(15, 132, 1), 
(15, 149, 1), 
(15, 137, 1), 
(15, 144, 1), 
(15, 140, 1), 
(24, 163, 1), 
(24, 178, 1), 
(24, 159, 1), 
(24, 171, 1), 
(24, 154, 1), 
(24, 164, 1), 
(24, 165, 1), 
(24, 157, 1), 
(24, 161, 1), 
(24, 160, 1), 
(24, 172, 1), 
(24, 156, 1), 
(24, 179, 1), 
(24, 177, 1), 
(29, 163, 1), 
(29, 178, 1), 
(29, 159, 1), 
(29, 171, 1), 
(29, 154, 1), 
(29, 164, 1), 
(29, 165, 1), 
(29, 157, 1), 
(29, 161, 1), 
(29, 160, 1), 
(29, 172, 1), 
(29, 156, 1), 
(29, 179, 1), 
(29, 177, 1), 
(26, 163, 1), 
(26, 178, 1), 
(26, 159, 1), 
(26, 171, 1), 
(26, 154, 1), 
(26, 164, 1), 
(26, 165, 1), 
(26, 157, 1), 
(26, 161, 1), 
(26, 160, 1), 
(26, 172, 1), 
(26, 156, 1), 
(26, 179, 1), 
(26, 177, 1), 
(25, 163, 1), 
(25, 178, 1), 
(25, 159, 1), 
(25, 171, 1), 
(25, 154, 1), 
(25, 164, 1), 
(25, 165, 1), 
(25, 157, 1), 
(25, 161, 1), 
(25, 160, 1), 
(25, 172, 1), 
(25, 156, 1), 
(25, 179, 1), 
(25, 177, 1), 
(23, 163, 1), 
(23, 178, 1), 
(23, 159, 1), 
(23, 171, 1), 
(23, 154, 1), 
(23, 164, 1), 
(23, 165, 1), 
(23, 157, 1), 
(23, 161, 1), 
(23, 160, 1), 
(23, 172, 1), 
(23, 156, 1), 
(23, 179, 1), 
(23, 177, 1), 
(27, 163, 1), 
(27, 178, 1), 
(27, 159, 1), 
(27, 171, 1), 
(27, 154, 1), 
(27, 164, 1), 
(27, 165, 1), 
(27, 157, 1), 
(27, 161, 1), 
(27, 160, 1), 
(27, 172, 1), 
(27, 156, 1), 
(27, 179, 1), 
(27, 177, 1), 
(28, 163, 1), 
(28, 178, 1), 
(28, 159, 1), 
(28, 171, 1), 
(28, 154, 1), 
(28, 164, 1), 
(28, 165, 1), 
(28, 157, 1), 
(28, 161, 1), 
(28, 160, 1), 
(28, 172, 1), 
(28, 156, 1), 
(28, 179, 1), 
(28, 177, 1), 
(19, 163, 1), 
(19, 178, 1), 
(19, 159, 1), 
(19, 171, 1), 
(19, 154, 1), 
(19, 164, 1), 
(19, 165, 1), 
(19, 157, 1), 
(19, 161, 1), 
(19, 160, 1), 
(19, 172, 1), 
(19, 156, 1), 
(19, 179, 1), 
(19, 177, 1), 
(1, 163, 1), 
(1, 178, 1), 
(1, 159, 1), 
(1, 171, 1), 
(1, 154, 1), 
(1, 164, 1), 
(1, 165, 1), 
(1, 157, 1), 
(1, 161, 1), 
(1, 160, 1), 
(1, 172, 1), 
(1, 156, 1), 
(1, 179, 1), 
(1, 177, 1), 
(2, 163, 2), 
(2, 178, 2), 
(2, 159, 2), 
(2, 171, 2), 
(2, 154, 2), 
(2, 164, 2), 
(2, 165, 2), 
(2, 157, 2), 
(2, 161, 2), 
(2, 160, 2), 
(2, 172, 2), 
(2, 156, 2), 
(2, 179, 2), 
(2, 177, 2), 
(3, 163, 3), 
(3, 178, 3), 
(3, 159, 3), 
(3, 171, 3), 
(3, 154, 3), 
(3, 164, 3), 
(3, 165, 3), 
(3, 157, 3), 
(3, 161, 3), 
(3, 160, 3), 
(3, 172, 3), 
(3, 156, 3), 
(3, 179, 3), 
(3, 177, 3), 
(22, 163, 1), 
(22, 178, 1), 
(22, 159, 1), 
(22, 171, 1), 
(22, 154, 1), 
(22, 164, 1), 
(22, 165, 1), 
(22, 157, 1), 
(22, 161, 1), 
(22, 160, 1), 
(22, 172, 1), 
(22, 156, 1), 
(22, 179, 1), 
(22, 177, 1), 
(17, 163, 1), 
(17, 178, 1), 
(17, 159, 1), 
(17, 171, 1), 
(17, 154, 1), 
(17, 164, 1), 
(17, 165, 1), 
(17, 157, 1), 
(17, 161, 1), 
(17, 160, 1), 
(17, 172, 1), 
(17, 156, 1), 
(17, 179, 1), 
(17, 177, 1), 
(4, 163, 1), 
(4, 178, 1), 
(4, 159, 1), 
(4, 171, 1), 
(4, 154, 1), 
(4, 164, 1), 
(4, 165, 1), 
(4, 157, 1), 
(4, 161, 1), 
(4, 160, 1), 
(4, 172, 1), 
(4, 156, 1), 
(4, 179, 1), 
(4, 177, 1), 
(5, 163, 2), 
(5, 178, 2), 
(5, 159, 2), 
(5, 171, 2), 
(5, 154, 2), 
(5, 164, 2), 
(5, 165, 2), 
(5, 157, 2), 
(5, 161, 2), 
(5, 160, 2), 
(5, 172, 2), 
(5, 156, 2), 
(5, 179, 2), 
(5, 177, 2), 
(6, 163, 3), 
(6, 178, 3), 
(6, 159, 3), 
(6, 171, 3), 
(6, 154, 3), 
(6, 164, 3), 
(6, 165, 3), 
(6, 157, 3), 
(6, 161, 3), 
(6, 160, 3), 
(6, 172, 3), 
(6, 156, 3), 
(6, 179, 3), 
(6, 177, 3), 
(21, 163, 1), 
(21, 178, 1), 
(21, 159, 1), 
(21, 171, 1), 
(21, 154, 1), 
(21, 164, 1), 
(21, 165, 1), 
(21, 157, 1), 
(21, 161, 1), 
(21, 160, 1), 
(21, 172, 1), 
(21, 156, 1), 
(21, 179, 1), 
(21, 177, 1), 
(8, 163, 1), 
(8, 178, 1), 
(8, 159, 1), 
(8, 171, 1), 
(8, 154, 1), 
(8, 164, 1), 
(8, 165, 1), 
(8, 157, 1), 
(8, 161, 1), 
(8, 160, 1), 
(8, 172, 1), 
(8, 156, 1), 
(8, 179, 1), 
(8, 177, 1), 
(20, 163, 1), 
(20, 178, 1), 
(20, 159, 1), 
(20, 171, 1), 
(20, 154, 1), 
(20, 164, 1), 
(20, 165, 1), 
(20, 157, 1), 
(20, 161, 1), 
(20, 160, 1), 
(20, 172, 1), 
(20, 156, 1), 
(20, 179, 1), 
(20, 177, 1), 
(18, 163, 1), 
(18, 178, 1), 
(18, 159, 1), 
(18, 171, 1), 
(18, 154, 1), 
(18, 164, 1), 
(18, 165, 1), 
(18, 157, 1), 
(18, 161, 1), 
(18, 160, 1), 
(18, 172, 1), 
(18, 156, 1), 
(18, 179, 1), 
(18, 177, 1), 
(16, 163, 1), 
(16, 178, 1), 
(16, 159, 1), 
(16, 171, 1), 
(16, 154, 1), 
(16, 164, 1), 
(16, 165, 1), 
(16, 157, 1), 
(16, 161, 1), 
(16, 160, 1), 
(16, 172, 1), 
(16, 156, 1), 
(16, 179, 1), 
(16, 177, 1), 
(10, 163, 1), 
(10, 178, 1), 
(10, 159, 1), 
(10, 171, 1), 
(10, 154, 1), 
(10, 164, 1), 
(10, 165, 1), 
(10, 157, 1), 
(10, 161, 1), 
(10, 160, 1), 
(10, 172, 1), 
(10, 156, 1), 
(10, 179, 1), 
(10, 177, 1), 
(11, 163, 2), 
(11, 178, 2), 
(11, 159, 2), 
(11, 171, 2), 
(11, 154, 2), 
(11, 164, 2), 
(11, 165, 2), 
(11, 157, 2), 
(11, 161, 2), 
(11, 160, 2), 
(11, 172, 2), 
(11, 156, 2), 
(11, 179, 2), 
(11, 177, 2), 
(12, 163, 3), 
(12, 178, 3), 
(12, 159, 3), 
(12, 171, 3), 
(12, 154, 3), 
(12, 164, 3), 
(12, 165, 3), 
(12, 157, 3), 
(12, 161, 3), 
(12, 160, 3), 
(12, 172, 3), 
(12, 156, 3), 
(12, 179, 3), 
(12, 177, 3), 
(13, 163, 4), 
(13, 178, 4), 
(13, 159, 4), 
(13, 171, 4), 
(13, 154, 4), 
(13, 164, 4), 
(13, 165, 4), 
(13, 157, 4), 
(13, 161, 4), 
(13, 160, 4), 
(13, 172, 4), 
(13, 156, 4), 
(13, 179, 4), 
(13, 177, 4), 
(15, 163, 1), 
(15, 178, 1), 
(15, 159, 1), 
(15, 171, 1), 
(15, 154, 1), 
(15, 164, 1), 
(15, 165, 1), 
(15, 157, 1), 
(15, 161, 1), 
(15, 160, 1), 
(15, 172, 1), 
(15, 156, 1), 
(15, 179, 1), 
(15, 177, 1), 
(30, 2, 1), 
(30, 36, 1), 
(30, 39, 1), 
(30, 42, 1), 
(30, 43, 1), 
(30, 54, 1), 
(30, 55, 1), 
(30, 56, 1), 
(30, 57, 1), 
(30, 27, 1), 
(30, 47, 1), 
(30, 122, 1), 
(30, 11, 1), 
(30, 52, 1), 
(30, 5, 1), 
(30, 6, 1), 
(30, 7, 1), 
(30, 13, 1), 
(30, 15, 1), 
(30, 16, 1), 
(30, 51, 1), 
(30, 53, 1), 
(30, 46, 1), 
(30, 163, 1), 
(30, 178, 1), 
(30, 159, 1), 
(30, 171, 1), 
(30, 154, 1), 
(30, 164, 1), 
(30, 165, 1), 
(30, 157, 1), 
(30, 161, 1), 
(30, 160, 1), 
(30, 172, 1), 
(30, 156, 1), 
(30, 179, 1), 
(30, 177, 1), 
(30, 33, 1), 
(30, 32, 1), 
(30, 30, 1), 
(30, 29, 1), 
(30, 31, 1), 
(30, 28, 1), 
(30, 34, 1), 
(30, 24, 1), 
(30, 20, 1), 
(30, 21, 1), 
(30, 26, 1), 
(30, 23, 1), 
(30, 18, 1), 
(30, 25, 1), 
(30, 17, 1), 
(30, 22, 1), 
(30, 19, 1), 
(30, 48, 1), 
(30, 50, 1), 
(30, 58, 1), 
(30, 35, 1), 
(31, 2, 1), 
(31, 36, 1), 
(31, 39, 1), 
(31, 42, 1), 
(31, 43, 1), 
(31, 54, 1), 
(31, 55, 1), 
(31, 56, 1), 
(31, 57, 1), 
(31, 27, 1), 
(31, 47, 1), 
(31, 122, 1), 
(31, 11, 1), 
(31, 52, 1), 
(31, 5, 1), 
(31, 6, 1), 
(31, 7, 1), 
(31, 13, 1), 
(31, 15, 1), 
(31, 16, 1), 
(31, 51, 1), 
(31, 53, 1), 
(31, 46, 1), 
(31, 163, 1), 
(31, 178, 1), 
(31, 159, 1), 
(31, 171, 1), 
(31, 154, 1), 
(31, 164, 1), 
(31, 165, 1), 
(31, 157, 1), 
(31, 161, 1), 
(31, 160, 1), 
(31, 172, 1), 
(31, 156, 1), 
(31, 179, 1), 
(31, 177, 1), 
(31, 33, 1), 
(31, 32, 1), 
(31, 30, 1), 
(31, 29, 1), 
(31, 31, 1), 
(31, 28, 1), 
(31, 34, 1), 
(31, 24, 1), 
(31, 20, 1), 
(31, 21, 1), 
(31, 26, 1), 
(31, 23, 1), 
(31, 18, 1), 
(31, 25, 1), 
(31, 17, 1), 
(31, 22, 1), 
(31, 19, 1), 
(31, 48, 1), 
(31, 50, 1), 
(31, 58, 1), 
(31, 35, 1), 
(32, 2, 1), 
(32, 36, 1), 
(32, 39, 1), 
(32, 42, 1), 
(32, 43, 1), 
(32, 54, 1), 
(32, 55, 1), 
(32, 56, 1), 
(32, 57, 1), 
(32, 27, 1), 
(32, 47, 1), 
(32, 122, 1), 
(32, 11, 1), 
(32, 52, 1), 
(32, 5, 1), 
(32, 6, 1), 
(32, 7, 1), 
(32, 13, 1), 
(32, 15, 1), 
(32, 16, 1), 
(32, 51, 1), 
(32, 53, 1), 
(32, 46, 1), 
(32, 163, 1), 
(32, 178, 1), 
(32, 159, 1), 
(32, 171, 1), 
(32, 154, 1), 
(32, 164, 1), 
(32, 165, 1), 
(32, 157, 1), 
(32, 161, 1), 
(32, 160, 1), 
(32, 172, 1), 
(32, 156, 1), 
(32, 179, 1), 
(32, 177, 1), 
(32, 33, 1), 
(32, 32, 1), 
(32, 30, 1), 
(32, 29, 1), 
(32, 31, 1), 
(32, 28, 1), 
(32, 34, 1), 
(32, 24, 1), 
(32, 20, 1), 
(32, 21, 1), 
(32, 26, 1), 
(32, 23, 1), 
(32, 18, 1), 
(32, 25, 1), 
(32, 17, 1), 
(32, 22, 1), 
(32, 19, 1), 
(32, 48, 1), 
(32, 50, 1), 
(32, 58, 1), 
(32, 35, 1), 
(33, 2, 1), 
(33, 36, 1), 
(33, 39, 1), 
(33, 42, 1), 
(33, 43, 1), 
(33, 54, 1), 
(33, 55, 1), 
(33, 56, 1), 
(33, 57, 1), 
(33, 27, 1), 
(33, 47, 1), 
(33, 122, 1), 
(33, 11, 1), 
(33, 52, 1), 
(33, 5, 1), 
(33, 6, 1), 
(33, 7, 1), 
(33, 13, 1), 
(33, 15, 1), 
(33, 16, 1), 
(33, 51, 1), 
(33, 53, 1), 
(33, 46, 1), 
(33, 163, 1), 
(33, 178, 1), 
(33, 159, 1), 
(33, 171, 1), 
(33, 154, 1), 
(33, 164, 1), 
(33, 165, 1), 
(33, 157, 1), 
(33, 161, 1), 
(33, 160, 1), 
(33, 172, 1), 
(33, 156, 1), 
(33, 179, 1), 
(33, 177, 1), 
(33, 33, 1), 
(33, 32, 1), 
(33, 30, 1), 
(33, 29, 1), 
(33, 31, 1), 
(33, 28, 1), 
(33, 34, 1), 
(33, 24, 1), 
(33, 20, 1), 
(33, 21, 1), 
(33, 26, 1), 
(33, 23, 1), 
(33, 18, 1), 
(33, 25, 1), 
(33, 17, 1), 
(33, 22, 1), 
(33, 19, 1), 
(33, 48, 1), 
(33, 50, 1), 
(33, 58, 1), 
(33, 35, 1), 
(34, 2, 1), 
(34, 36, 1), 
(34, 39, 1), 
(34, 42, 1), 
(34, 43, 1), 
(34, 54, 1), 
(34, 55, 1), 
(34, 56, 1), 
(34, 57, 1), 
(34, 27, 1), 
(34, 47, 1), 
(34, 122, 1), 
(34, 11, 1), 
(34, 52, 1), 
(34, 5, 1), 
(34, 6, 1), 
(34, 7, 1), 
(34, 13, 1), 
(34, 15, 1), 
(34, 16, 1), 
(34, 51, 1), 
(34, 53, 1), 
(34, 46, 1), 
(34, 163, 1), 
(34, 178, 1), 
(34, 159, 1), 
(34, 171, 1), 
(34, 154, 1), 
(34, 164, 1), 
(34, 165, 1), 
(34, 157, 1), 
(34, 161, 1), 
(34, 160, 1), 
(34, 172, 1), 
(34, 156, 1), 
(34, 179, 1), 
(34, 177, 1), 
(34, 33, 1), 
(34, 32, 1), 
(34, 30, 1), 
(34, 29, 1), 
(34, 31, 1), 
(34, 28, 1), 
(34, 34, 1), 
(34, 24, 1), 
(34, 20, 1), 
(34, 21, 1), 
(34, 26, 1), 
(34, 23, 1), 
(34, 18, 1), 
(34, 25, 1), 
(34, 17, 1), 
(34, 22, 1), 
(34, 19, 1), 
(34, 48, 1), 
(34, 50, 1), 
(34, 58, 1), 
(34, 35, 1), 
(35, 2, 1), 
(35, 36, 1), 
(35, 39, 1), 
(35, 42, 1), 
(35, 43, 1), 
(35, 54, 1), 
(35, 55, 1), 
(35, 56, 1), 
(35, 57, 1), 
(35, 27, 1), 
(35, 47, 1), 
(35, 122, 1), 
(35, 11, 1), 
(35, 52, 1), 
(35, 5, 1), 
(35, 6, 1), 
(35, 7, 1), 
(35, 13, 1), 
(35, 15, 1), 
(35, 16, 1), 
(35, 51, 1), 
(35, 53, 1), 
(35, 46, 1), 
(35, 163, 1), 
(35, 178, 1), 
(35, 159, 1), 
(35, 171, 1), 
(35, 154, 1), 
(35, 164, 1), 
(35, 165, 1), 
(35, 157, 1), 
(35, 161, 1), 
(35, 160, 1), 
(35, 172, 1), 
(35, 156, 1), 
(35, 179, 1), 
(35, 177, 1), 
(35, 33, 1), 
(35, 32, 1), 
(35, 30, 1), 
(35, 29, 1), 
(35, 31, 1), 
(35, 28, 1), 
(35, 34, 1), 
(35, 24, 1), 
(35, 20, 1), 
(35, 21, 1), 
(35, 26, 1), 
(35, 23, 1), 
(35, 18, 1), 
(35, 25, 1), 
(35, 17, 1), 
(35, 22, 1), 
(35, 19, 1), 
(35, 48, 1), 
(35, 50, 1), 
(35, 58, 1), 
(35, 35, 1), 
(36, 2, 1), 
(36, 36, 1), 
(36, 39, 1), 
(36, 42, 1), 
(36, 43, 1), 
(36, 54, 1), 
(36, 55, 1), 
(36, 56, 1), 
(36, 57, 1), 
(36, 27, 1), 
(36, 47, 1), 
(36, 122, 1), 
(36, 11, 1), 
(36, 52, 1), 
(36, 5, 1), 
(36, 6, 1), 
(36, 7, 1), 
(36, 13, 1), 
(36, 15, 1), 
(36, 16, 1), 
(36, 51, 1), 
(36, 53, 1), 
(36, 46, 1), 
(36, 163, 1), 
(36, 178, 1), 
(36, 159, 1), 
(36, 171, 1), 
(36, 154, 1), 
(36, 164, 1), 
(36, 165, 1), 
(36, 157, 1), 
(36, 161, 1), 
(36, 160, 1), 
(36, 172, 1), 
(36, 156, 1), 
(36, 179, 1), 
(36, 177, 1), 
(36, 33, 1), 
(36, 32, 1), 
(36, 30, 1), 
(36, 29, 1), 
(36, 31, 1), 
(36, 28, 1), 
(36, 34, 1), 
(36, 24, 1), 
(36, 20, 1), 
(36, 21, 1), 
(36, 26, 1), 
(36, 23, 1), 
(36, 18, 1), 
(36, 25, 1), 
(36, 17, 1), 
(36, 22, 1), 
(36, 19, 1), 
(36, 48, 1), 
(36, 50, 1), 
(36, 58, 1), 
(36, 35, 1), 
(37, 2, 1), 
(37, 36, 1), 
(37, 39, 1), 
(37, 42, 1), 
(37, 43, 1), 
(37, 54, 1), 
(37, 55, 1), 
(37, 56, 1), 
(37, 57, 1), 
(37, 27, 1), 
(37, 47, 1), 
(37, 122, 1), 
(37, 11, 1), 
(37, 52, 1), 
(37, 5, 1), 
(37, 6, 1), 
(37, 7, 1), 
(37, 13, 1), 
(37, 15, 1), 
(37, 16, 1), 
(37, 51, 1), 
(37, 53, 1), 
(37, 46, 1), 
(37, 163, 1), 
(37, 178, 1), 
(37, 159, 1), 
(37, 171, 1), 
(37, 154, 1), 
(37, 164, 1), 
(37, 165, 1), 
(37, 157, 1), 
(37, 161, 1), 
(37, 160, 1), 
(37, 172, 1), 
(37, 156, 1), 
(37, 179, 1), 
(37, 177, 1), 
(37, 33, 1), 
(37, 32, 1), 
(37, 30, 1), 
(37, 29, 1), 
(37, 31, 1), 
(37, 28, 1), 
(37, 34, 1), 
(37, 24, 1), 
(37, 20, 1), 
(37, 21, 1), 
(37, 26, 1), 
(37, 23, 1), 
(37, 18, 1), 
(37, 25, 1), 
(37, 17, 1), 
(37, 22, 1), 
(37, 19, 1), 
(37, 48, 1), 
(37, 50, 1), 
(37, 58, 1), 
(37, 35, 1), 
(38, 2, 1), 
(38, 36, 1), 
(38, 39, 1), 
(38, 42, 1), 
(38, 43, 1), 
(38, 54, 1), 
(38, 55, 1), 
(38, 56, 1), 
(38, 57, 1), 
(38, 27, 1), 
(38, 47, 1), 
(38, 122, 1), 
(38, 11, 1), 
(38, 52, 1), 
(38, 5, 1), 
(38, 6, 1), 
(38, 7, 1), 
(38, 13, 1), 
(38, 15, 1), 
(38, 16, 1), 
(38, 51, 1), 
(38, 53, 1), 
(38, 46, 1), 
(38, 163, 1), 
(38, 178, 1), 
(38, 159, 1), 
(38, 171, 1), 
(38, 154, 1), 
(38, 164, 1), 
(38, 165, 1), 
(38, 157, 1), 
(38, 161, 1), 
(38, 160, 1), 
(38, 172, 1), 
(38, 156, 1), 
(38, 179, 1), 
(38, 177, 1), 
(38, 33, 1), 
(38, 32, 1), 
(38, 30, 1), 
(38, 29, 1), 
(38, 31, 1), 
(38, 28, 1), 
(38, 34, 1), 
(38, 24, 1), 
(38, 20, 1), 
(38, 21, 1), 
(38, 26, 1), 
(38, 23, 1), 
(38, 18, 1), 
(38, 25, 1), 
(38, 17, 1), 
(38, 22, 1), 
(38, 19, 1), 
(38, 48, 1), 
(38, 50, 1), 
(38, 58, 1), 
(38, 35, 1), 
(39, 2, 1), 
(39, 36, 1), 
(39, 39, 1), 
(39, 42, 1), 
(39, 43, 1), 
(39, 54, 1), 
(39, 55, 1), 
(39, 56, 1), 
(39, 57, 1), 
(39, 27, 1), 
(39, 47, 1), 
(39, 122, 1), 
(39, 11, 1), 
(39, 52, 1), 
(39, 5, 1), 
(39, 6, 1), 
(39, 7, 1), 
(39, 13, 1), 
(39, 15, 1), 
(39, 16, 1), 
(39, 51, 1), 
(39, 53, 1), 
(39, 46, 1), 
(39, 163, 1), 
(39, 178, 1), 
(39, 159, 1), 
(39, 171, 1), 
(39, 154, 1), 
(39, 164, 1), 
(39, 165, 1), 
(39, 157, 1), 
(39, 161, 1), 
(39, 160, 1), 
(39, 172, 1), 
(39, 156, 1), 
(39, 179, 1), 
(39, 177, 1), 
(39, 33, 1), 
(39, 32, 1), 
(39, 30, 1), 
(39, 29, 1), 
(39, 31, 1), 
(39, 28, 1), 
(39, 34, 1), 
(39, 24, 1), 
(39, 20, 1), 
(39, 21, 1), 
(39, 26, 1), 
(39, 23, 1), 
(39, 18, 1), 
(39, 25, 1), 
(39, 17, 1), 
(39, 22, 1), 
(39, 19, 1), 
(39, 48, 1), 
(39, 50, 1), 
(39, 58, 1), 
(39, 35, 1), 
(40, 2, 1), 
(40, 36, 1), 
(40, 39, 1), 
(40, 42, 1), 
(40, 43, 1), 
(40, 54, 1), 
(40, 55, 1), 
(40, 56, 1), 
(40, 57, 1), 
(40, 27, 1), 
(40, 47, 1), 
(40, 122, 1), 
(40, 11, 1), 
(40, 52, 1), 
(40, 5, 1), 
(40, 6, 1), 
(40, 7, 1), 
(40, 13, 1), 
(40, 15, 1), 
(40, 16, 1), 
(40, 51, 1), 
(40, 53, 1), 
(40, 46, 1), 
(40, 163, 1), 
(40, 178, 1), 
(40, 159, 1), 
(40, 171, 1), 
(40, 154, 1), 
(40, 164, 1), 
(40, 165, 1), 
(40, 157, 1), 
(40, 161, 1), 
(40, 160, 1), 
(40, 172, 1), 
(40, 156, 1), 
(40, 179, 1), 
(40, 177, 1), 
(40, 33, 1), 
(40, 32, 1), 
(40, 30, 1), 
(40, 29, 1), 
(40, 31, 1), 
(40, 28, 1), 
(40, 34, 1), 
(40, 24, 1), 
(40, 20, 1), 
(40, 21, 1), 
(40, 26, 1), 
(40, 23, 1), 
(40, 18, 1), 
(40, 25, 1), 
(40, 17, 1), 
(40, 22, 1), 
(40, 19, 1), 
(40, 48, 1), 
(40, 50, 1), 
(40, 58, 1), 
(40, 35, 1), 
(41, 2, 1), 
(41, 36, 1), 
(41, 39, 1), 
(41, 42, 1), 
(41, 43, 1), 
(41, 54, 1), 
(41, 55, 1), 
(41, 56, 1), 
(41, 57, 1), 
(41, 27, 1), 
(41, 47, 1), 
(41, 122, 1), 
(41, 11, 1), 
(41, 52, 1), 
(41, 5, 1), 
(41, 6, 1), 
(41, 7, 1), 
(41, 13, 1), 
(41, 15, 1), 
(41, 16, 1), 
(41, 51, 1), 
(41, 53, 1), 
(41, 46, 1), 
(41, 163, 1), 
(41, 178, 1), 
(41, 159, 1), 
(41, 171, 1), 
(41, 154, 1), 
(41, 164, 1), 
(41, 165, 1), 
(41, 157, 1), 
(41, 161, 1), 
(41, 160, 1), 
(41, 172, 1), 
(41, 156, 1), 
(41, 179, 1), 
(41, 177, 1), 
(41, 33, 1), 
(41, 32, 1), 
(41, 30, 1), 
(41, 29, 1), 
(41, 31, 1), 
(41, 28, 1), 
(41, 34, 1), 
(41, 24, 1), 
(41, 20, 1), 
(41, 21, 1), 
(41, 26, 1), 
(41, 23, 1), 
(41, 18, 1), 
(41, 25, 1), 
(41, 17, 1), 
(41, 22, 1), 
(41, 19, 1), 
(41, 48, 1), 
(41, 50, 1), 
(41, 58, 1), 
(41, 35, 1), 
(42, 2, 1), 
(42, 36, 1), 
(42, 39, 1), 
(42, 42, 1), 
(42, 43, 1), 
(42, 54, 1), 
(42, 55, 1), 
(42, 56, 1), 
(42, 57, 1), 
(42, 27, 1), 
(42, 47, 1), 
(42, 122, 1), 
(42, 11, 1), 
(42, 52, 1), 
(42, 5, 1), 
(42, 6, 1), 
(42, 7, 1), 
(42, 13, 1), 
(42, 15, 1), 
(42, 16, 1), 
(42, 51, 1), 
(42, 53, 1), 
(42, 46, 1), 
(42, 163, 1), 
(42, 178, 1), 
(42, 159, 1), 
(42, 171, 1), 
(42, 154, 1), 
(42, 164, 1), 
(42, 165, 1), 
(42, 157, 1), 
(42, 161, 1), 
(42, 160, 1), 
(42, 172, 1), 
(42, 156, 1), 
(42, 179, 1), 
(42, 177, 1), 
(42, 33, 1), 
(42, 32, 1), 
(42, 30, 1), 
(42, 29, 1), 
(42, 31, 1), 
(42, 28, 1), 
(42, 34, 1), 
(42, 24, 1), 
(42, 20, 1), 
(42, 21, 1), 
(42, 26, 1), 
(42, 23, 1), 
(42, 18, 1), 
(42, 25, 1), 
(42, 17, 1), 
(42, 22, 1), 
(42, 19, 1), 
(42, 48, 1), 
(42, 50, 1), 
(42, 58, 1), 
(42, 35, 1), 
(43, 2, 1), 
(43, 36, 1), 
(43, 39, 1), 
(43, 42, 1), 
(43, 43, 1), 
(43, 54, 1), 
(43, 55, 1), 
(43, 56, 1), 
(43, 57, 1), 
(43, 27, 1), 
(43, 47, 1), 
(43, 122, 1), 
(43, 11, 1), 
(43, 52, 1), 
(43, 5, 1), 
(43, 6, 1), 
(43, 7, 1), 
(43, 13, 1), 
(43, 15, 1), 
(43, 16, 1), 
(43, 51, 1), 
(43, 53, 1), 
(43, 46, 1), 
(43, 163, 1), 
(43, 178, 1), 
(43, 159, 1), 
(43, 171, 1), 
(43, 154, 1), 
(43, 164, 1), 
(43, 165, 1), 
(43, 157, 1), 
(43, 161, 1), 
(43, 160, 1), 
(43, 172, 1), 
(43, 156, 1), 
(43, 179, 1), 
(43, 177, 1), 
(43, 33, 1), 
(43, 32, 1), 
(43, 30, 1), 
(43, 29, 1), 
(43, 31, 1), 
(43, 28, 1), 
(43, 34, 1), 
(43, 24, 1), 
(43, 20, 1), 
(43, 21, 1), 
(43, 26, 1), 
(43, 23, 1), 
(43, 18, 1), 
(43, 25, 1), 
(43, 17, 1), 
(43, 22, 1), 
(43, 19, 1), 
(43, 48, 1), 
(43, 50, 1), 
(43, 58, 1), 
(43, 35, 1), 
(46, 2, 1), 
(46, 11, 1), 
(46, 52, 1), 
(46, 5, 1), 
(46, 6, 1), 
(46, 7, 1), 
(46, 13, 1), 
(46, 15, 1), 
(46, 16, 1), 
(46, 51, 1), 
(46, 24, 1), 
(46, 20, 1), 
(46, 21, 1), 
(46, 26, 1), 
(46, 23, 1), 
(46, 18, 1), 
(46, 25, 1), 
(46, 17, 1), 
(46, 22, 1), 
(46, 19, 1), 
(46, 48, 1), 
(46, 50, 1), 
(46, 58, 1), 
(46, 27, 1), 
(46, 33, 1), 
(46, 32, 1), 
(46, 30, 1), 
(46, 29, 1), 
(46, 31, 1), 
(46, 28, 1), 
(46, 34, 1), 
(46, 35, 1), 
(46, 36, 1), 
(46, 39, 1), 
(46, 42, 1), 
(46, 43, 1), 
(46, 46, 1), 
(46, 47, 1), 
(46, 53, 1), 
(46, 54, 1), 
(46, 55, 1), 
(46, 56, 1), 
(46, 57, 1), 
(46, 122, 1), 
(46, 163, 1), 
(46, 178, 1), 
(46, 159, 1), 
(46, 171, 1), 
(46, 154, 1), 
(46, 164, 1), 
(46, 165, 1), 
(46, 157, 1), 
(46, 161, 1), 
(46, 160, 1), 
(46, 172, 1), 
(46, 156, 1), 
(46, 179, 1), 
(46, 177, 1), 
(24, 183, 1), 
(24, 184, 1), 
(24, 181, 1), 
(24, 182, 1), 
(29, 183, 1), 
(29, 184, 1), 
(29, 181, 1), 
(29, 182, 1), 
(26, 183, 1), 
(26, 184, 1), 
(26, 181, 1), 
(26, 182, 1), 
(25, 183, 1), 
(25, 184, 1), 
(25, 181, 1), 
(25, 182, 1), 
(23, 183, 1), 
(23, 184, 1), 
(23, 181, 1), 
(23, 182, 1), 
(27, 183, 1), 
(27, 184, 1), 
(27, 181, 1), 
(27, 182, 1), 
(28, 183, 1), 
(28, 184, 1), 
(28, 181, 1), 
(28, 182, 1), 
(19, 183, 1), 
(19, 184, 1), 
(19, 181, 1), 
(19, 182, 1), 
(46, 183, 1), 
(46, 184, 1), 
(46, 181, 1), 
(46, 182, 1), 
(1, 183, 1), 
(1, 184, 1), 
(1, 181, 1), 
(1, 182, 1), 
(2, 183, 2), 
(2, 184, 2), 
(2, 181, 2), 
(2, 182, 2), 
(3, 183, 3), 
(3, 184, 3), 
(3, 181, 3), 
(3, 182, 3), 
(22, 183, 1), 
(22, 184, 1), 
(22, 181, 1), 
(22, 182, 1), 
(17, 183, 1), 
(17, 184, 1), 
(17, 181, 1), 
(17, 182, 1), 
(4, 183, 1), 
(4, 184, 1), 
(4, 181, 1), 
(4, 182, 1), 
(5, 183, 2), 
(5, 184, 2), 
(5, 181, 2), 
(5, 182, 2), 
(6, 183, 3), 
(6, 184, 3), 
(6, 181, 3), 
(6, 182, 3), 
(21, 183, 1), 
(21, 184, 1), 
(21, 181, 1), 
(21, 182, 1), 
(8, 183, 1), 
(8, 184, 1), 
(8, 181, 1), 
(8, 182, 1), 
(20, 183, 1), 
(20, 184, 1), 
(20, 181, 1), 
(20, 182, 1), 
(18, 183, 1), 
(18, 184, 1), 
(18, 181, 1), 
(18, 182, 1), 
(16, 183, 1), 
(16, 184, 1), 
(16, 181, 1), 
(16, 182, 1), 
(10, 183, 1), 
(10, 184, 1), 
(10, 181, 1), 
(10, 182, 1), 
(11, 183, 2), 
(11, 184, 2), 
(11, 181, 2), 
(11, 182, 2), 
(12, 183, 3), 
(12, 184, 3), 
(12, 181, 3), 
(12, 182, 3), 
(13, 183, 4), 
(13, 184, 4), 
(13, 181, 4), 
(13, 182, 4), 
(15, 183, 1), 
(15, 184, 1), 
(15, 181, 1), 
(15, 182, 1), 
(31, 183, 1), 
(31, 184, 1), 
(31, 181, 1), 
(31, 182, 1), 
(35, 183, 1), 
(35, 184, 1), 
(35, 181, 1), 
(35, 182, 1), 
(43, 183, 1), 
(43, 184, 1), 
(43, 181, 1), 
(43, 182, 1), 
(30, 183, 1), 
(30, 184, 1), 
(30, 181, 1), 
(30, 182, 1), 
(36, 183, 1), 
(36, 184, 1), 
(36, 181, 1), 
(36, 182, 1), 
(37, 183, 1), 
(37, 184, 1), 
(37, 181, 1), 
(37, 182, 1), 
(33, 183, 1), 
(33, 184, 1), 
(33, 181, 1), 
(33, 182, 1), 
(42, 183, 1), 
(42, 184, 1), 
(42, 181, 1), 
(42, 182, 1), 
(32, 183, 1), 
(32, 184, 1), 
(32, 181, 1), 
(32, 182, 1), 
(39, 183, 1), 
(39, 184, 1), 
(39, 181, 1), 
(39, 182, 1), 
(38, 183, 1), 
(38, 184, 1), 
(38, 181, 1), 
(38, 182, 1), 
(34, 183, 1), 
(34, 184, 1), 
(34, 181, 1), 
(34, 182, 1), 
(40, 183, 1), 
(40, 184, 1), 
(40, 181, 1), 
(40, 182, 1), 
(41, 183, 1), 
(41, 184, 1), 
(41, 181, 1), 
(41, 182, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_comments`
--

DROP TABLE IF EXISTS `nv4_vi_comments`;
CREATE TABLE `nv4_vi_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `area` tinyint(4) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_department`
--

DROP TABLE IF EXISTS `nv4_vi_contact_department`;
CREATE TABLE `nv4_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `yahoo` varchar(100) NOT NULL,
  `skype` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `admins` text NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_contact_department`
--

INSERT INTO `nv4_vi_contact_department` VALUES
(1, 'Webmaster', '', '', '', '', '', '', '1/1/1/0;', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_reply`
--

DROP TABLE IF EXISTS `nv4_vi_contact_reply`;
CREATE TABLE `nv4_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_send`
--

DROP TABLE IF EXISTS `nv4_vi_contact_send`;
CREATE TABLE `nv4_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) DEFAULT '',
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu`
--

DROP TABLE IF EXISTS `nv4_vi_menu`;
CREATE TABLE `nv4_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_menu`
--

INSERT INTO `nv4_vi_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu_rows`
--

DROP TABLE IF EXISTS `nv4_vi_menu_rows`;
CREATE TABLE `nv4_vi_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `note` varchar(255) DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text,
  `groups_view` varchar(255) DEFAULT '',
  `module_name` varchar(255) DEFAULT '',
  `op` varchar(255) DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255) DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=35  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_menu_rows`
--

INSERT INTO `nv4_vi_menu_rows` VALUES
(1, 0, 1, 'Giới thiệu', '/nukeviet-my/index.php?language=vi&nv=about', '', '', 1, 1, 0, '2,3', '6', 'about', '', 1, '', 1, 1), 
(2, 1, 1, 'Giới thiệu về NukeViet 3.0', '/nukeviet-my/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-NukeViet-3-0', '', '', 1, 2, 1, '', '6', 'about', 'Gioi-thieu-ve-NukeViet-3-0', 1, '', 1, 1), 
(3, 1, 1, 'Giới thiệu về công ty chuyên quản NukeViet', '/nukeviet-my/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '', '', 2, 3, 1, '', '6', 'about', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', 1, '', 1, 1), 
(4, 0, 1, 'Tin Tức', '/nukeviet-my/index.php?language=vi&nv=news', '', '', 2, 4, 0, '5,6,7,8,30,31,32', '6', 'news', '', 1, '', 1, 1), 
(5, 4, 1, 'Tin tức', '/nukeviet-my/index.php?language=vi&nv=news&amp;op=Tin-tuc', '', '', 1, 5, 1, '', '6', 'news', 'Tin-tuc', 1, '', 1, 1), 
(6, 4, 1, 'Sản phẩm', '/nukeviet-my/index.php?language=vi&nv=news&amp;op=San-pham', '', '', 2, 6, 1, '', '6', 'news', 'San-pham', 1, '', 1, 1), 
(7, 4, 1, 'Đối tác', '/nukeviet-my/index.php?language=vi&nv=news&amp;op=Doi-tac', '', '', 3, 7, 1, '', '6', 'news', 'Doi-tac', 1, '', 1, 1), 
(8, 4, 1, 'Tuyển dụng', '/nukeviet-my/index.php?language=vi&nv=news&amp;op=Tuyen-dung', '', '', 4, 8, 1, '', '6', 'news', 'Tuyen-dung', 1, '', 1, 1), 
(9, 0, 1, 'Thành viên', '/nukeviet-my/index.php?language=vi&nv=users', '', '', 3, 12, 0, '10,11,12,13,14,15,16', '6', 'users', '', 1, '', 1, 1), 
(10, 9, 1, 'Đăng nhập', '/nukeviet-my/index.php?language=vi&nv=users&op=login', '', '', 1, 13, 1, '', '5', 'users', 'login', 1, '', 1, 1), 
(11, 9, 1, 'Logout', '/nukeviet-my/index.php?language=vi&nv=users&op=logout', '', '', 2, 14, 1, '', '4', 'users', 'logout', 1, '', 1, 1), 
(12, 9, 1, 'Đăng ký', '/nukeviet-my/index.php?language=vi&nv=users&op=register', '', '', 3, 15, 1, '', '5', 'users', 'register', 1, '', 1, 1), 
(13, 9, 1, 'Quên mật khẩu', '/nukeviet-my/index.php?language=vi&nv=users&op=lostpass', '', '', 4, 16, 1, '', '5', 'users', 'lostpass', 1, '', 1, 1), 
(14, 9, 1, 'Đổi mật khẩu', '/nukeviet-my/index.php?language=vi&nv=users&op=changepass', '', '', 5, 17, 1, '', '4', 'users', 'changepass', 1, '', 1, 1), 
(15, 9, 1, 'Openid', '/nukeviet-my/index.php?language=vi&nv=users&op=openid', '', '', 6, 18, 1, '', '4', 'users', 'openid', 1, '', 1, 1), 
(16, 9, 1, 'Danh sách thành viên', '/nukeviet-my/index.php?language=vi&nv=users&op=memberlist', '', '', 7, 19, 1, '', '4', 'users', 'memberlist', 1, '', 1, 1), 
(17, 0, 1, 'Liên hệ', '/nukeviet-my/index.php?language=vi&nv=contact', '', '', 7, 28, 0, '18', '6', 'contact', '', 1, '', 1, 1), 
(18, 17, 1, 'Webmaster', '/nukeviet-my/index.php?language=vi&nv=contact&amp;op=1', '', '', 1, 29, 1, '', '6', 'contact', '1', 1, '', 1, 1), 
(19, 0, 1, 'Thống kê', '/nukeviet-my/index.php?language=vi&nv=statistics', '', '', 4, 20, 0, '20,21,22,23,24', '6', 'statistics', '', 1, '', 1, 1), 
(20, 19, 1, 'Theo đường dẫn đến site', '/nukeviet-my/index.php?language=vi&nv=statistics&amp;op=allreferers', '', '', 1, 21, 1, '', '6', 'statistics', 'allreferers', 1, '', 1, 1), 
(21, 19, 1, 'Theo quốc gia', '/nukeviet-my/index.php?language=vi&nv=statistics&amp;op=allcountries', '', '', 2, 22, 1, '', '6', 'statistics', 'allcountries', 1, '', 1, 1), 
(22, 19, 1, 'Theo trình duyệt', '/nukeviet-my/index.php?language=vi&nv=statistics&amp;op=allbrowsers', '', '', 3, 23, 1, '', '6', 'statistics', 'allbrowsers', 1, '', 1, 1), 
(23, 19, 1, 'Theo hệ điều hành', '/nukeviet-my/index.php?language=vi&nv=statistics&amp;op=allos', '', '', 4, 24, 1, '', '6', 'statistics', 'allos', 1, '', 1, 1), 
(24, 19, 1, 'Máy chủ tìm kiếm', '/nukeviet-my/index.php?language=vi&nv=statistics&amp;op=allbots', '', '', 5, 25, 1, '', '6', 'statistics', 'allbots', 1, '', 1, 1), 
(25, 0, 1, 'Thăm dò ý kiến', '/nukeviet-my/index.php?language=vi&nv=voting', '', '', 5, 26, 0, '', '6', 'voting', '', 1, '', 1, 1), 
(30, 4, 1, 'Rss', '/nukeviet-my/index.php?language=vi&nv=news&op=rss', '', '', 5, 9, 1, '', '6', 'news', 'rss', 1, '', 0, 1), 
(27, 0, 1, 'Tìm kiếm', '/nukeviet-my/index.php?language=vi&nv=seek', '', '', 6, 27, 0, '', '6', 'seek', '', 1, '', 1, 1), 
(31, 4, 1, 'Đăng bài viết', '/nukeviet-my/index.php?language=vi&nv=news&op=content', '', '', 6, 10, 1, '', '6', 'news', 'content', 1, '', 0, 1), 
(32, 4, 1, 'Tìm kiếm', '/nukeviet-my/index.php?language=vi&nv=news&op=search', '', '', 7, 11, 1, '', '6', 'news', 'search', 1, '', 0, 1), 
(33, 0, 1, 'make theme', '/nukeviet-my/index.php?language=vi&nv=make-theme', '', '', 8, 30, 0, '', '6', 'make-theme', '', 1, '', 0, 1), 
(34, 0, 1, 'nvtools', '/nukeviet-my/index.php?language=vi&nv=nvtools', '', '', 9, 31, 0, '', '6', 'nvtools', '', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modfuncs`
--

DROP TABLE IF EXISTS `nv4_vi_modfuncs`;
CREATE TABLE `nv4_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `alias` varchar(55) NOT NULL DEFAULT '',
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=185  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modfuncs`
--

INSERT INTO `nv4_vi_modfuncs` VALUES
(1, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(2, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(3, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(5, 'content', 'content', 'Content', 'news', 1, 1, 3, ''), 
(6, 'detail', 'detail', 'Detail', 'news', 1, 0, 4, ''), 
(7, 'main', 'main', 'Main', 'news', 1, 0, 5, ''), 
(9, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(10, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(11, 'rss', 'rss', 'Rss', 'news', 1, 1, 1, ''), 
(12, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(13, 'search', 'search', 'Search', 'news', 1, 1, 6, ''), 
(14, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(15, 'topic', 'topic', 'Topic', 'news', 1, 0, 7, ''), 
(16, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 8, ''), 
(17, 'active', 'active', 'Active', 'users', 1, 1, 8, ''), 
(18, 'changepass', 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, ''), 
(19, 'editinfo', 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''), 
(20, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(21, 'logout', 'logout', 'Logout', 'users', 1, 1, 3, ''), 
(22, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''), 
(23, 'lostpass', 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, ''), 
(24, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(25, 'openid', 'openid', 'Openid', 'users', 1, 1, 7, ''), 
(26, 'register', 'register', 'Đăng ký', 'users', 1, 1, 4, ''), 
(27, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(28, 'allbots', 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(29, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(30, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(31, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(32, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(33, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(34, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(35, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(36, 'addads', 'addads', 'Addads', 'banners', 1, 0, 1, ''), 
(37, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(38, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(39, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''), 
(40, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(41, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(42, 'main', 'main', 'Main', 'banners', 1, 0, 3, ''), 
(43, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(44, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(46, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(47, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(48, 'regroups', 'regroups', 'Nhóm thành viên', 'users', 1, 0, 11, ''), 
(50, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 12, ''), 
(51, 'groups', 'groups', 'Groups', 'news', 1, 0, 9, ''), 
(52, 'tag', 'tag', 'Tag', 'news', 1, 0, 2, ''), 
(53, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(54, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(55, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(56, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(57, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(58, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 13, ''), 
(172, 'search_result', 'search_result', 'Search_result', 'shops', 1, 0, 11, ''), 
(173, 'sendmail', 'sendmail', 'Sendmail', 'shops', 0, 0, 0, ''), 
(174, 'service', 'service', 'Service', 'shops', 0, 0, 0, ''), 
(175, 'setcart', 'setcart', 'Setcart', 'shops', 0, 0, 0, ''), 
(184, 'theme', 'theme', 'Theme', 'nvtools', 1, 1, 2, ''), 
(183, 'main', 'main', 'Main', 'nvtools', 1, 1, 1, ''), 
(182, 'data', 'data', 'Data', 'nvtools', 1, 1, 4, ''), 
(180, 'wishlist_update', 'wishlist_update', 'Wishlist_update', 'shops', 0, 0, 0, ''), 
(181, 'checktable', 'checktable', 'Checktable', 'nvtools', 1, 1, 3, ''), 
(178, 'viewcat', 'viewcat', 'Viewcat', 'shops', 1, 0, 2, ''), 
(179, 'wishlist', 'wishlist', 'Wishlist', 'shops', 1, 0, 13, ''), 
(177, 'tag', 'tag', 'Tag', 'shops', 1, 0, 14, ''), 
(176, 'sitemap', 'sitemap', 'Sitemap', 'shops', 0, 0, 0, ''), 
(171, 'search', 'search', 'Search', 'shops', 1, 0, 4, ''), 
(170, 'rss', 'rss', 'Rss', 'shops', 0, 0, 0, ''), 
(159, 'detail', 'detail', 'Detail', 'shops', 1, 0, 3, ''), 
(160, 'group', 'group', 'Group', 'shops', 1, 0, 10, ''), 
(161, 'history', 'history', 'History', 'shops', 1, 0, 9, ''), 
(162, 'loadcart', 'loadcart', 'Loadcart', 'shops', 0, 0, 0, ''), 
(163, 'main', 'main', 'Main', 'shops', 1, 0, 1, ''), 
(164, 'order', 'order', 'Order', 'shops', 1, 0, 6, ''), 
(165, 'payment', 'payment', 'Payment', 'shops', 1, 0, 7, ''), 
(166, 'print', 'print', 'Print', 'shops', 0, 0, 0, ''), 
(167, 'print_pro', 'print_pro', 'Print_pro', 'shops', 0, 0, 0, ''), 
(168, 'rate', 'rate', 'Rate', 'shops', 0, 0, 0, ''), 
(169, 'remove', 'remove', 'Remove', 'shops', 0, 0, 0, ''), 
(154, 'cart', 'cart', 'Cart', 'shops', 1, 0, 5, ''), 
(155, 'checkorder', 'checkorder', 'Checkorder', 'shops', 0, 0, 0, ''), 
(156, 'compare', 'compare', 'Compare', 'shops', 1, 0, 12, ''), 
(157, 'complete', 'complete', 'Complete', 'shops', 1, 0, 8, ''), 
(122, 'main', 'main', 'Main', 'make-theme', 1, 0, 1, ''), 
(158, 'delhis', 'delhis', 'Delhis', 'shops', 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modthemes`
--

DROP TABLE IF EXISTS `nv4_vi_modthemes`;
CREATE TABLE `nv4_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modthemes`
--

INSERT INTO `nv4_vi_modthemes` VALUES
(0, 'body', 'ala'), 
(0, 'body', 'mobile_nukeviet'), 
(0, 'body', 'xe'), 
(0, 'body-right', 'modern'), 
(0, 'left-body-right', 'default'), 
(2, 'body', 'ala'), 
(2, 'body', 'mobile_nukeviet'), 
(2, 'body', 'modern'), 
(2, 'body', 'xe'), 
(2, 'left-body-right', 'default'), 
(5, 'body', 'ala'), 
(5, 'body', 'mobile_nukeviet'), 
(5, 'body', 'xe'), 
(5, 'body-right', 'modern'), 
(5, 'left-body-right', 'default'), 
(6, 'body', 'ala'), 
(6, 'body', 'mobile_nukeviet'), 
(6, 'body', 'xe'), 
(6, 'body-right', 'modern'), 
(6, 'left-body-right', 'default'), 
(7, 'body', 'ala'), 
(7, 'body', 'mobile_nukeviet'), 
(7, 'body', 'xe'), 
(7, 'body-right', 'modern'), 
(7, 'left-body-right', 'default'), 
(11, 'body', 'ala'), 
(11, 'body', 'xe'), 
(11, 'body-right', 'modern'), 
(11, 'left-body-right', 'default'), 
(13, 'body', 'ala'), 
(13, 'body', 'mobile_nukeviet'), 
(13, 'body', 'xe'), 
(13, 'body-right', 'modern'), 
(13, 'left-body-right', 'default'), 
(15, 'body', 'ala'), 
(15, 'body', 'mobile_nukeviet'), 
(15, 'body', 'xe'), 
(15, 'body-right', 'modern'), 
(15, 'left-body-right', 'default'), 
(16, 'body', 'ala'), 
(16, 'body', 'mobile_nukeviet'), 
(16, 'body', 'xe'), 
(16, 'body-right', 'modern'), 
(16, 'left-body-right', 'default'), 
(17, 'body', 'ala'), 
(17, 'body', 'mobile_nukeviet'), 
(17, 'body', 'xe'), 
(17, 'body-right', 'modern'), 
(17, 'left-body-right', 'default'), 
(18, 'body', 'ala'), 
(18, 'body', 'mobile_nukeviet'), 
(18, 'body', 'xe'), 
(18, 'body-right', 'modern'), 
(18, 'left-body-right', 'default'), 
(19, 'body', 'ala'), 
(19, 'body', 'mobile_nukeviet'), 
(19, 'body', 'xe'), 
(19, 'body-right', 'modern'), 
(19, 'left-body-right', 'default'), 
(20, 'body', 'ala'), 
(20, 'body', 'mobile_nukeviet'), 
(20, 'body', 'xe'), 
(20, 'body-right', 'modern'), 
(20, 'left-body-right', 'default'), 
(21, 'body', 'ala'), 
(21, 'body', 'mobile_nukeviet'), 
(21, 'body', 'xe'), 
(21, 'body-right', 'modern'), 
(21, 'left-body-right', 'default'), 
(22, 'body', 'ala'), 
(22, 'body', 'mobile_nukeviet'), 
(22, 'body', 'xe'), 
(22, 'body-right', 'modern'), 
(22, 'left-body-right', 'default'), 
(23, 'body', 'ala'), 
(23, 'body', 'mobile_nukeviet'), 
(23, 'body', 'xe'), 
(23, 'body-right', 'modern'), 
(23, 'left-body-right', 'default'), 
(24, 'body', 'ala'), 
(24, 'body', 'mobile_nukeviet'), 
(24, 'body', 'xe'), 
(24, 'body-right', 'modern'), 
(24, 'left-body-right', 'default'), 
(25, 'body', 'ala'), 
(25, 'body', 'mobile_nukeviet'), 
(25, 'body', 'xe'), 
(25, 'body-right', 'modern'), 
(25, 'left-body-right', 'default'), 
(26, 'body', 'ala'), 
(26, 'body', 'mobile_nukeviet'), 
(26, 'body', 'xe'), 
(26, 'body-right', 'modern'), 
(26, 'left-body-right', 'default'), 
(27, 'body', 'ala'), 
(27, 'body', 'mobile_nukeviet'), 
(27, 'body', 'xe'), 
(27, 'body-right', 'modern'), 
(27, 'left-body-right', 'default'), 
(28, 'body', 'ala'), 
(28, 'body', 'mobile_nukeviet'), 
(28, 'body', 'modern'), 
(28, 'body', 'xe'), 
(28, 'left-body-right', 'default'), 
(29, 'body', 'ala'), 
(29, 'body', 'mobile_nukeviet'), 
(29, 'body', 'modern'), 
(29, 'body', 'xe'), 
(29, 'left-body-right', 'default'), 
(30, 'body', 'ala'), 
(30, 'body', 'mobile_nukeviet'), 
(30, 'body', 'modern'), 
(30, 'body', 'xe'), 
(30, 'left-body-right', 'default'), 
(31, 'body', 'ala'), 
(31, 'body', 'mobile_nukeviet'), 
(31, 'body', 'modern'), 
(31, 'body', 'xe'), 
(31, 'left-body-right', 'default'), 
(32, 'body', 'ala'), 
(32, 'body', 'mobile_nukeviet'), 
(32, 'body', 'modern'), 
(32, 'body', 'xe'), 
(32, 'left-body-right', 'default'), 
(33, 'body', 'ala'), 
(33, 'body', 'mobile_nukeviet'), 
(33, 'body', 'modern'), 
(33, 'body', 'xe'), 
(33, 'left-body-right', 'default'), 
(34, 'body', 'ala'), 
(34, 'body', 'mobile_nukeviet'), 
(34, 'body', 'modern'), 
(34, 'body', 'xe'), 
(34, 'left-body-right', 'default'), 
(35, 'body', 'ala'), 
(35, 'body', 'mobile_nukeviet'), 
(35, 'body', 'xe'), 
(35, 'body-right', 'modern'), 
(35, 'left-body-right', 'default'), 
(36, 'body', 'ala'), 
(36, 'body', 'mobile_nukeviet'), 
(36, 'body', 'xe'), 
(36, 'body-right', 'modern'), 
(36, 'left-body-right', 'default'), 
(39, 'body', 'ala'), 
(39, 'body', 'mobile_nukeviet'), 
(39, 'body', 'xe'), 
(39, 'body-right', 'modern'), 
(39, 'left-body-right', 'default'), 
(42, 'body', 'ala'), 
(42, 'body', 'mobile_nukeviet'), 
(42, 'body', 'xe'), 
(42, 'body-right', 'modern'), 
(42, 'left-body-right', 'default'), 
(43, 'body', 'ala'), 
(43, 'body', 'mobile_nukeviet'), 
(43, 'body', 'xe'), 
(43, 'body-right', 'modern'), 
(43, 'left-body-right', 'default'), 
(46, 'body', 'ala'), 
(46, 'body', 'mobile_nukeviet'), 
(46, 'body', 'xe'), 
(46, 'body-right', 'modern'), 
(46, 'left-body-right', 'default'), 
(47, 'body', 'ala'), 
(47, 'body', 'mobile_nukeviet'), 
(47, 'body', 'modern'), 
(47, 'body', 'xe'), 
(47, 'left-body-right', 'default'), 
(48, 'body', 'ala'), 
(48, 'body', 'mobile_nukeviet'), 
(48, 'body', 'xe'), 
(48, 'body-right', 'modern'), 
(48, 'left-body-right', 'default'), 
(50, 'body', 'ala'), 
(50, 'body', 'mobile_nukeviet'), 
(50, 'body', 'xe'), 
(50, 'body-right', 'modern'), 
(50, 'left-body-right', 'default'), 
(51, 'body', 'ala'), 
(51, 'body', 'mobile_nukeviet'), 
(51, 'body', 'xe'), 
(51, 'body-right', 'modern'), 
(51, 'left-body-right', 'default'), 
(52, 'body', 'ala'), 
(52, 'body', 'mobile_nukeviet'), 
(52, 'body', 'xe'), 
(52, 'body-right', 'modern'), 
(52, 'left-body-right', 'default'), 
(53, 'body', 'ala'), 
(53, 'body', 'mobile_nukeviet'), 
(53, 'body', 'modern'), 
(53, 'body', 'xe'), 
(53, 'left-body-right', 'default'), 
(54, 'body', 'ala'), 
(54, 'body', 'mobile_nukeviet'), 
(54, 'body', 'xe'), 
(54, 'body-right', 'modern'), 
(54, 'left-body-right', 'default'), 
(55, 'body', 'ala'), 
(55, 'body', 'mobile_nukeviet'), 
(55, 'body', 'xe'), 
(55, 'body-right', 'modern'), 
(55, 'left-body-right', 'default'), 
(56, 'body', 'ala'), 
(56, 'body', 'mobile_nukeviet'), 
(56, 'body', 'xe'), 
(56, 'body-right', 'modern'), 
(56, 'left-body-right', 'default'), 
(57, 'body', 'ala'), 
(57, 'body', 'mobile_nukeviet'), 
(57, 'body', 'xe'), 
(57, 'body-right', 'modern'), 
(57, 'left-body-right', 'default'), 
(58, 'body', 'ala'), 
(58, 'body', 'xe'), 
(58, 'left-body-right', 'default'), 
(122, 'body', 'ala'), 
(122, 'body', 'mobile_nukeviet'), 
(122, 'body', 'xe'), 
(122, 'body-right', 'modern'), 
(122, 'left-body-right', 'default'), 
(154, 'body', 'ala'), 
(154, 'body', 'mobile_nukeviet'), 
(154, 'body', 'xe'), 
(154, 'body-right', 'modern'), 
(154, 'left-body-right', 'default'), 
(155, 'left-body-right', 'default'), 
(156, 'body', 'ala'), 
(156, 'body', 'mobile_nukeviet'), 
(156, 'body', 'xe'), 
(156, 'body-right', 'modern'), 
(156, 'left-body-right', 'default'), 
(157, 'body', 'ala'), 
(157, 'body', 'mobile_nukeviet'), 
(157, 'body', 'xe'), 
(157, 'body-right', 'modern'), 
(157, 'left-body-right', 'default'), 
(158, 'left-body-right', 'default'), 
(159, 'body', 'ala'), 
(159, 'body', 'mobile_nukeviet'), 
(159, 'body', 'xe'), 
(159, 'body-right', 'modern'), 
(159, 'left-body-right', 'default'), 
(160, 'body', 'ala'), 
(160, 'body', 'mobile_nukeviet'), 
(160, 'body', 'xe'), 
(160, 'body-right', 'modern'), 
(160, 'left-body-right', 'default'), 
(161, 'body', 'ala'), 
(161, 'body', 'mobile_nukeviet'), 
(161, 'body', 'xe'), 
(161, 'body-right', 'modern'), 
(161, 'left-body-right', 'default'), 
(162, 'left-body-right', 'default'), 
(163, 'body', 'ala'), 
(163, 'body', 'mobile_nukeviet'), 
(163, 'body', 'xe'), 
(163, 'body-right', 'modern'), 
(163, 'left-body-right', 'default'), 
(164, 'body', 'ala'), 
(164, 'body', 'mobile_nukeviet'), 
(164, 'body', 'xe'), 
(164, 'body-right', 'modern'), 
(164, 'left-body-right', 'default'), 
(165, 'body', 'ala'), 
(165, 'body', 'mobile_nukeviet'), 
(165, 'body', 'xe'), 
(165, 'body-right', 'modern'), 
(165, 'left-body-right', 'default'), 
(166, 'left-body-right', 'default'), 
(167, 'left-body-right', 'default'), 
(168, 'left-body-right', 'default'), 
(169, 'left-body-right', 'default'), 
(170, 'left-body-right', 'default'), 
(171, 'body', 'ala'), 
(171, 'body', 'mobile_nukeviet'), 
(171, 'body', 'xe'), 
(171, 'body-right', 'modern'), 
(171, 'left-body-right', 'default'), 
(172, 'body', 'ala'), 
(172, 'body', 'mobile_nukeviet'), 
(172, 'body', 'xe'), 
(172, 'body-right', 'modern'), 
(172, 'left-body-right', 'default'), 
(173, 'left-body-right', 'default'), 
(174, 'left-body-right', 'default'), 
(175, 'left-body-right', 'default'), 
(176, 'left-body-right', 'default'), 
(177, 'body', 'ala'), 
(177, 'body', 'mobile_nukeviet'), 
(177, 'body', 'xe'), 
(177, 'body-right', 'modern'), 
(177, 'left-body-right', 'default'), 
(178, 'body', 'ala'), 
(178, 'body', 'mobile_nukeviet'), 
(178, 'body', 'xe'), 
(178, 'body-right', 'modern'), 
(178, 'left-body-right', 'default'), 
(179, 'body', 'ala'), 
(179, 'body', 'mobile_nukeviet'), 
(179, 'body', 'xe'), 
(179, 'body-right', 'modern'), 
(179, 'left-body-right', 'default'), 
(180, 'left-body-right', 'default'), 
(181, 'body', 'ala'), 
(181, 'body', 'mobile_nukeviet'), 
(181, 'body', 'xe'), 
(181, 'body-right', 'modern'), 
(181, 'left-body-right', 'default'), 
(182, 'body', 'ala'), 
(182, 'body', 'mobile_nukeviet'), 
(182, 'body', 'xe'), 
(182, 'body-right', 'modern'), 
(182, 'left-body-right', 'default'), 
(183, 'body', 'ala'), 
(183, 'body', 'mobile_nukeviet'), 
(183, 'body', 'xe'), 
(183, 'body-right', 'modern'), 
(183, 'left-body-right', 'default'), 
(184, 'body', 'ala'), 
(184, 'body', 'mobile_nukeviet'), 
(184, 'body', 'xe'), 
(184, 'body-right', 'modern'), 
(184, 'left-body-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modules`
--

DROP TABLE IF EXISTS `nv4_vi_modules`;
CREATE TABLE `nv4_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) DEFAULT '',
  `mobile` varchar(100) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `keywords` text,
  `groups_view` varchar(255) NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modules`
--

INSERT INTO `nv4_vi_modules` VALUES
('about', 'page', 'about', 'Giới thiệu', '', 1276333182, 1, 1, '', '', '', '', '6', 1, 1, '', 0, 0), 
('news', 'news', 'news', 'Tin Tức', '', 1270400000, 1, 1, '', '', '', '', '6', 2, 1, '', 1, 0), 
('users', 'users', 'users', 'Thành viên', 'Tài khoản', 1274080277, 1, 1, '', '', '', '', '6', 3, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'Liên hệ', '', 1275351337, 1, 1, '', '', '', '', '6', 4, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'Thống kê', '', 1276520928, 1, 0, '', '', '', 'truy cập, online, statistics', '6', 5, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1275315261, 1, 1, '', '', '', '', '6', 6, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'Quảng cáo', '', 1270400000, 1, 1, '', '', '', '', '6', 7, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'Tìm kiếm', '', 1273474173, 1, 0, '', '', '', '', '6', 8, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', '', '', '', '6', 9, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'Rss Feeds', '', 1279366705, 1, 1, '', '', '', '', '6', 10, 1, '', 0, 0), 
('page', 'page', 'page', 'Page', '', 1279366705, 1, 1, '', '', '', '', '6', 11, 1, '', 0, 0), 
('comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1279366705, 1, 1, '', '', '', '', '6', 12, 1, '', 0, 0), 
('make-theme', 'make-theme', 'make_theme', 'make theme', '', 1421636267, 1, 0, '', '', '', '', '6', 13, 1, '', 0, 0), 
('nvtools', 'nvtools', 'nvtools', 'nvtools', '', 1421983387, 1, 0, '', '', '', '', '6', 15, 1, '', 0, 0), 
('shops', 'shops', 'shops', 'shops', 'shop', 1421642202, 1, 1, '', '', '', '', '6', 14, 1, '', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_1`
--

DROP TABLE IF EXISTS `nv4_vi_news_1`;
CREATE TABLE `nv4_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_1`
--

INSERT INTO `nv4_vi_news_1` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 4, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_10`
--

DROP TABLE IF EXISTS `nv4_vi_news_10`;
CREATE TABLE `nv4_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_10`
--

INSERT INTO `nv4_vi_news_10` VALUES
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_11`
--

DROP TABLE IF EXISTS `nv4_vi_news_11`;
CREATE TABLE `nv4_vi_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_11`
--

INSERT INTO `nv4_vi_news_11` VALUES
(7, 11, '11', 0, 1, '', 2, 1307197282, 1307197381, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên, chuyên viên đồ họa phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-chuyen-vien-do-hoa-phat-trien-NukeViet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '6', 1, 1, '2', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_12`
--

DROP TABLE IF EXISTS `nv4_vi_news_12`;
CREATE TABLE `nv4_vi_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_12`
--

INSERT INTO `nv4_vi_news_12` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_2`
--

DROP TABLE IF EXISTS `nv4_vi_news_2`;
CREATE TABLE `nv4_vi_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_2`
--

INSERT INTO `nv4_vi_news_2` VALUES
(5, 2, '2', 1, 1, '', 5, 1274993307, 1275318039, 1, 1274993280, 0, 2, 'Giới thiệu về mã nguồn mở NukeViet', 'Gioi-thieu-ve-ma-nguon-mo-NukeViet', 'Chắc hẳn đây không phải lần đầu tiên bạn nghe nói đến mã nguồn mở. Và nếu bạn là người mê lướt web thì hẳn bạn từng nhìn thấy đâu đó cái tên NukeViet. NukeViet, phát âm là Nu-Ke-Việt, chính là phần mềm dùng để xây dựng các Website mà bạn ngày ngày online để truy cập đấy.', 'screenshot.jpg', '6', 1, 0, '2', 1, 1, 0, 0, 0), 
(9, 2, '2', 0, 1, 'Phạm Thế Quang Huy', 4, 1322685396, 1322686088, 1, 1322685396, 0, 2, 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet-Cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-Viet-Nam', '(Dân trí) - Là một trong những hệ quản trị nội dung nổi tiếng hàng đầu tại Việt Nam, NukeViet đã được áp dụng rộng rãi trong việc xây dựng nhiều trang báo điện tử và các cổng thông tin điện tử nổi tiếng tại Việt Nam. Mới đây nhất, NukeViet đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011', 'product_box.jpg', 'Sản phẩm dự thi Nhân tài Đất Việt 2011&#x3A; Mã nguồn mở NukeViet', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_8`
--

DROP TABLE IF EXISTS `nv4_vi_news_8`;
CREATE TABLE `nv4_vi_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_8`
--

INSERT INTO `nv4_vi_news_8` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_9`
--

DROP TABLE IF EXISTS `nv4_vi_news_9`;
CREATE TABLE `nv4_vi_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_9`
--

INSERT INTO `nv4_vi_news_9` VALUES
(8, 9, '9', 0, 1, 'laser', 3, 1310067949, 1310068009, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 4, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_admins`
--

DROP TABLE IF EXISTS `nv4_vi_news_admins`;
CREATE TABLE `nv4_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block`
--

DROP TABLE IF EXISTS `nv4_vi_news_block`;
CREATE TABLE `nv4_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_block`
--

INSERT INTO `nv4_vi_news_block` VALUES
(1, 5, 3), 
(1, 2, 2), 
(1, 1, 1), 
(2, 6, 4), 
(2, 5, 3), 
(2, 2, 2), 
(2, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_block_cat`;
CREATE TABLE `nv4_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_block_cat`
--

INSERT INTO `nv4_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv4_vi_news_bodyhtml_1`;
CREATE TABLE `nv4_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_bodyhtml_1`
--

INSERT INTO `nv4_vi_news_bodyhtml_1` VALUES
(1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br /> <br /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br /> <br /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br /> <br /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 'http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm', 1, 0, 1, 1, 1, 0), 
(2, '<p style=\"font-weight: bold;\"> <span style=\"font-size: 14pt;\">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style=\"font-weight: bold;\"> Từ một trăn trở</p><p style=\"text-align: justify;\"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style=\"font-weight: bold;\">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style=\"font-weight: bold;\">Một mô hình - một lối đi</span></p><p style=\"text-align: justify;\"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br /> <span style=\"font-weight: bold;\">Triển khai thực hiện</span></p><p style=\"text-align: justify;\"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style=\"text-align: center;\"> <img alt=\"Anh Tú phát biểu khai trương VINADES.,JSC \" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg\" style=\"border: 0px solid;\" width=\"500\" /></div><div style=\"text-align: center;\"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br /> <img alt=\"\" border=\"0\" src=\"http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg\" style=\"width: 500px;\" width=\"500\" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br /> <img alt=\"\" border=\"0\" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/nangly.jpg\" style=\"width: 500px; height: 332px;\" width=\"500\" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style=\"font-weight: bold;\"> ... và lời cảm ơn gửi tới cộng đồng</p><p style=\"text-align: justify;\"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style=\"font-weight: bold;\"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style=\"text-align: justify;\"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style=\"text-align: justify;\"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href=\"http://nukeviet.vn/phpbb/viewforum.php?f=99\" target=\"_blank\">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC-2/', 1, 0, 1, 1, 1, 0), 
(5, '<p> <strong><span style=\"font-size: 14px;\">THÔNGTIN VỀ MÃ NGUỒN MỞ NUKEVIET</span></strong></p><p style=\"font-weight: bold;\"> I. Giới thiệu chung:</p><p> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System), người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền Web.</p><p> NukeViet có 2 dòng phiên bản chính:</p><p> Dòng phiên bản trước năm 2009 (NukeViet 2.0 trở về trước) được Nguyễn Anh Tú- một lưu học sinh người Việt tại Nga - cùng cộng đồng phát triển thành một ứng dụng thuần Việt từ nền tảng PHP-Nuke.</p><p> Dòng phiên bản NukeViet 3.0 trở về sau (kể từ năm 2010 trở đi) là dòng phiên bản hoàn toàn mới, được xây dựng từ đầu với nhiều tính năng ưu việt.</p><p> NukeViet được viết bằng ngôn ngữ PHP và chủ yếu sử dụng cơ sở dữ liệu MySQL, cho phép người sử dụng có thể dễ dàng xuất bản &amp;quản trị các nội dung của họ lên Internet hoặc Intranet.</p><p> NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng.</p><p style=\"text-align: justify;\"> NukeViet là giải pháp hoàn hảo cho các Website từ cá nhân cho tới các doanh nghiệp. NukeViet là bộ mã nguồn chất lượng cao, được phát hành theo giấy phép mã nguồn mở nên việc sử dụng NukeViet hoàn toàn miễn phí. Với người sử dụng cá nhân, tất cả đều có thể tự tạo cho mình một website chuyên nghiệp mà không mất bất cứ chi phí nào. Với những nhà phát triển Web, sử dụng NukeViet có thể nhanh chóng xây dựng các hệ thống lớn mà việc lập trình không đòi hỏi quá nhiều thời gian vì NukeViet đã xây dựng sẵn hệ thống quản lý ưu việt.</p> <p>Thông tin chi tiết về NukeViet có thể tìm thấy ở bách khoa toàn thư mở Wikipedia: <a href=\"http://vi.wikipedia.org/wiki/NukeViet\">http://vi.wikipedia.org/wiki/NukeViet</a></p><p style=\"font-weight: bold;\"> II. Thông tin về diễn đàn NukeViet:</p><p> Diễn đàn NukeViet hoạt động trên website: <a href=\"http://nukeviet.vn/\"><span style=\"font-weight: bold;\">http://nukeviet.vn</span></a> hiện có trên 22.000 thành viên thực gồm học sinh, sinh viên &amp; nhiều thành phần khác thuộc giới trí thức ở trong và ngoài nước.</p><p> Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng,văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an...</p><p> Nhiều học sinh, sinh viên tham gia diễn đàn NukeViet, đam mê mã nguồn mở và đã thành công với chính công việc mà họ yêu thích.</p>', 'http://nukeviet.vn/vi/news/Tin-tuc/Gioi-thieu-ve-ma-nguon-mo-NukeViet-5/', 1, 0, 1, 1, 1, 0), 
(6, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Thu-moi-hop-tac-6/', 1, 0, 1, 1, 1, 0), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.<br /><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân.<br /><p style=\"text-align: justify;\"> <strong>1. Vị trí dự tuyển</strong>: Chuyên viên đồ hoạ; Lập trình viên.</p><p style=\"text-align: justify;\"> <strong>2. Mô tả công việc:</strong></p>Với vị trí lập trình viên PHP &amp; MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet.<br /><p style=\"text-align: justify;\"> Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau:</p><p style=\"margin-left: 40px; text-align: justify;\"> + Vẽ và cắt giao diện.</p><p style=\"margin-left: 40px; text-align: justify;\"> + Valid CSS, xHTML.</p><p style=\"margin-left: 40px; text-align: justify;\"> + Ghép giao diện cho hệ thống.</p><strong>3. Yêu cầu: </strong><br /><br />Lập trình viên PHP &amp; MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.<br /><br />Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML.<p style=\"text-align: justify; margin-left: 40px;\"> + Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML &amp; CSS.</p><p style=\"text-align: justify; margin-left: 40px;\"> + Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+)</p>Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc.<br /><p style=\"text-align: justify;\"> <strong>4: Quyền lợi:</strong></p><p style=\"text-align: justify;\"> <strong>-</strong> Lương: thoả thuận, trả qua ATM.</p><p style=\"text-align: justify;\"> - Thưởng theo dự án, các ngày lễ tết.</p><p style=\"text-align: justify;\"> - Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</p><p style=\"text-align: justify;\"> <strong>5. Thời gian làm việc:</strong> Toàn thời gian cố định hoặc làm <strong>online</strong>.</p><p style=\"text-align: justify;\"> <strong>6. Hạn nộp hồ sơ</strong>: Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a></p><p style=\"text-align: justify;\"> <strong>7. Hồ sơ bao gồm:</strong></p><p style=\"text-align: justify;\"> &nbsp;&nbsp;<strong>&nbsp; *&nbsp; Cách thức đăng ký dự tuyển</strong>: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn<br /> &nbsp;&nbsp;&nbsp; *&nbsp; <strong>Nội dung hồ sơ xin việc file mềm gồm</strong>:<br /> <br /> <strong>+ Đơn xin việc:</strong> Tự biên soạn.</p><p style=\"text-align: justify;\"> <strong>+ Thông tin ứng viên:</strong> Theo mẫu của VINADES.,JSC (dowload tại đây: <strong><u><a href=\"http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/\" target=\"_blank\" title=\"Mẫu lý lịch ứng viên\">Mẫu lý lịch ứng viên</a></u></strong>)<br /> <br /> Chi tiết vui lòng tham khảo tại: <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /> <br /> Mọi thắc mắc vui lòng liên hệ:<br /> <br /> <strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br /> Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div> - Tel: +84-4-85872007 - Fax: +84-4-35500914<br /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div>', 'http://vinades.vn/vi/news/Tuyen-dung/', 2, 0, 1, 1, 1, 0), 
(8, '<p style=\"text-align: justify;\"> <span style=\"font-size:16px;\"><strong>Giảm giá tới 90% giá module, ngày nào cũng là ngày &quot;mua chung&quot; trên webnhanh.vn!</strong></span></p><p style=\"text-align: justify;\"> Như thông báo trên webnhanh.vn, chương trình &quot;<a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Mua-chung-tren-Webnhanhvn-se-giam-gia-90-gia-module-da-cong-bo-245/\" target=\"_blank\"><strong>mua chung module</strong></a>&quot; nằm trong chính sách chung của webnhanh.vn trong việc hỗ trợ phát triển mã nguồn mở, giúp cho mọi người được hưởng những dịch vụ thiết kế website tốt nhất với chi phí thấp nhất. Tham gia chương trình này, bạn chỉ phải trả số tiền bằng 1/10 giá trị module mà vẫn được sở hữu module với tính năng hấp dẫn mà bạn&nbsp; mong muốn.<br /> <br /> Cụ thể, các module trong <a href=\"http://webnhanh.vn/vi/nvresources/cat/Modules-1/\" target=\"_blank\"><strong>kho module của webnhanh.vn</strong></a> đang chờ hoàn thiện sẽ được giảm giá tới 90% nếu khách hàng đăng ký mua chung module. Tuy nhiên sau 2 tháng thực hiện, Ban Quản Trị webnhanh.vn thấy rằng khả năng xuất hiện nhu cầu cùng mua chung 1 sản phẩm và dịch vụ có tính đặc thù như code dành cho web là rất thấp. Chính vì thế webnhanh.vn đã giảm giá đồng loạt các module trên webnhanh.vn để khách hàng có nhu cầu sẽ có nhiều cơ hội được sử dụng các module mà mình mong muốn cung cấp lên website.<br /> <br /> Đại đa số các module sẽ được giảm giá xuống mức giá siêu rẻ để đảm bảo mọi người đều có khả năng sử dụng. Đặc biệt với các module có mức giá từ 10-20 triệu đồng sẽ giảm giá xuống còn ở mức 1-5 triệu đồng.<br /> <br /> <span style=\"font-size:16px;\"><strong>Giá rẻ hơn, nhiều giao diện hơn cho web</strong></span></p><p style=\"text-align: justify;\"> Ngoài việc giảm giá <a href=\"http://webnhanh.vn/vi/nvresources/cat/Giao-dien-3/\" target=\"_blank\"><strong>các giao diện website</strong></a> do VINADES.,JSC thiết kế (từ mức giá 2 triệu đồng xuống còn 300 đến 700 ngàn đồng). Webnhanh.vn cũng sẽ cải thiện kho giao diện của mình bằng cách đưa vào sử dụng các mẫu giao diện của các nhà thiết kế giao diện khác với giá trung bình khoảng 300 ngàn đồng (chi phí chuyển template thành giao diện có thể cài đặt cho website). Khách hàng cũng có thể gửi mẫu giao diện (đã cắt HTML) để chúng tôi thực hiện việc ghép giao diện với mức giá 300-500 ngàn đồng (áp dụng mô hình giá chia sẻ của VINADES.,JSC&nbsp; trong <strong><a href=\"http://vinades.vn/vi/news/San-pham/Thiet-ke-giao-dien-14/\" target=\"_blank\">thiết kế giao diện web</a></strong> <sup>(*)</sup>).<br /> <br /> <span style=\"font-size:16px;\"><strong>Giảm giá các gói web dựng sẵn, nâng cao chất lượng và cấu hình dịch vụ</strong></span></p><p style=\"text-align: justify;\"> Cơ cấu chất lượng sản phẩm và dịch vụ cũng thay đổi theo hướng nâng cao rõ rệt. Ngoài việc giảm giá các <strong><a href=\"http://webnhanh.vn/vi/nvresources/package/\" target=\"_blank\">gói web dựng sẵn</a></strong>, webnhanh.vn đồng thời nâng cao chất lượng các dịch vụ đi kèm của các gói web này. Theo đó ngoài việc kéo dài thời gian bảo hành miễn phí lên 12 tháng, đồng thời webnhanh.vn cũng kéo dài thời gian sử dụng hosting miễn phí lên 12 tháng. Với mức hỗ trợ này, website thiết kế trên webnhanh.vn đảm bảo chất lượng cao và mức giá còn rẻ hơn cả các nhà cung cấp dịch vụ web giá rẻ. Đây là cơ hội rất lớn cho <strong><a href=\"http://webnhanh.vn/vi/dealers/\" target=\"_blank\">các đại lý của webnhanh.vn</a></strong> để tạo nên lợi thế cạnh tranh về chất lượng và giá cả dịch vụ.<br /> <br /> <strong><sup>(*)</sup> &quot;Giá chia sẻ&quot;</strong> là mức giá tiết kiệm cho khách hàng, nếu mua với mức giá này khách hàng sẽ tiết kiệm chi phí thiết kế giao diện một cách tối đa mà vẫn được toàn quyền sử dụng mẫu giao diện đã đặt hàng. Webnhanh.vn sẽ giữ lại mẫu giao diện này và đưa vào thư viện giao diện để cung cấp cho các khách hàng khác. Mô hình &quot;Giá chia sẻ&quot; sử dụng cho các khách hàng không quá khắt khe về việc đảm bảo tính duy nhất của mẫu giao diện đồng thời giúp webnhanh.vn làm phong phú thêm kho giao diện của mình.</p><strong>Chú ý:</strong> Ngoài việc cung cấp các gói web dựng sẵn với chi phí thấp phục vụ người dùng phổ thông, <strong><a href=\"http://vinades.vn\">VINADES.,JSC</a></strong> vẫn duy trì dịch vụ thiết kế giao diện riêng và thiết kế website theo yêu cầu để phục vụ những khách hàng có nhu cầu riêng biệt và cao cấp hơn, khách hàng có nhu cầu vui lòng truy cập <a href=\"http://vinades.vn\" target=\"_blank\">http://vinades.vn</a> hoặc liên hệ nhân viên kinh doanh của VINADES.,JSC để được tư vấn và báo giá dịch vụ.<br /><br /><div style=\"text-align: justify;\"> Như vậy, cùng với việc tham gia cung cấp hosting chuyên nghiệp dành cho NukeViet của các nhà cung cấp hosting trong và ngoài nước như <strong><a href=\"http://vinades.vn/vi/news/Doi-tac/VINADES-JSC-va-DIGISTAR-hop-tac-trong-viec-phat-trien-ma-nguon-mo-NukeViet-17/\">DIGISTAR</a></strong>, <strong><a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/TMDHosting-cung-cap-dich-vu-hosting-chuyen-NukeViet-64/\" title=\"TMDHosting cung cấp dịch vụ hosting chuyên NukeViet\">TMDHosting</a></strong> hay <strong><a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/SiteGround-cung-cap-dich-vu-hosting-chuyen-NukeViet-59/\" title=\"SiteGround cung cấp dịch vụ hosting chuyên NukeViet\">SiteGround</a></strong>, <a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/\" title=\"Webnhanh.vn - website đầu tiên thiết kế website và bán code chuyên nghiệp dành cho NukeViet\"><strong>Webnhanh.vn</strong> là website đầu tiên có dịch vụ thiết kế website và bán code chuyên nghiệp</a> dành riêng cho NukeViet. Sự chuyên nghiệp hóa trong các khâu từ phát triển đến cung cấp dịch vụ cho mã nguồn mở NukeViet sẽ mở ra một cơ hội phát triển mới cho người sử dụng web ở Việt Nam.</div>', 'http://nukeviet.vn/vi/news/website/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/', 2, 0, 1, 1, 1, 0), 
(9, '<div> Nhắc đến các hệ thống quản trị nội dung (Content Management System – CMS) để quản lý các cổng thông tin điện tử trên Internet, không ít người sẽ nhắc đến các bộ công cụ như Joomla hay Wordpress. Tuy nhiên, có một sản phẩm hoàn toàn thuần Việt, do người Việt xây dựng không hề thua kém những sản phẩm trên cả về tính năng lẫn khả năng ứng dụng, đó là NukeViet của nhóm tác giả thuộc Công ty Cổ phần phát triển nguồn mở Việt Nam (VINADES).</div><div> &nbsp;</div><div> Với NukeViet, người dùng tại Việt Nam sẽ vượt qua các trở ngại về rào cản ngôn ngữ, có thể xây dựng và vận hành các trang web một cách dễ dàng nhất, đồng thời nhận được sự hỗ trợ của cộng đồng người dùng và các nhà phát triển cũng chính là người Việt Nam.</div><div> &nbsp;</div><div> Mới đây nhất, Ban giám khảo <span style=\"FONT-STYLE: italic\">Giải thưởng Nhân Tài Đất Việt 2011</span> đã quyết định đưa NukeViet vào danh sách các sản phẩm đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của <span style=\"FONT-STYLE: italic\">Giải Thưởng Nhân Tài Đất Việt 2011</span> diễn ra vào ngày 17-18/11 tới đây.</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Những ý tưởng giúp hình thành nên sản phẩm “thuần Việt”</span></div><div> &nbsp;</div><div> Theo chia sẻ của đại diện nhóm tác giả, năm 2004, anh Nguyễn Anh Tú, một lưu học sinh người Việt tại Nga với ý tưởng xây dựng một website để kết nối cộng đồng sinh viên du học đã sử dụng bộ CMS mã nguồn mở PHP-Nuke để thực hiện.</div><div> &nbsp;</div><div> Sau đó, anh Nguyễn Anh Tú đã phát triển và cải tiến bộ mã nguồn mở PHP-Nuke để chia sẻ cho các thành viên có nhu cầu xây dựng website một cách đơn giản và thuận tiện hơn. Được sự đón nhận của đông đảo người sử dụng, bộ mã nguồn đã liên tục được phát triển và trở thành một ứng dụng thuần Việt với tên gọi NukeViet. NukeViet đã nhanh chóng trở nên phổ biến trong giới các nhà xây dựng và phát triển website tại Việt Nam.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-1_4b905.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Giao diện một website tin tức được xây dựng bằng NukeViet</span></span></div><div> &nbsp;</div><div> Trong quá trình phát triển NukeViet, có một điều đội ngũ kỹ thuật luôn trăn trở là làm sao để có thể nâng cao tỉ lệ đóng góp của người Việt vào trong mã nguồn sản phẩm. Chính vì ý thức được điều này nên mức độ thuần Việt của sản phẩm ngày càng được nâng cao trong từng phiên bản phát hành. Cho đến phiên bản 3.0 (phát hành tháng 10 năm 2010) thì NukeViet đã thực sự trở thành một sản phẩm mã nguồn mở riêng của Việt Nam với 100% dòng code được viết mới.</div><div> &nbsp;</div><div> Kể từ đây, cộng đồng mã nguồn mở Việt Nam đã có riêng một bộ mã nguồn thuần Việt, tự hào sánh bước ngang vai cùng các cộng đồng mã nguồn mở khác trên thế giới. NukeViet ra đời đã giúp cộng đồng mạng Việt Nam giải quyết nhu cầu và mong muốn có một bộ mã nguồn mở của riêng Việt Nam, giúp phát triển hệ thống website của người Việt một cách an toàn nhất, đảm bảo nhất.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-2_600d0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Một website bán hành trực tuyến xây dựng bằng NukeViet</span></span></div><div> &nbsp;</div><div> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Khả năng ứng dụng và những ưu điểm của NukeViet</span></div><div> &nbsp;</div><div> Kể từ khi ra đời và trải qua một quá trình dài phát triển, NukeViet hiện được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block...&nbsp;</div><div> &nbsp;</div><div> NukeViet chủ yếu được sử dụng làm trang tin tức &nbsp;nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-4_416a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Website phòng Giáo dục và Đào tạo Lạng Giang được xây dựng trên mã nguồn NukeViet</span></span></div><div> &nbsp;</div><div> NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ phiên bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: &quot;hệ thống Portal dành cho người Việt&quot;. Tuy nhiên, kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế với hỗ trợ thêm nhiều ngôn ngữ.&nbsp;</div><div> &nbsp;</div><div> Trên thực tế, với những ưu điểm vượt trội của mình, NukeViet 3 đã được ứng dụng ở hàng ngàn website khác nhau. Đặc biệt, không ít các cơ quan, tổ chức của Nhà nước đã tin tưởng sử dụng mã nguồn NukeViet để xây dựng cổng thông tin điện tử của mình, như &nbsp;Cổng thông tin tích hợp 1 cửa cho Phòng giáo dục Lạng Giang, cổng thông tin 2 chiều - Công ty cổ phần đầu tư tài chính công đoàn dầu khí Việt Nam, Hệ thống tra cứu điểm, tra cứu văn bằng - Cổng thông tin Sở GD&amp;ĐT Quảng Ninh, Website viện y học cổ truyền Quân Đội…</div><div> &nbsp;</div><div> Tất cả các dự án trên đều được khách hàng đánh giá rất cao về tính ứng dụng, hiệu quả do tiết kiệm chi phí và đáp ứng rất tốt nhu cầu sử dụng của các đơn vị.&nbsp;</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Hướng phát triển trong tương lai và những kỳ vọng trước mắt</span></div><div> &nbsp;</div><div> Với ý nghĩa là phần mềm quản lý website (chiếm tới 90% các giao tiếp và tương tác trực tiếp với người sử dụng trên môi trường internet), khi phát triển, NukeViet sẽ trở thành một công cụ truyền thông rất mạnh, có thể đem lại những hiệu quả to lớn khác. Nhóm phát triển sẽ phát huy lợi thế này để phát triển sản phẩm.</div><div> &nbsp;</div><div> Nhóm phát triển cũng muốn tăng cường các khả năng liên kết, chia sẻ và tích hợp dữ liệu giữa các hệ thống khác nhau nhằm tạo nên một mạng lưới lớn, rộng khắp và hoàn chỉnh, có thể huy động sức mạnh tổng lực, thực hiện các nhiệm vụ xã hội khác trên mã nguồn NukeViet của mình.</div><div> &nbsp;</div><div> NukeViet khi được kết hợp với xu thế phát triển của điện toán đám mây sẽ trở thành một nền tảng giúp phát triển nhiều hệ thống dịch vụ trực tuyến có thể thu hút nhiều người dùng với giá trị thương mại cao.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-3_46e98.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\">Giao diện soạn thảo nội dung trên NukeViet</span></div><div> &nbsp;</div><div> Với việc gửi sản phẩm dự thi tại <span style=\"FONT-STYLE: italic\">Giải thưởng Nhân Tài Đất Việt 2011</span>, nhóm tác giả của NukeViet hy vọng mã nguồn mở của mình sẽ đạt vị trí cao tại Giải thưởng, như một cách thức để quảng bá rộng rãi sản phẩm, được thừa nhận và hỗ trợ sử dụng trong các lĩnh vực mà nó có thể phục vụ tốt và đem lại hiệu quả kinh tế, xã hội cao như: lĩnh vực giáo dục, lĩnh vực hành chính… để các bộ-ban-ngành, các cơ quan hành chính, chính quyền địa phương nhìn thấy giá trị và hiệu quả to lớn của mã nguồn mở NukeViet để triển khai NukeViet phục vụ các cơ quan này. NukeViet sẽ giúp hiện thực hóa cải cách hành chính và góp phần đẩy nhanh thủ tục một cửa một cách tiết kiệm mà vẫn đạt hiệu quả cao nhất.</div><div> &nbsp;</div><div> Ngoài ra, uy tính của Giải thưởng, nhóm tác giả NukeViet hy vọng sẽ đem NukeViet đến nhiều người hơn, để cả xã hội được sử dụng thành quả lớn lao của bộ mã nguồn mở được coi là biểu tượng và đại diện tiểu biểu cho sự phát triển và thành công của mã nguồn mở Việt Nam. Không chỉ thế, mở ra cơ hội tiếp cận và học hỏi công nghệ cho hàng ngàn học sinh, sinh viên, qua đó có được các kiến thức đầy đủ về công nghệ web, về internet và vô số các kỹ năng làm việc trên máy tính khác mà có thể do vô tình hay cố ý, trong quá trình tìm hiểu, học tập và vận hành NukeViet mà họ đã có được.</div><div> &nbsp;</div><div> Với những ứng dụng rộng rãi mà NukeViet đã có được kể từ khi ra mắt và và trải qua thời gian dài phát triển, Hội đồng <span style=\"FONT-STYLE: italic\">Giám khảo Giải Thưởng Nhân &nbsp;Tài Đất Việt</span> đã đánh giá rất cao những ưu điểm và thế mạnh của NukeViet để đưa sản phẩm vào danh sách 17 sản phẩm sẽ tranh tài tại vòng Chung khảo của <span style=\"FONT-STYLE: italic\">Giải Thưởng Nhân Tài Đất Việt 2011</span> diễn ra vào ngày 17-18/11 tới đây.</div><div> &nbsp;</div><div> Bạn đọc có thể tìm hiểu thêm về NukeViet tại <span style=\"FONT-WEIGHT: bold\"><a href=\"http://nukeviet.vn/vi/news/Bao-chi-viet/\">http://nukeviet.vn/</a>.</span></div>', 'http://dantri.com.vn/c119/s119-537812/nukeviet-cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-vn.htm', 1, 0, 1, 1, 1, 0), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước.<div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Sân khấu trước lễ trao giải.</span></div><div> &nbsp;</div><div align=\"center\"> &nbsp;</div><div align=\"left\"> Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ.</div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg\" width=\"350\" /></div> <div align=\"center\"> Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm.</div></div><p> Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải.</p><div> Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới&nbsp;dự Lễ trao giải.</span></div><div> &nbsp;</div><div> 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan.</span></div><div> &nbsp;</div><div> Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số…</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Giáo sư - Viện sỹ Nguyễn Văn Hiệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam.</span></div><p> Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải.</p><div> Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Tiết mục mở màn Lễ trao giải.</span></div><p> Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự.</p><blockquote> <p> <em><span style=\"FONT-STYLE: italic\">Hà Nội, ngày 16 tháng 11 năm 2011</span></em></p> <div> <em>Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược.</em></div></blockquote><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg\" style=\"MARGIN: 5px\" width=\"400\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt.</span></div><blockquote> <p> <em>Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay.</em></p> <p> <em>Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</em></p> <p> <em>Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế.</em></p> <p> <em>Chào thân ái,</em></p> <p> <strong><em>Chủ tịch danh dự Hội Khuyến học Việt Nam</em></strong></p> <p> <strong><em>Đại tướng Võ Nguyên Giáp</em></strong></p></blockquote><p> Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt.</p><div> Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp&nbsp;các vị lãnh đạo&nbsp; Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ.</span></div><p> Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh&nbsp; vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia.</p><div> “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất&nbsp; sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang.</span></div><p> Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng&nbsp; mới ra đời cách đây 7 năm.</p><p> Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</p><p> Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải.</p><div> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Khoa học Tự nhiên Việt Nam </span>thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân.</p><p> GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam.</p><div> Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ.</span></div><p> GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.”</p><p> GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam.</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược:</span> 2 giải</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình <span style=\"FONT-STYLE: italic\">“Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”</span>.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div> &nbsp;</div><div> Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp,&nbsp;2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức.</span></div><p> Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác.</p><p> <span style=\"FONT-WEIGHT: bold\">2.</span> Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu <span style=\"FONT-STYLE: italic\">“Triển khai ghép tim trên người lấy từ người cho chết não”</span>.</p><div> Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế).</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt.</span></div><p> Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện.</p><p> ---------------------</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin.</span></p><p> <span style=\"FONT-STYLE: italic\">Hệ thống sản phẩm đã ứng dụng thực tế:</span></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất:</span> Không có.</p><p> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> Không có</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 3 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> <span style=\"FONT-STYLE: italic\">“Bộ cạc xử lý tín hiệu HDTV”</span> của nhóm HD Việt Nam.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm HDTV Việt Nam lên nhận giải.</span></div><p> Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào.</p><div> <span style=\"FONT-WEIGHT: bold; FONT-STYLE: italic\">2.</span> <span style=\"FONT-STYLE: italic\">“Mã nguồn mở NukeViet”</span> của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC).</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" alt=\"NukeViet nhận giải ba Nhân tài đất Việt 2011\" src=\"/nukeviet-my/uploads/news/nukeviet-nhantaidatviet2011.jpg\" style=\"margin: 5px; width: 450px; height: 301px;\" /></div></div><p> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</p><div> <span style=\"FONT-WEIGHT: bold\">3.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống ngôi nhà thông minh homeON”</span> của nhóm Smart home group.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ.&nbsp;</p><p> <strong><span style=\"FONT-STYLE: italic\">* Hệ thống sản phẩm có tiềm năng ứng dụng:</span></strong></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất: </span>Không có.</p><div> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> trị giá 50 triệu đồng: <span style=\"FONT-STYLE: italic\">“Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion”</span> của nhóm tác giả SIG.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng.</span></div><p> ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động.</p><p> Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.”</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 2 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1. </span><span style=\"FONT-STYLE: italic\">“Bộ điều khiển IPNET”</span> của nhóm IPNET</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET.</span></div><p> Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc.</p><div> <span style=\"FONT-WEIGHT: bold\">2.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX”</span> của nhóm LYNX.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome…</p><div> Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực&nbsp;tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\"> <tbody> <tr> <td> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng.</span></span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này.</span>&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> </td> </tr> </tbody> </table> </div></div>', 'http://dantri.com.vn/c119/s119-539911/nhan-tai-dat-viet-chap-canh-khat-khao-sang-tao.htm', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_bodytext`
--

DROP TABLE IF EXISTS `nv4_vi_news_bodytext`;
CREATE TABLE `nv4_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_bodytext`
--

INSERT INTO `nv4_vi_news_bodytext` VALUES
(1, 'Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam. Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế. NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm xem chi tiết), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov xem chi tiết); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.'), 
(2, 'Câu chuyện của NukeViet và VINADES.,JSC Từ một trăn trở Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề \"Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet\". Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định... Gặp mặt Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này. Một mô hình - một lối đi Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: \"Thành lập doanh nghiệp chuyên quản NukeViet\". Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn. Triển khai thực hiện Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin \"Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam\". Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương: Anh Tú phát biểu khai trương VINADES.,JSC Anh Tú phát biểu khai trương VINADES.,JSC http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg Anh Tú phát biểu khai trương VINADES.,JSC Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động. http://nukeviet.vn/uploads/spaw2/images/nangly.jpg Cùng nâng ly chúc mừng khai trương. Cùng nâng ly chúc mừng khai trương. ... và lời cảm ơn gửi tới cộng đồng VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. \"Lửa thử vàng, gian nan thử sức\", mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng. http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg Văn phòng làm việc của VINADES.,JSC ở Hà Nội. http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg Một góc văn phòng nhìn từ trong ra ngoài. NukeViet 3.0 - Cuộc cách mạng của NukeViet Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua. NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: http://nukeviet.vn/phpbb/viewforum.php?f=99 http://nukeviet.vn/phpbb/viewforum.php?f=99'), 
(5, 'THÔNGTIN VỀ MÃ NGUỒN MỞ NUKEVIET Giới thiệu chung NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System), người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền Web. NukeViet có 2 dòng phiên bản chính: Dòng phiên bản trước năm 2009 (NukeViet 2.0 trở về trước) được Nguyễn Anh Tú- một lưu học sinh người Việt tại Nga - cùng cộng đồng phát triển thành một ứng dụng thuần Việt từ nền tảng PHP-Nuke. Dòng phiên bản NukeViet 3.0 trở về sau (kể từ năm 2010 trở đi) là dòng phiên bản hoàn toàn mới, được xây dựng từ đầu với nhiều tính năng ưu việt. NukeViet được viết bằng ngôn ngữ PHP và chủ yếu sử dụng cơ sở dữ liệu MySQL, cho phép người sử dụng có thể dễ dàng xuất bản &quản trị các nội dung của họ lên Internet hoặc Intranet. NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng. NukeViet là giải pháp hoàn hảo cho các Website từ cá nhân cho tới các doanh nghiệp. NukeViet là bộ mã nguồn chất lượng cao, được phát hành theo giấy phép mã nguồn mở nên việc sử dụng NukeViet hoàn toàn miễn phí. Với người sử dụng cá nhân, tất cả đều có thể tự tạo cho mình một website chuyên nghiệp mà không mất bất cứ chi phí nào. Với những nhà phát triển Web, sử dụng NukeViet có thể nhanh chóng xây dựng các hệ thống lớn mà việc lập trình không đòi hỏi quá nhiều thời gian vì NukeViet đã xây dựng sẵn hệ thống quản lý ưu việt. Thông tin chi tiết về NukeViet có thể tìm thấy ở bách khoa toàn thư mở Wikipedia: http://vi.wikipedia.org/wiki/NukeViet http://vi.wikipedia.org/wiki/NukeViet II. Thông tin về diễn đàn NukeViet: Diễn đàn NukeViet hoạt động trên website: http://nukeviet.vn/ http://nukeviet.vn hiện có trên 13.000 thành viên thực gồm học sinh, sinh viên & nhiều thành phần khác thuộc giới trí thức ở trong và ngoài nước. Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng,văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an... Nhiều học sinh, sinh viên tham gia diễn đàn NukeViet, đam mê mã nguồn mở và đã thành công với chính công việc mà họ yêu thích.'), 
(6, 'THƯ MỜI HỢP TÁC TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN MÃ NGUỒN MỞ NUKEVIET Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh. VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này. NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển. Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên. Phương thức hợp tác nhưsau: 1.Quảng cáo, trao đổi banner, liên kết website: a. Mô tả hình thức: - Quảng cáo trên website & hệ thống kênh truyền thông của 2 bên. - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet. b, Lợi ích: - Quảng bá rộng rãi cho đối tượng của 2 bên. - Giảm chi phí quảng bá cho 2 bên. c, Trách nhiệm: - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên. - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet. 2.Hợp tác cung cấp hosting thử nghiệm NukeViet: a. Mô tả hình thức: - Hai bên ký hợp đồng nguyên tắc & thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó: + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt. + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet. b. Lợi ích: - Mở rộng thị trường theo cả hướng đối tượng. - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh. c. Trách nhiệm: - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác. - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác. 3,Hợp tác nhân lực hỗ trợ người sử dụng: a, Mô tả hình thức: - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng. + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác. b, Lợi ích: - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên. - Tăng hiệu quả hỗ trợ khách hàng. c, Trách nhiệm: - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này. 4. Các hình thức khác: Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam. Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”. Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị. Thông tin liên hệ: CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC) Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội. Điện thoại: +84-4-85872007 Fax: +84-4-35500914 Website: http://www.vinades.vn/ www.vinades.vn – http://www.nukeviet.vn/ www.nukeviet.vn Email: mailto:contact@vinades.vn contact@vinades.vn'), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. 1. Vị trí dự tuyển: Chuyên viên đồ hoạ; Lập trình viên. 2. Mô tả công việc:Với vị trí lập trình viên PHP & MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet. Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau: + Vẽ và cắt giao diện. + Valid CSS, xHTML. + Ghép giao diện cho hệ thống.3. Yêu cầu: Lập trình viên PHP & MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML. + Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML & CSS. + Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+)Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc. 4: Quyền lợi: - Lương: thoả thuận, trả qua ATM. - Thưởng theo dự án, các ngày lễ tết. - Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội... 5. Thời gian làm việc: Toàn thời gian cố định hoặc làm online. 6. Hạn nộp hồ sơ: Không hạn chế, vui lòng kiểm tra tại http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/ 7. Hồ sơ bao gồm: * Cách thức đăng ký dự tuyển: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn * Nội dung hồ sơ xin việc file mềm gồm: + Đơn xin việc: Tự biên soạn. + Thông tin ứng viên: Theo mẫu của VINADES.,JSC (dowload tại đây: http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/ Mẫu lý lịch ứng viên) Chi tiết vui lòng tham khảo tại: http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/ Mọi thắc mắc vui lòng liên hệ: Công ty cổ phần phát triển nguồn mở Việt Nam. Địa chỉ: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội. - Tel: +84-4-85872007 - Fax: +84-4-35500914 - Email: mailto:contact@vinades.vn contact@vinades.vn - Website: http://www.vinades.vn/ http://www.vinades.vn'), 
(8, 'Giảm giá tới 90% giá module, ngày nào cũng là ngày \"mua chung\" trên webnhanh.vn! Như thông báo trên webnhanh.vn, chương trình \"http://webnhanh.vn/vi/thiet-ke-web/detail/Mua-chung-tren-Webnhanhvn-se-giam-gia-90-gia-module-da-cong-bo-245/ mua chung module\" nằm trong chính sách chung của webnhanh.vn trong việc hỗ trợ phát triển mã nguồn mở, giúp cho mọi người được hưởng những dịch vụ thiết kế website tốt nhất với chi phí thấp nhất. Tham gia chương trình này, bạn chỉ phải trả số tiền bằng 1/10 giá trị module mà vẫn được sở hữu module với tính năng hấp dẫn mà bạn mong muốn. Cụ thể, các module trong http://webnhanh.vn/vi/nvresources/cat/Modules-1/ kho module của webnhanh.vn đang chờ hoàn thiện sẽ được giảm giá tới 90% nếu khách hàng đăng ký mua chung module. Tuy nhiên sau 2 tháng thực hiện, Ban Quản Trị webnhanh.vn thấy rằng khả năng xuất hiện nhu cầu cùng mua chung 1 sản phẩm và dịch vụ có tính đặc thù như code dành cho web là rất thấp. Chính vì thế webnhanh.vn đã giảm giá đồng loạt các module trên webnhanh.vn để khách hàng có nhu cầu sẽ có nhiều cơ hội được sử dụng các module mà mình mong muốn cung cấp lên website. Đại đa số các module sẽ được giảm giá xuống mức giá siêu rẻ để đảm bảo mọi người đều có khả năng sử dụng. Đặc biệt với các module có mức giá từ 10-20 triệu đồng sẽ giảm giá xuống còn ở mức 1-5 triệu đồng. Giá rẻ hơn, nhiều giao diện hơn cho web Ngoài việc giảm giá http://webnhanh.vn/vi/nvresources/cat/Giao-dien-3/ các giao diện website do VINADES.,JSC thiết kế (từ mức giá 2 triệu đồng xuống còn 300 đến 700 ngàn đồng). Webnhanh.vn cũng sẽ cải thiện kho giao diện của mình bằng cách đưa vào sử dụng các mẫu giao diện của các nhà thiết kế giao diện khác với giá trung bình khoảng 300 ngàn đồng (chi phí chuyển template thành giao diện có thể cài đặt cho website). Khách hàng cũng có thể gửi mẫu giao diện (đã cắt HTML) để chúng tôi thực hiện việc ghép giao diện với mức giá 300-500 ngàn đồng (áp dụng mô hình giá chia sẻ của VINADES.,JSC trong http://vinades.vn/vi/news/San-pham/Thiet-ke-giao-dien-14/ thiết kế giao diện web (*)). Giảm giá các gói web dựng sẵn, nâng cao chất lượng và cấu hình dịch vụ Cơ cấu chất lượng sản phẩm và dịch vụ cũng thay đổi theo hướng nâng cao rõ rệt. Ngoài việc giảm giá các http://webnhanh.vn/vi/nvresources/package/ gói web dựng sẵn, webnhanh.vn đồng thời nâng cao chất lượng các dịch vụ đi kèm của các gói web này. Theo đó ngoài việc kéo dài thời gian bảo hành miễn phí lên 12 tháng, đồng thời webnhanh.vn cũng kéo dài thời gian sử dụng hosting miễn phí lên 12 tháng. Với mức hỗ trợ này, website thiết kế trên webnhanh.vn đảm bảo chất lượng cao và mức giá còn rẻ hơn cả các nhà cung cấp dịch vụ web giá rẻ. Đây là cơ hội rất lớn cho http://webnhanh.vn/vi/dealers/ các đại lý của webnhanh.vn để tạo nên lợi thế cạnh tranh về chất lượng và giá cả dịch vụ. (*) \"Giá chia sẻ\" là mức giá tiết kiệm cho khách hàng, nếu mua với mức giá này khách hàng sẽ tiết kiệm chi phí thiết kế giao diện một cách tối đa mà vẫn được toàn quyền sử dụng mẫu giao diện đã đặt hàng. Webnhanh.vn sẽ giữ lại mẫu giao diện này và đưa vào thư viện giao diện để cung cấp cho các khách hàng khác. Mô hình \"Giá chia sẻ\" sử dụng cho các khách hàng không quá khắt khe về việc đảm bảo tính duy nhất của mẫu giao diện đồng thời giúp webnhanh.vn làm phong phú thêm kho giao diện của mình.Chú ý: Ngoài việc cung cấp các gói web dựng sẵn với chi phí thấp phục vụ người dùng phổ thông, http://vinades.vn VINADES.,JSC vẫn duy trì dịch vụ thiết kế giao diện riêng và thiết kế website theo yêu cầu để phục vụ những khách hàng có nhu cầu riêng biệt và cao cấp hơn, khách hàng có nhu cầu vui lòng truy cập http://vinades.vn http://vinades.vn hoặc liên hệ nhân viên kinh doanh của VINADES.,JSC để được tư vấn và báo giá dịch vụ. Như vậy, cùng với việc tham gia cung cấp hosting chuyên nghiệp dành cho NukeViet của các nhà cung cấp hosting trong và ngoài nước như http://vinades.vn/vi/news/Doi-tac/VINADES-JSC-va-DIGISTAR-hop-tac-trong-viec-phat-trien-ma-nguon-mo-NukeViet-17/ DIGISTAR, http://nukeviet.vn/vi/news/the-gioi-cong-nghe/TMDHosting-cung-cap-dich-vu-hosting-chuyen-NukeViet-64/ TMDHosting hay http://nukeviet.vn/vi/news/the-gioi-cong-nghe/SiteGround-cung-cap-dich-vu-hosting-chuyen-NukeViet-59/ SiteGround, http://nukeviet.vn/vi/news/the-gioi-cong-nghe/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/ Webnhanh.vn là website đầu tiên có dịch vụ thiết kế website và bán code chuyên nghiệp dành riêng cho NukeViet. Sự chuyên nghiệp hóa trong các khâu từ phát triển đến cung cấp dịch vụ cho mã nguồn mở NukeViet sẽ mở ra một cơ hội phát triển mới cho người sử dụng web ở Việt Nam.'), 
(9, 'Nhắc đến các hệ thống quản trị nội dung (Content Management System – CMS) để quản lý các cổng thông tin điện tử trên Internet, không ít người sẽ nhắc đến các bộ công cụ như Joomla hay Wordpress. Tuy nhiên, có một sản phẩm hoàn toàn thuần Việt, do người Việt xây dựng không hề thua kém những sản phẩm trên cả về tính năng lẫn khả năng ứng dụng, đó là NukeViet của nhóm tác giả thuộc Công ty Cổ phần phát triển nguồn mở Việt Nam (VINADES). Với NukeViet, người dùng tại Việt Nam sẽ vượt qua các trở ngại về rào cản ngôn ngữ, có thể xây dựng và vận hành các trang web một cách dễ dàng nhất, đồng thời nhận được sự hỗ trợ của cộng đồng người dùng và các nhà phát triển cũng chính là người Việt Nam. Mới đây nhất, Ban giám khảo Giải thưởng Nhân Tài Đất Việt 2011 đã quyết định đưa NukeViet vào danh sách các sản phẩm đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011 diễn ra vào ngày 17-18/11 tới đây. Những ý tưởng giúp hình thành nên sản phẩm “thuần Việt” Theo chia sẻ của đại diện nhóm tác giả, năm 2004, anh Nguyễn Anh Tú, một lưu học sinh người Việt tại Nga với ý tưởng xây dựng một website để kết nối cộng đồng sinh viên du học đã sử dụng bộ CMS mã nguồn mở PHP-Nuke để thực hiện. Sau đó, anh Nguyễn Anh Tú đã phát triển và cải tiến bộ mã nguồn mở PHP-Nuke để chia sẻ cho các thành viên có nhu cầu xây dựng website một cách đơn giản và thuận tiện hơn. Được sự đón nhận của đông đảo người sử dụng, bộ mã nguồn đã liên tục được phát triển và trở thành một ứng dụng thuần Việt với tên gọi NukeViet. NukeViet đã nhanh chóng trở nên phổ biến trong giới các nhà xây dựng và phát triển website tại Việt Nam. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-1_4b905.jpg Giao diện một website tin tức được xây dựng bằng NukeViet Trong quá trình phát triển NukeViet, có một điều đội ngũ kỹ thuật luôn trăn trở là làm sao để có thể nâng cao tỉ lệ đóng góp của người Việt vào trong mã nguồn sản phẩm. Chính vì ý thức được điều này nên mức độ thuần Việt của sản phẩm ngày càng được nâng cao trong từng phiên bản phát hành. Cho đến phiên bản 3.0 (phát hành tháng 10 năm 2010) thì NukeViet đã thực sự trở thành một sản phẩm mã nguồn mở riêng của Việt Nam với 100% dòng code được viết mới. Kể từ đây, cộng đồng mã nguồn mở Việt Nam đã có riêng một bộ mã nguồn thuần Việt, tự hào sánh bước ngang vai cùng các cộng đồng mã nguồn mở khác trên thế giới. NukeViet ra đời đã giúp cộng đồng mạng Việt Nam giải quyết nhu cầu và mong muốn có một bộ mã nguồn mở của riêng Việt Nam, giúp phát triển hệ thống website của người Việt một cách an toàn nhất, đảm bảo nhất. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-2_600d0.jpg Một website bán hành trực tuyến xây dựng bằng NukeViet NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. Khả năng ứng dụng và những ưu điểm của NukeViet Kể từ khi ra đời và trải qua một quá trình dài phát triển, NukeViet hiện được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet chủ yếu được sử dụng làm trang tin tức nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-4_416a1.jpg Website phòng Giáo dục và Đào tạo Lạng Giang được xây dựng trên mã nguồn NukeViet NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ phiên bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: \"hệ thống Portal dành cho người Việt\". Tuy nhiên, kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế với hỗ trợ thêm nhiều ngôn ngữ. Trên thực tế, với những ưu điểm vượt trội của mình, NukeViet 3 đã được ứng dụng ở hàng ngàn website khác nhau. Đặc biệt, không ít các cơ quan, tổ chức của Nhà nước đã tin tưởng sử dụng mã nguồn NukeViet để xây dựng cổng thông tin điện tử của mình, như Cổng thông tin tích hợp 1 cửa cho Phòng giáo dục Lạng Giang, cổng thông tin 2 chiều - Công ty cổ phần đầu tư tài chính công đoàn dầu khí Việt Nam, Hệ thống tra cứu điểm, tra cứu văn bằng - Cổng thông tin Sở GD&ĐT Quảng Ninh, Website viện y học cổ truyền Quân Đội… Tất cả các dự án trên đều được khách hàng đánh giá rất cao về tính ứng dụng, hiệu quả do tiết kiệm chi phí và đáp ứng rất tốt nhu cầu sử dụng của các đơn vị. Hướng phát triển trong tương lai và những kỳ vọng trước mắt Với ý nghĩa là phần mềm quản lý website (chiếm tới 90% các giao tiếp và tương tác trực tiếp với người sử dụng trên môi trường internet), khi phát triển, NukeViet sẽ trở thành một công cụ truyền thông rất mạnh, có thể đem lại những hiệu quả to lớn khác. Nhóm phát triển sẽ phát huy lợi thế này để phát triển sản phẩm. Nhóm phát triển cũng muốn tăng cường các khả năng liên kết, chia sẻ và tích hợp dữ liệu giữa các hệ thống khác nhau nhằm tạo nên một mạng lưới lớn, rộng khắp và hoàn chỉnh, có thể huy động sức mạnh tổng lực, thực hiện các nhiệm vụ xã hội khác trên mã nguồn NukeViet của mình. NukeViet khi được kết hợp với xu thế phát triển của điện toán đám mây sẽ trở thành một nền tảng giúp phát triển nhiều hệ thống dịch vụ trực tuyến có thể thu hút nhiều người dùng với giá trị thương mại cao. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-3_46e98.jpg Giao diện soạn thảo nội dung trên NukeViet Với việc gửi sản phẩm dự thi tại Giải thưởng Nhân Tài Đất Việt 2011, nhóm tác giả của NukeViet hy vọng mã nguồn mở của mình sẽ đạt vị trí cao tại Giải thưởng, như một cách thức để quảng bá rộng rãi sản phẩm, được thừa nhận và hỗ trợ sử dụng trong các lĩnh vực mà nó có thể phục vụ tốt và đem lại hiệu quả kinh tế, xã hội cao như: lĩnh vực giáo dục, lĩnh vực hành chính… để các bộ-ban-ngành, các cơ quan hành chính, chính quyền địa phương nhìn thấy giá trị và hiệu quả to lớn của mã nguồn mở NukeViet để triển khai NukeViet phục vụ các cơ quan này. NukeViet sẽ giúp hiện thực hóa cải cách hành chính và góp phần đẩy nhanh thủ tục một cửa một cách tiết kiệm mà vẫn đạt hiệu quả cao nhất. Ngoài ra, uy tính của Giải thưởng, nhóm tác giả NukeViet hy vọng sẽ đem NukeViet đến nhiều người hơn, để cả xã hội được sử dụng thành quả lớn lao của bộ mã nguồn mở được coi là biểu tượng và đại diện tiểu biểu cho sự phát triển và thành công của mã nguồn mở Việt Nam. Không chỉ thế, mở ra cơ hội tiếp cận và học hỏi công nghệ cho hàng ngàn học sinh, sinh viên, qua đó có được các kiến thức đầy đủ về công nghệ web, về internet và vô số các kỹ năng làm việc trên máy tính khác mà có thể do vô tình hay cố ý, trong quá trình tìm hiểu, học tập và vận hành NukeViet mà họ đã có được. Với những ứng dụng rộng rãi mà NukeViet đã có được kể từ khi ra mắt và và trải qua thời gian dài phát triển, Hội đồng Giám khảo Giải Thưởng Nhân Tài Đất Việt đã đánh giá rất cao những ưu điểm và thế mạnh của NukeViet để đưa sản phẩm vào danh sách 17 sản phẩm sẽ tranh tài tại vòng Chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011 diễn ra vào ngày 17-18/11 tới đây. Bạn đọc có thể tìm hiểu thêm về NukeViet tại http://nukeviet.vn/vi/news/Bao-chi-viet/ http://nukeviet.vn/'), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg Sân khấu trước lễ trao giải. Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm. Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải. Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới dự Lễ trao giải. 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan. Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số… http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg Giáo sư - Viện sỹ Nguyễn Văn Hiệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam. Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải. Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg Tiết mục mở màn Lễ trao giải. Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự. Hà Nội, ngày 16 tháng 11 năm 2011 Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt. Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay. Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế. Chào thân ái, Chủ tịch danh dự Hội Khuyến học Việt Nam Đại tướng Võ Nguyên Giáp Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt. Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp các vị lãnh đạo Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ. Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia. “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang. Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng mới ra đời cách đây 7 năm. Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải. * Giải thưởng Khoa học Tự nhiên Việt Nam thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân. GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam. Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ. GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.” GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam. * Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược: 2 giải 1. Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình “Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp, 2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức. Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác. 2. Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu “Triển khai ghép tim trên người lấy từ người cho chết não”. Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế). http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt. Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện. --------------------- * Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin. Hệ thống sản phẩm đã ứng dụng thực tế: Giải Nhất: Không có. Giải Nhì: Không có Giải Ba: 3 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ cạc xử lý tín hiệu HDTV” của nhóm HD Việt Nam. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg Nhóm HDTV Việt Nam lên nhận giải. Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào. 2. “Mã nguồn mở NukeViet” của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC). /uploads/news/2011_11/nukeviet-nhantaidatviet2011.jpg NukeViet nhận giải ba Nhân tài đất Việt 2011 NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. 3. “Hệ thống ngôi nhà thông minh homeON” của nhóm Smart home group. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ. * Hệ thống sản phẩm có tiềm năng ứng dụng: Giải Nhất: Không có. Giải Nhì: trị giá 50 triệu đồng: “Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion” của nhóm tác giả SIG. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng. ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động. Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.” Giải Ba: 2 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ điều khiển IPNET” của nhóm IPNET http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET. Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc. 2. “Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX” của nhóm LYNX. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome… Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng. Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_cat`;
CREATE TABLE `nv4_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_cat`
--

INSERT INTO `nv4_vi_news_cat` VALUES
(1, 0, 'Tin tức', '', 'Tin-tuc', '', '', '', 0, 1, 1, 0, 'viewcat_main_right', 3, '8,12,9', 1, 4, 2, '', '', 1274986690, 1274986690, '6'), 
(2, 0, 'Sản phẩm', '', 'San-pham', '', '', '', 0, 2, 5, 0, 'viewcat_page_new', 0, '', 1, 4, 2, '', '', 1274986705, 1274986705, '6'), 
(8, 1, 'Thông cáo báo chí', '', 'thong-cao-bao-chi', '', '', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 1, 4, 2, '', '', 1274987105, 1274987244, '6'), 
(9, 1, 'Tin công nghệ', '', 'Tin-cong-nghe', '', '', '', 0, 3, 4, 1, 'viewcat_page_new', 0, '', 1, 4, 2, '', '', 1274987212, 1274987212, '6'), 
(10, 0, 'Đối tác', '', 'Doi-tac', '', '', '', 0, 3, 9, 0, 'viewcat_main_right', 0, '', 1, 4, 2, '', '', 1274987460, 1274987460, '6'), 
(11, 0, 'Tuyển dụng', '', 'Tuyen-dung', '', '', '', 0, 4, 12, 0, 'viewcat_page_new', 0, '', 1, 4, 2, '', '', 1274987538, 1274987538, '6'), 
(12, 1, 'Bản tin nội bộ', '', 'Ban-tin-noi-bo', '', '', '', 0, 2, 3, 1, 'viewcat_page_new', 0, '', 1, 4, 2, '', '', 1274987902, 1274987902, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_config_post`
--

DROP TABLE IF EXISTS `nv4_vi_news_config_post`;
CREATE TABLE `nv4_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_config_post`
--

INSERT INTO `nv4_vi_news_config_post` VALUES
(5, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_rows`
--

DROP TABLE IF EXISTS `nv4_vi_news_rows`;
CREATE TABLE `nv4_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_rows`
--

INSERT INTO `nv4_vi_news_rows` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0), 
(5, 2, '2', 1, 1, '', 5, 1274993307, 1275318039, 1, 1274993280, 0, 2, 'Giới thiệu về mã nguồn mở NukeViet', 'Gioi-thieu-ve-ma-nguon-mo-NukeViet', 'Chắc hẳn đây không phải lần đầu tiên bạn nghe nói đến mã nguồn mở. Và nếu bạn là người mê lướt web thì hẳn bạn từng nhìn thấy đâu đó cái tên NukeViet. NukeViet, phát âm là Nu-Ke-Việt, chính là phần mềm dùng để xây dựng các Website mà bạn ngày ngày online để truy cập đấy.', 'screenshot.jpg', '6', 1, 0, '2', 1, 1, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(7, 11, '11', 0, 1, '', 2, 1307197282, 1307197381, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên, chuyên viên đồ họa phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-chuyen-vien-do-hoa-phat-trien-NukeViet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '6', 1, 1, '2', 1, 1, 0, 0, 0), 
(8, 9, '9', 0, 1, 'laser', 3, 1310067949, 1310068009, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(9, 2, '2', 0, 1, 'Phạm Thế Quang Huy', 4, 1322685396, 1322686088, 1, 1322685396, 0, 2, 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet-Cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-Viet-Nam', '(Dân trí) - Là một trong những hệ quản trị nội dung nổi tiếng hàng đầu tại Việt Nam, NukeViet đã được áp dụng rộng rãi trong việc xây dựng nhiều trang báo điện tử và các cổng thông tin điện tử nổi tiếng tại Việt Nam. Mới đây nhất, NukeViet đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011', 'product_box.jpg', 'Sản phẩm dự thi Nhân tài Đất Việt 2011&#x3A; Mã nguồn mở NukeViet', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 4, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_sources`
--

DROP TABLE IF EXISTS `nv4_vi_news_sources`;
CREATE TABLE `nv4_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_sources`
--

INSERT INTO `nv4_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', 'http://vinades.vn', '', 2, 1274989787, 1274989787), 
(3, 'NukeViet', 'http://nukeviet.vn', '', 2, 1274989787, 1274989787), 
(4, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 3, 1322685396, 1322685396);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags`;
CREATE TABLE `nv4_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=33  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_tags`
--

INSERT INTO `nv4_vi_news_tags` VALUES
(1, 2, 'nguồn-mở', '', '', 'nguồn mở'), 
(2, 1, 'quen-thuộc', '', '', 'quen thuộc'), 
(3, 2, 'cộng-đồng', '', '', 'cộng đồng'), 
(4, 2, 'việt-nam', '', '', 'việt nam'), 
(5, 1, 'hoạt-động', '', '', 'hoạt động'), 
(6, 1, 'tin-tức', '', '', 'tin tức'), 
(7, 1, 'thương-mại-điện', '', '', 'thương mại điện'), 
(8, 1, 'điện-tử', '', '', 'điện tử'), 
(9, 3, 'nukeviet', '', '', 'nukeviet'), 
(10, 1, 'nền-tảng', '', '', 'nền tảng'), 
(11, 1, 'xây-dựng', '', '', 'xây dựng'), 
(12, 2, 'quản-trị', '', '', 'quản trị'), 
(13, 2, 'nội-dung', '', '', 'nội dung'), 
(14, 2, 'sử-dụng', '', '', 'sử dụng'), 
(15, 2, 'khả-năng', '', '', 'khả năng'), 
(16, 2, 'tích-hợp', '', '', 'tích hợp'), 
(17, 2, 'ứng-dụng', '', '', 'ứng dụng'), 
(18, 1, 'vinades', '', '', 'vinades'), 
(19, 1, 'lập-trình-viên', '', '', 'lập trình viên'), 
(20, 1, 'chuyên-viên-đồ-họa', '', '', 'chuyên viên đồ họa'), 
(21, 1, 'php', '', '', 'php'), 
(22, 1, 'mysql', '', '', 'mysql'), 
(23, 1, 'khai-trương', '', '', 'khai trương'), 
(24, 1, 'khuyến-mại', '', '', 'khuyến mại'), 
(25, 1, 'giảm-giá', '', '', 'giảm giá'), 
(26, 1, 'siêu-khuyến-mại', '', '', 'siêu khuyến mại'), 
(27, 1, 'webnhanh', '', '', 'webnhanh'), 
(28, 1, 'thiết-kế-website', '', '', 'thiết kế website'), 
(29, 1, 'giao-diện-web', '', '', 'giao diện web'), 
(30, 1, 'thiết-kế-web', '', '', 'thiết kế web'), 
(31, 2, 'nhân-tài-đất-việt-2011', '', '', 'nhân tài đất việt 2011'), 
(32, 2, 'mã-nguồn-mở', '', '', 'mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags_id`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags_id`;
CREATE TABLE `nv4_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_tags_id`
--

INSERT INTO `nv4_vi_news_tags_id` VALUES
(1, 1, 'nguồn mở'), 
(1, 2, 'quen thuộc'), 
(1, 3, 'cộng đồng'), 
(1, 4, 'việt nam'), 
(1, 5, 'hoạt động'), 
(1, 6, 'tin tức'), 
(1, 7, 'thương mại điện'), 
(1, 8, 'điện tử'), 
(1, 9, 'nukeviet'), 
(2, 10, 'nền tảng'), 
(2, 11, 'xây dựng'), 
(2, 1, 'nguồn mở'), 
(2, 4, 'việt nam'), 
(2, 3, 'cộng đồng'), 
(5, 12, 'quản trị'), 
(5, 13, 'nội dung'), 
(5, 14, 'sử dụng'), 
(5, 15, 'khả năng'), 
(5, 16, 'tích hợp'), 
(5, 17, 'ứng dụng'), 
(7, 18, 'vinades'), 
(7, 9, 'nukeviet'), 
(7, 19, 'lập trình viên'), 
(7, 20, 'chuyên viên đồ họa'), 
(7, 21, 'php'), 
(7, 22, 'mysql'), 
(8, 23, 'khai trương'), 
(8, 24, 'khuyến mại'), 
(8, 25, 'giảm giá'), 
(8, 26, 'siêu khuyến mại'), 
(8, 27, 'webnhanh'), 
(8, 28, 'thiết kế website'), 
(8, 29, 'giao diện web'), 
(8, 30, 'thiết kế web'), 
(9, 31, 'Nhân tài Đất Việt 2011'), 
(9, 32, 'mã nguồn mở'), 
(10, 31, 'Nhân tài đất Việt 2011'), 
(10, 32, 'mã nguồn mở'), 
(10, 9, 'nukeviet');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_topics`
--

DROP TABLE IF EXISTS `nv4_vi_news_topics`;
CREATE TABLE `nv4_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_topics`
--

INSERT INTO `nv4_vi_news_topics` VALUES
(1, 'NukeViet 3', 'NukeViet-3', '', 'NukeViet 3', 1, 'NukeViet 3', 1274990212, 1274990212);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page`
--

DROP TABLE IF EXISTS `nv4_vi_page`;
CREATE TABLE `nv4_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page_config`
--

DROP TABLE IF EXISTS `nv4_vi_page_config`;
CREATE TABLE `nv4_vi_page_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_page_config`
--

INSERT INTO `nv4_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_referer_stats`
--

DROP TABLE IF EXISTS `nv4_vi_referer_stats`;
CREATE TABLE `nv4_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_searchkeys`
--

DROP TABLE IF EXISTS `nv4_vi_searchkeys`;
CREATE TABLE `nv4_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `skey` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting`
--

DROP TABLE IF EXISTS `nv4_vi_voting`;
CREATE TABLE `nv4_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_voting`
--

INSERT INTO `nv4_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting_rows`
--

DROP TABLE IF EXISTS `nv4_vi_voting_rows`;
CREATE TABLE `nv4_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_voting_rows`
--

INSERT INTO `nv4_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);